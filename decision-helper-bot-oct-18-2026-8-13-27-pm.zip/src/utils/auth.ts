import { UserAccount } from '../types';
import { INITIAL_USER_ACCOUNTS } from './sampleData';

const ACCOUNTS_STORAGE_KEY = 'dhb_user_accounts';
const CURRENT_USER_STORAGE_KEY = 'dhb_current_user';

export const AVATAR_GRADIENTS = [
  'from-blue-600 to-indigo-600',
  'from-violet-600 to-purple-600',
  'from-emerald-500 to-teal-700',
  'from-amber-500 to-orange-600',
  'from-rose-500 to-pink-600',
  'from-cyan-500 to-blue-600',
];

export function getRandomGradient(): string {
  return AVATAR_GRADIENTS[Math.floor(Math.random() * AVATAR_GRADIENTS.length)];
}

/**
 * Retrieves all stored accounts.
 * Always ensures the requested demo account `acc:user password:123` exists.
 */
export function getStoredAccounts(): UserAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    let accounts: UserAccount[] = raw ? JSON.parse(raw) : [];

    // Ensure the required demo account `user` / `123` is always present
    const hasDefaultUser = accounts.some(
      (a) => a.username.trim().toLowerCase() === 'user'
    );

    if (!hasDefaultUser) {
      accounts = [...INITIAL_USER_ACCOUNTS, ...accounts];
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
    }

    return accounts;
  } catch (e) {
    console.error('Failed to load accounts from storage:', e);
    return INITIAL_USER_ACCOUNTS;
  }
}

/**
 * Saves the list of user accounts to localStorage
 */
export function saveAccounts(accounts: UserAccount[]): void {
  try {
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
  } catch (e) {
    console.error('Failed to save accounts to storage:', e);
  }
}

/**
 * Retrieves the currently logged-in user, if any.
 */
export function getCurrentUser(): UserAccount | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Sets the currently active user session
 */
export function setCurrentUser(user: UserAccount | null): void {
  try {
    if (user) {
      localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
    }
  } catch (e) {
    console.error('Failed to save current user:', e);
  }
}

export interface AuthResult {
  success: boolean;
  user?: UserAccount;
  error?: string;
}

/**
 * Authenticate by username (or email) and password.
 * Matches `acc:user password:123`
 */
export function authenticateUser(
  identifier: string,
  pass: string
): AuthResult {
  const cleanId = identifier.trim().toLowerCase();
  const accounts = getStoredAccounts();

  const account = accounts.find(
    (a) =>
      a.username.trim().toLowerCase() === cleanId ||
      a.email.trim().toLowerCase() === cleanId
  );

  if (!account) {
    return {
      success: false,
      error: 'Account not found. Check your username or create a new account.',
    };
  }

  if (account.password !== pass) {
    return {
      success: false,
      error: 'Incorrect password. (Hint: demo password is 123)',
    };
  }

  // Update last login timestamp
  const updatedUser: UserAccount = {
    ...account,
    lastLoginAt: Date.now(),
  };

  const updatedAccounts = accounts.map((a) =>
    a.id === updatedUser.id ? updatedUser : a
  );
  saveAccounts(updatedAccounts);
  setCurrentUser(updatedUser);

  return {
    success: true,
    user: updatedUser,
  };
}

export interface CreateAccountInput {
  username: string;
  password: string;
  displayName?: string;
  email?: string;
}

/**
 * Creates a new account and immediately logs the user in.
 */
export function createAccount(input: CreateAccountInput): AuthResult {
  const cleanUsername = input.username.trim().toLowerCase();

  if (!cleanUsername || cleanUsername.length < 2) {
    return {
      success: false,
      error: 'Username must be at least 2 characters long.',
    };
  }

  // Check valid chars
  if (!/^[a-zA-Z0-9._-]+$/.test(cleanUsername)) {
    return {
      success: false,
      error: 'Username can only contain letters, numbers, dots, and hyphens.',
    };
  }

  if (!input.password || input.password.length < 3) {
    return {
      success: false,
      error: 'Password must be at least 3 characters long.',
    };
  }

  const accounts = getStoredAccounts();

  // Check if username already exists
  if (accounts.some((a) => a.username.trim().toLowerCase() === cleanUsername)) {
    return {
      success: false,
      error: `Username "${cleanUsername}" is already taken. Please choose another.`,
    };
  }

  // Check if email already exists
  if (
    input.email &&
    accounts.some(
      (a) =>
        a.email &&
        a.email.trim().toLowerCase() === input.email!.trim().toLowerCase()
    )
  ) {
    return {
      success: false,
      error: `Email address "${input.email}" is already registered.`,
    };
  }

  const newAccount: UserAccount = {
    id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    username: cleanUsername,
    password: input.password,
    displayName:
      input.displayName?.trim() ||
      cleanUsername.charAt(0).toUpperCase() + cleanUsername.slice(1),
    email: input.email?.trim() || `${cleanUsername}@decisionhelper.app`,
    avatarColor: getRandomGradient(),
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
  };

  const updatedAccounts = [newAccount, ...accounts];
  saveAccounts(updatedAccounts);
  setCurrentUser(newAccount);

  return {
    success: true,
    user: newAccount,
  };
}
