import { 
  ParsedDecision, 
  DecisionOption, 
  DecisionRiskMatrix, 
  DecisionPerspectives, 
  DecisionDevilsAdvocate, 
  CognitiveBiasAnalysis,
  TemporalForecast,
  WeightedFactor,
  RiskLevel, 
  ReversibilityType 
} from '../types';

export function computeRiskLevel(longTermRisk: number, reversibility: number): RiskLevel {
  const riskIndex = (longTermRisk * 1.4) - (reversibility * 0.7);
  if (riskIndex <= 3.5) return 'Low';
  if (riskIndex <= 7.0) return 'Moderate';
  if (riskIndex <= 10.0) return 'High';
  return 'Critical';
}

export function computeConfidenceScore(shortTermImpact: number, reversibility: number, longTermRisk: number): number {
  const raw = (shortTermImpact * 3.0) + (reversibility * 4.2) + ((11 - longTermRisk) * 2.8);
  return Math.min(98, Math.max(45, Math.round(raw)));
}

export function parseDecisionText(text: string): ParsedDecision | null {
  if (!text) return null;

  // Check if this text contains the decision format structure
  const hasOptions = /Option\s+[A-C]:/i.test(text);
  const hasRec = /Recommendation:/i.test(text);

  if (!hasOptions || !hasRec) {
    return null;
  }

  try {
    // 1. Extract Quick Summary
    let quickSummary = '';
    const summaryMatch = text.match(/Quick Summary[:\s]*([^\n]+(?:\n[^\n]+)?)(?=\n\s*(?:Cognitive|Confidence|Advisory|\*\*Cognitive|\*\*Confidence|\*\*Option|Option\s+A))/i);
    if (summaryMatch) {
      quickSummary = summaryMatch[1].replace(/^\*+|\*+$/g, '').trim();
    } else {
      const firstLineMatch = text.match(/(?:Quick Summary[:\s]*)?([^\n]+)/i);
      if (firstLineMatch && !/Option\s+A/i.test(firstLineMatch[1])) {
        quickSummary = firstLineMatch[1].replace(/Quick Summary:?/i, '').trim();
      }
    }

    // 2. Extract Cognitive Bias Calibration
    let cognitiveBias: CognitiveBiasAnalysis | undefined = undefined;
    const biasBlockMatch = text.match(/(?:Cognitive Bias Calibration|Cognitive Bias Detector|Cognitive Bias)[:\s]*([\s\S]*?)(?=(?:Confidence\s*&?\s*Risk Matrix|Risk Matrix|Advisory Perspectives|\*\*Option\s+A|Option\s+A))/i);
    if (biasBlockMatch) {
      const bBlock = biasBlockMatch[1];
      let detectedBias = 'Analysis Paralysis';
      let manifestation = '';
      let debiasingChallenge = '';

      const detMatch = bBlock.match(/Detected Bias[:\s]*([^\n]+)/i);
      if (detMatch) detectedBias = detMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const manMatch = bBlock.match(/Manifestation[:\s]*([^\n]+)/i);
      if (manMatch) manifestation = manMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const debMatch = bBlock.match(/(?:De-Biasing Challenge|Challenge)[:\s]*([^\n]+)/i);
      if (debMatch) debiasingChallenge = debMatch[1].replace(/^\*+|\*+$/g, '').trim();

      if (detectedBias && !/none detected/i.test(detectedBias)) {
        cognitiveBias = {
          detectedBias,
          manifestation: manifestation || 'Framing places excessive emphasis on downside risks relative to upside opportunity.',
          debiasingChallenge: debiasingChallenge || 'If this decision were 100% reversible, what choice would you make right now?',
        };
      }
    }

    // 3. Extract Confidence & Risk Matrix
    let riskMatrix: DecisionRiskMatrix | undefined = undefined;
    const matrixBlockMatch = text.match(/(?:Confidence\s*&?\s*Risk Matrix|Risk Matrix|Dynamic Confidence)[:\s]*([\s\S]*?)(?=(?:Advisory Perspectives|Perspectives|Weighted Trade-Off|\*\*Option\s+A|Option\s+A|Recommendation:))/i);
    
    let shortTermScore = 7;
    let shortTermDesc = 'Fast execution with immediate tangible outcomes';
    let longTermRiskScore = 4;
    let longTermRiskDesc = 'Manageable downside with controllable dependencies';
    let revScore = 8;
    let revType: ReversibilityType = 'Two-Way Door';
    let revDesc = 'Easily adjusted or pivoted if outcomes deviate';
    let confidencePercent: number | undefined = undefined;
    let riskLevel: RiskLevel | undefined = undefined;
    let mitigationAdvice = 'Start with a localized test step before expanding investment.';

    if (matrixBlockMatch) {
      const block = matrixBlockMatch[1];

      // Short-Term Impact
      const stMatch = block.match(/Short-Term Impact[:\s]*(\d+)(?:\/10)?\s*(?:[-–:]\s*([^\n]+))?/i);
      if (stMatch) {
        shortTermScore = Math.min(10, Math.max(1, parseInt(stMatch[1], 10)));
        if (stMatch[2]) shortTermDesc = stMatch[2].replace(/^\*+|\*+$/g, '').trim();
      }

      // Long-Term Risk
      const ltMatch = block.match(/Long-Term Risk[:\s]*(\d+)(?:\/10)?\s*(?:[-–:]\s*([^\n]+))?/i);
      if (ltMatch) {
        longTermRiskScore = Math.min(10, Math.max(1, parseInt(ltMatch[1], 10)));
        if (ltMatch[2]) longTermRiskDesc = ltMatch[2].replace(/^\*+|\*+$/g, '').trim();
      }

      // Reversibility
      const revMatch = block.match(/Reversibility[:\s]*(\d+)?(?:\/10)?\s*(?:[-–:]\s*\[?([^\]\n]+)\]?)?\s*(?:[-–:]\s*([^\n]+))?/i);
      if (revMatch) {
        if (revMatch[1]) revScore = Math.min(10, Math.max(1, parseInt(revMatch[1], 10)));
        const typeStr = (revMatch[2] || '').toLowerCase();
        if (typeStr.includes('one-way') || typeStr.includes('irreversible')) {
          revType = 'One-Way Door';
        } else if (typeStr.includes('partial') || typeStr.includes('rollback')) {
          revType = 'Partial Rollback';
        } else {
          revType = 'Two-Way Door';
        }
        if (revMatch[3]) revDesc = revMatch[3].replace(/^\*+|\*+$/g, '').trim();
      }

      // Confidence Score
      const confMatch = block.match(/Confidence Score[:\s]*(\d+)%?/i);
      if (confMatch) {
        confidencePercent = Math.min(100, Math.max(1, parseInt(confMatch[1], 10)));
      }

      // Risk Level
      const rlMatch = block.match(/Risk Level[:\s]*([a-zA-Z]+)/i);
      if (rlMatch) {
        const parsedRl = rlMatch[1].trim();
        if (/low/i.test(parsedRl)) riskLevel = 'Low';
        else if (/mod/i.test(parsedRl)) riskLevel = 'Moderate';
        else if (/crit/i.test(parsedRl)) riskLevel = 'Critical';
        else if (/high/i.test(parsedRl)) riskLevel = 'High';
      }

      // Mitigation
      const mitMatch = block.match(/Mitigation[:\s]*([^\n]+)/i);
      if (mitMatch) {
        mitigationAdvice = mitMatch[1].replace(/^\*+|\*+$/g, '').trim();
      }
    }

    // Compute fallback metrics if not parsed
    if (confidencePercent === undefined) {
      confidencePercent = computeConfidenceScore(shortTermScore, revScore, longTermRiskScore);
    }
    if (!riskLevel) {
      riskLevel = computeRiskLevel(longTermRiskScore, revScore);
    }

    riskMatrix = {
      shortTermImpactScore: shortTermScore,
      shortTermImpactDesc: shortTermDesc,
      longTermRiskScore: longTermRiskScore,
      longTermRiskDesc: longTermRiskDesc,
      reversibilityScore: revScore,
      reversibilityType: revType,
      confidencePercent,
      riskLevel,
      mitigationAdvice,
    };

    // 4. Extract Advisory Perspectives
    let perspectives: DecisionPerspectives | undefined = undefined;
    const perspBlockMatch = text.match(/(?:Advisory Perspectives|Perspectives|Multi-Perspective)[:\s]*([\s\S]*?)(?=(?:Weighted Trade-Off|\*\*Option\s+A|Option\s+A|Recommendation:))/i);
    if (perspBlockMatch) {
      const block = perspBlockMatch[1];
      let pragmatistStance = '';
      let visionaryStance = '';
      let realistStance = '';

      const pragMatch = block.match(/Pragmatist[:\s]*([^\n]+)/i);
      if (pragMatch) pragmatistStance = pragMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const visMatch = block.match(/Visionary[:\s]*([^\n]+)/i);
      if (visMatch) visionaryStance = visMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const realMatch = block.match(/Realist[:\s]*([^\n]+)/i);
      if (realMatch) realistStance = realMatch[1].replace(/^\*+|\*+$/g, '').trim();

      if (pragmatistStance || visionaryStance || realistStance) {
        perspectives = {
          pragmatist: {
            stance: pragmatistStance || 'Favors the leanest immediate path to validation.',
          },
          visionary: {
            stance: visionaryStance || 'Prioritizes maximum strategic upside and future options.',
          },
          realist: {
            stance: realistStance || 'Highlights execution friction and resource constraints.',
          },
        };
      }
    }

    // 5. Extract Options (A, B, C...) + Weighted Multipliers
    const options: DecisionOption[] = [];
    const optionMatches = [...text.matchAll(/(?:\*\*)?Option\s+([A-Z])[:\s]*([^\n*]+)(?:\*\*)?([\s\S]*?)(?=(?:\*\*)?Option\s+[A-Z]|(?:\*\*)?Temporal\s+Scenario|(?:\*\*)?Recommendation:|$)/gi)];

    for (const match of optionMatches) {
      const letter = match[1].toUpperCase();
      let rawName = match[2].trim().replace(/^\*+|\*+$/g, '');
      
      // Parse Net Utility Index if present in header, e.g. "Option A: Hybrid Plan [Net Utility Index: +14.2]"
      let netUtilityIndex: number | undefined = undefined;
      const nuiHeaderMatch = rawName.match(/\[?(?:Net Utility Index|NUI)[:\s]*([+-]?\d+(?:\.\d+)?)\]?/i);
      if (nuiHeaderMatch) {
        netUtilityIndex = parseFloat(nuiHeaderMatch[1]);
        rawName = rawName.replace(/\[?(?:Net Utility Index|NUI)[:\s]*[+-]?\d+(?:\.\d+)?\]?/i, '').trim();
      }

      const content = match[3];
      const pros: string[] = [];
      const cons: string[] = [];
      const weightedPros: WeightedFactor[] = [];
      const weightedCons: WeightedFactor[] = [];

      const lines = content.split('\n');
      for (const line of lines) {
        const trimmed = line.trim().replace(/^[-*•+]\s*/, '').replace(/^\*+|\*+$/g, '');
        
        // Check for Pro lines
        if (/^Pro[:\s]/i.test(trimmed) || /^\+\s*Pro[:\s]/i.test(line.trim())) {
          const proFull = trimmed.replace(/^Pro[:\s]*/i, '').trim();
          pros.push(proFull);

          // Parse weights: (Weight: 4/5, Urgency: 1.5x -> +6.0)
          const weightMatch = proFull.match(/(.*?)\s*\((?:Weight[:\s]*(\d+)(?:\/5)?(?:,\s*Urgency[:\s]*(\d+(?:\.\d+)?x?))?(?:.*?[->:]\s*([+-]?\d+(?:\.\d+)?))?)\)/i);
          if (weightMatch) {
            const cleanText = weightMatch[1].trim();
            const weight = parseInt(weightMatch[2] || '4', 10);
            const urgency = parseFloat((weightMatch[3] || '1.2').replace('x', ''));
            const netScore = weightMatch[4] ? parseFloat(weightMatch[4]) : Math.round(weight * urgency * 10) / 10;
            weightedPros.push({
              text: cleanText,
              weight,
              urgency,
              netScore: Math.abs(netScore),
            });
          } else {
            weightedPros.push({
              text: proFull,
              weight: 4,
              urgency: 1.2,
              netScore: 4.8,
            });
          }
        } 
        // Check for Con lines
        else if (/^Con[:\s]/i.test(trimmed) || /^-\s*Con[:\s]/i.test(line.trim())) {
          const conFull = trimmed.replace(/^Con[:\s]*/i, '').trim();
          cons.push(conFull);

          const weightMatch = conFull.match(/(.*?)\s*\((?:Weight[:\s]*(\d+)(?:\/5)?(?:,\s*Urgency[:\s]*(\d+(?:\.\d+)?x?))?(?:.*?[->:]\s*([+-]?\d+(?:\.\d+)?))?)\)/i);
          if (weightMatch) {
            const cleanText = weightMatch[1].trim();
            const weight = parseInt(weightMatch[2] || '3', 10);
            const urgency = parseFloat((weightMatch[3] || '1.0').replace('x', ''));
            const netScore = weightMatch[4] ? parseFloat(weightMatch[4]) : -Math.round(weight * urgency * 10) / 10;
            weightedCons.push({
              text: cleanText,
              weight,
              urgency,
              netScore: -Math.abs(netScore),
            });
          } else {
            weightedCons.push({
              text: conFull,
              weight: 3,
              urgency: 1.0,
              netScore: -3.0,
            });
          }
        }
      }

      // Compute Net Utility Index if not parsed directly
      if (netUtilityIndex === undefined) {
        const proSum = weightedPros.reduce((acc, p) => acc + p.netScore, 0);
        const conSum = weightedCons.reduce((acc, c) => acc + Math.abs(c.netScore), 0);
        netUtilityIndex = Math.round((proSum - conSum) * 10) / 10;
      }

      if (pros.length > 0 || cons.length > 0 || rawName) {
        options.push({
          name: rawName || `Option ${letter}`,
          pros,
          cons,
          weightedPros: weightedPros.length > 0 ? weightedPros : undefined,
          weightedCons: weightedCons.length > 0 ? weightedCons : undefined,
          netUtilityIndex,
        });
      }
    }

    // 6. Extract Temporal Scenario Forecast
    let temporalForecast: TemporalForecast | undefined = undefined;
    const tempBlockMatch = text.match(/(?:Temporal Scenario Forecast|Temporal Projection|Scenario Forecast)[:\s]*([\s\S]*?)(?=(?:\*\*Recommendation|Recommendation:))/i);
    if (tempBlockMatch) {
      const tBlock = tempBlockMatch[1];
      let imm24 = '';
      let med6m = '';
      let long5y = '';
      let ripple = '';

      const immMatch = tBlock.match(/(?:T\+24\s*Hours|Immediate|24\s*Hours)[:\s]*([^\n]+)/i);
      if (immMatch) imm24 = immMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const medMatch = tBlock.match(/(?:T\+6\s*Months|Medium-Term|6\s*Months)[:\s]*([^\n]+)/i);
      if (medMatch) med6m = medMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const longMatch = tBlock.match(/(?:T\+5\s*Years|Long-Term|5\s*Years)[:\s]*([^\n]+)/i);
      if (longMatch) long5y = longMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const ripMatch = tBlock.match(/(?:Ripple Effect|Secondary Effect|Ripple)[:\s]*([^\n]+)/i);
      if (ripMatch) ripple = ripMatch[1].replace(/^\*+|\*+$/g, '').trim();

      if (imm24 || med6m || long5y || ripple) {
        temporalForecast = {
          immediate24h: imm24 || 'Initial relief from resolving ambiguity and beginning execution.',
          mediumTerm6m: med6m || 'Systematic habituation and visible compounding milestones.',
          longTerm5y: long5y || 'Significantly broadened optionality and reduced opportunity cost.',
          rippleEffect: ripple || 'Forces stakeholders to clarify dependencies sooner than planned.',
        };
      }
    }

    // 7. Extract Recommendation & Utility Delta
    let chosenOption = '';
    let because = '';
    let utilityDelta: string | undefined = undefined;
    const recMatch = text.match(/(?:\*\*)?Recommendation:[:\s]*([\s\S]*?)(?=(?:\*\*)?Devil's Advocate|(?:\*\*)?Next Step|$)/i);
    if (recMatch) {
      const fullRec = recMatch[1].trim();
      const deltaMatch = fullRec.match(/\((?:Utility Delta|Delta)[:\s]*([+-]?\d+(?:\.\d+)?)\)/i);
      if (deltaMatch) {
        utilityDelta = deltaMatch[1];
      }

      const becauseMatch = fullRec.match(/(.*?)(?:Because:[:\s]*)([\s\S]*)/i);
      if (becauseMatch) {
        chosenOption = becauseMatch[1].replace(/\((?:Utility Delta|Delta)[:\s]*[+-]?\d+(?:\.\d+)?\)/i, '').replace(/^\*+|\*+$/g, '').trim();
        because = becauseMatch[2].replace(/^\*+|\*+$/g, '').trim();
      } else {
        chosenOption = fullRec.replace(/\((?:Utility Delta|Delta)[:\s]*[+-]?\d+(?:\.\d+)?\)/i, '').replace(/^\*+|\*+$/g, '').trim();
      }
    }

    // 8. Extract Devil's Advocate Challenge
    let devilsAdvocate: DecisionDevilsAdvocate | undefined = undefined;
    const daBlockMatch = text.match(/(?:Devil's Advocate Challenge|Devil's Advocate)[:\s]*([\s\S]*?)(?=(?:\*\*)?Next Step|(?:\*\*)?Note:|$)/i);
    if (daBlockMatch) {
      const daBlock = daBlockMatch[1];
      let blindSpot = '';
      let counterArgument = '';
      let stressTestQuestion = '';

      const bsMatch = daBlock.match(/Blind Spot[:\s]*([^\n]+)/i);
      if (bsMatch) blindSpot = bsMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const caMatch = daBlock.match(/Counter-Argument[:\s]*([^\n]+)/i);
      if (caMatch) counterArgument = caMatch[1].replace(/^\*+|\*+$/g, '').trim();

      const stqMatch = daBlock.match(/Stress-Test Question[:\s]*([^\n]+)/i);
      if (stqMatch) stressTestQuestion = stqMatch[1].replace(/^\*+|\*+$/g, '').trim();

      if (blindSpot || counterArgument || stressTestQuestion) {
        devilsAdvocate = {
          blindSpot: blindSpot || 'Underestimating initial coordination overhead and ramp-up friction.',
          counterArgument: counterArgument || 'The chosen path risks delaying secondary priorities if immediate results stall.',
          stressTestQuestion: stressTestQuestion || 'If this approach fails within 30 days, what is the exact trigger to pivot?',
        };
      }
    }

    // 9. Extract Next Step
    let nextStep = '';
    const nextStepMatch = text.match(/(?:\*\*)?Next Step[:\s]*([\s\S]*?)(?=(?:\*\*)?Note:|$)/i);
    if (nextStepMatch) {
      nextStep = nextStepMatch[1].trim().replace(/^\*+|\*+$/g, '');
    }

    // 10. Extract Safety Notice
    let safetyNotice: string | undefined = undefined;
    const safetyMatch = text.match(/(Note:\s*This is general advice only\.[^\n]*)/i);
    if (safetyMatch) {
      safetyNotice = safetyMatch[1].trim();
    }

    if (options.length >= 2 && chosenOption) {
      return {
        quickSummary: quickSummary || 'Decision breakdown between options',
        options,
        recommendation: {
          chosenOption,
          because,
          utilityDelta,
        },
        nextStep: nextStep || 'Review your choices and take action.',
        safetyNotice,
        riskMatrix,
        perspectives,
        devilsAdvocate,
        cognitiveBias,
        temporalForecast,
      };
    }
  } catch (err) {
    console.error('Error parsing decision text:', err);
  }

  return null;
}
