import {
  VotingPoll,
  ScaleEvaluation,
  JournalEntry,
  FinancialDecisionModel,
  CoinTossResult,
  UserAccount,
} from '../types';

export const INITIAL_VOTING_POLLS: VotingPoll[] = [
  {
    id: 'poll-seed-1',
    title: 'Team Vote: Core Architecture Framework (Next.js vs Remix vs Vite SPA)',
    description: 'Deciding our frontend stack architecture for the 2026 enterprise revamp.',
    options: ['Option A: Next.js App Router', 'Option B: Vite + React SPA', 'Option C: Remix / React Router v7'],
    votingMethod: 'ranked_choice',
    pointsBudget: 100,
    createdAt: Date.now() - 86400000 * 2,
    createdAtFormatted: 'Aug 23, 2026, 10:30 AM',
    status: 'open',
    voters: [
      {
        id: 'voter-1',
        name: 'Sarah (Lead Engineer)',
        role: 'Engineering',
        avatarColor: 'bg-emerald-600',
        rankedChoices: ['Option B: Vite + React SPA', 'Option A: Next.js App Router', 'Option C: Remix / React Router v7'],
      },
      {
        id: 'voter-2',
        name: 'Alex (Product Lead)',
        role: 'Product',
        avatarColor: 'bg-blue-600',
        rankedChoices: ['Option A: Next.js App Router', 'Option B: Vite + React SPA', 'Option C: Remix / React Router v7'],
      },
      {
        id: 'voter-3',
        name: 'Marcus (Finance / CFO)',
        role: 'Finance',
        avatarColor: 'bg-amber-600',
        rankedChoices: ['Option B: Vite + React SPA', 'Option C: Remix / React Router v7', 'Option A: Next.js App Router'],
      },
    ],
  },
];

export const INITIAL_SCALE_EVALUATIONS: ScaleEvaluation[] = [
  {
    id: 'scale-seed-1',
    title: 'MCDA Scale: Cloud Hosting (AWS Serverless vs Dedicated Kubernetes)',
    options: ['Option A: AWS Serverless / Lambda', 'Option B: Kubernetes / EKS Cluster'],
    createdAt: Date.now() - 86400000 * 3,
    createdAtFormatted: 'Aug 22, 2026, 02:15 PM',
    criteria: [
      { id: 'c1', name: 'Operational Simplicity', weight: 5, higherIsBetter: true },
      { id: 'c2', name: 'Speed to Deploy', weight: 4, higherIsBetter: true },
      { id: 'c3', name: 'Cost Predictability', weight: 4, higherIsBetter: true },
      { id: 'c4', name: 'Vendor Lock-in Risk', weight: 3, higherIsBetter: false },
      { id: 'c5', name: 'Maintenance Overhead', weight: 4, higherIsBetter: false },
    ],
    optionScores: [
      {
        optionName: 'Option A: AWS Serverless / Lambda',
        scores: { c1: 9, c2: 9, c3: 7, c4: 7, c5: 2 },
        totalWeightedScore: 84,
      },
      {
        optionName: 'Option B: Kubernetes / EKS Cluster',
        scores: { c1: 4, c2: 5, c3: 8, c4: 2, c5: 8 },
        totalWeightedScore: 56,
      },
    ],
  },
];

export const INITIAL_JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: 'journal-seed-1',
    decisionTitle: 'Senior Tech Lead Role Transition',
    chosenOption: 'Option A: Transition into Tech Lead & Scale Team',
    date: 'Aug 20, 2026, 09:00 AM',
    timestamp: Date.now() - 86400000 * 5,
    mood: 'confident',
    confidenceAtTime: 90,
    tags: ['Career', 'Leadership', 'Growth'],
    contextReasoning:
      'Chose leadership trajectory because mentoring engineers and setting architectural direction generates 10x higher organizational leverage than solitary coding.',
    assumptionsMade: [
      'Executive leadership will sponsor 2 additional engineering hires.',
      'Team is eager for standardized RFCs and design reviews.',
    ],
    fearsAndRisks: 'Initial decrease in direct hands-on PR contributions during onboarding months.',
    retrospective: {
      reviewedAt: Date.now() - 86400000 * 1,
      reviewedAtFormatted: 'Aug 24, 2026, 04:30 PM',
      daysAfterDecision: 4,
      actualOutcome:
        'Sprint velocity increased by 25% and two junior developers were successfully unblocked on core microservices.',
      outcomeRating: 5,
      wasRightChoice: 'yes',
      lessonsLearned:
        'Clear delegation frameworks eliminate context switching and create psychological safety.',
      wouldChooseAgain: true,
    },
  },
];

export const INITIAL_FINANCIAL_MODELS: FinancialDecisionModel[] = [
  {
    id: 'fin-seed-1',
    title: 'Financial Model: Customer Support Automation Platform',
    currency: '$',
    budgetCap: 15000,
    createdAt: Date.now() - 86400000 * 4,
    createdAtFormatted: 'Aug 21, 2026, 11:45 AM',
    options: [
      {
        optionName: 'Option A: AI Copilot Suite (SaaS)',
        upfrontCost: 2500,
        recurringMonthlyCost: 650,
        expectedMonthlyReturnOrSavings: 2400,
        implementationWeeks: 2,
        oneYearNetCostOrBenefit: 18500,
        threeYearNetCostOrBenefit: 60500,
        paybackPeriodMonths: 2,
        riskContingencyPercent: 15,
      },
      {
        optionName: 'Option B: Hire Additional FTE Support Rep',
        upfrontCost: 4000,
        recurringMonthlyCost: 4500,
        expectedMonthlyReturnOrSavings: 4800,
        implementationWeeks: 6,
        oneYearNetCostOrBenefit: -400,
        threeYearNetCostOrBenefit: 6800,
        paybackPeriodMonths: 14,
        riskContingencyPercent: 10,
      },
    ],
    actualExpenses: [
      {
        id: 'exp-1',
        date: 'Aug 22, 2026',
        timestamp: Date.now() - 86400000 * 3,
        description: 'Vendor Sandbox Setup & Onboarding',
        amount: 2500,
        category: 'upfront',
      },
      {
        id: 'exp-2',
        date: 'Aug 24, 2026',
        timestamp: Date.now() - 86400000 * 1,
        description: 'Monthly Workspace License (Month 1)',
        amount: 650,
        category: 'recurring',
      },
    ],
  },
];

export const INITIAL_COIN_TOSSES: CoinTossResult[] = [
  {
    id: 'toss-seed-1',
    timestamp: Date.now() - 3600000 * 4,
    timestampFormatted: 'Today, 09:15 AM',
    optionHeads: 'Option A: Sign up for Marathon Training',
    optionTails: 'Option B: Stick to Current Gym Routine',
    mode: 'single',
    flips: ['heads'],
    winnerFace: 'heads',
    winningOption: 'Option A: Sign up for Marathon Training',
    gutCheck: {
      reaction: 'relief',
      reflectedChoice: 'Option A: Sign up for Marathon Training',
      note: 'Felt immediate excitement when Heads came up—sign that I truly wanted the challenge.',
    },
  },
  {
    id: 'toss-seed-2',
    timestamp: Date.now() - 86400000 * 1,
    timestampFormatted: 'Yesterday, 04:40 PM',
    optionHeads: 'Option A: Upgrade to Enterprise Tier Now',
    optionTails: 'Option B: Stay on Pro Tier for Another Quarter',
    mode: 'best_of_3',
    flips: ['tails', 'heads', 'tails'],
    winnerFace: 'tails',
    winningOption: 'Option B: Stay on Pro Tier for Another Quarter',
    gutCheck: {
      reaction: 'relief',
      reflectedChoice: 'Option B: Stay on Pro Tier for Another Quarter',
      note: 'Best of 3 confirmed patience. Gives us 90 days to test usage metrics first.',
    },
  },
];

export const INITIAL_USER_ACCOUNTS: UserAccount[] = [
  {
    id: 'user-default-1',
    username: 'user',
    password: '123',
    displayName: 'Lead Decision Maker',
    email: 'user@decisionhelper.app',
    avatarColor: 'from-blue-600 to-indigo-600',
    createdAt: Date.now() - 86400000 * 14,
    lastLoginAt: Date.now(),
  },
];
