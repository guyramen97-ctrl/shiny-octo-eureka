// Synthesized audio effects for the coin toss using Web Audio API
// No external mp3/wav files required, works offline and latency-free!

class CoinSoundEngine {
  private audioCtx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    try {
      const savedMute = localStorage.getItem('dhb_coin_sound_muted');
      if (savedMute !== null) {
        this.isMuted = JSON.parse(savedMute);
      }
    } catch {
      this.isMuted = false;
    }
  }

  private getContext(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    try {
      localStorage.setItem('dhb_coin_sound_muted', JSON.stringify(this.isMuted));
    } catch {}
    return this.isMuted;
  }

  /**
   * Crisp high-frequency metallic ping when coin is flicked into the air
   */
  public playToss(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // Harmonic metallic ping
    const freqs = [1800, 2400, 3600];
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      // slight pitch slide up on flick
      osc.frequency.exponentialRampToValueAtTime(freq * 1.08, now + 0.08);

      const peakGain = 0.15 / (i + 1);
      gain.gain.setValueAtTime(peakGain, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35 + i * 0.1);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    });

    // Spinning flutter clicks
    for (let j = 0; j < 6; j++) {
      const clickTime = now + 0.05 + j * 0.06;
      const clickOsc = ctx.createOscillator();
      const clickGain = ctx.createGain();

      clickOsc.type = 'triangle';
      clickOsc.frequency.setValueAtTime(950 + j * 50, clickTime);

      clickGain.gain.setValueAtTime(0.04, clickTime);
      clickGain.gain.exponentialRampToValueAtTime(0.001, clickTime + 0.03);

      clickOsc.connect(clickGain);
      clickGain.connect(ctx.destination);

      clickOsc.start(clickTime);
      clickOsc.stop(clickTime + 0.04);
    }
  }

  /**
   * Satisfying metallic chime + thud when coin lands on table
   */
  public playLand(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // Solid surface contact (thud)
    const thudOsc = ctx.createOscillator();
    const thudGain = ctx.createGain();
    thudOsc.type = 'sine';
    thudOsc.frequency.setValueAtTime(140, now);
    thudOsc.frequency.exponentialRampToValueAtTime(50, now + 0.09);

    thudGain.gain.setValueAtTime(0.3, now);
    thudGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    thudOsc.connect(thudGain);
    thudGain.connect(ctx.destination);

    thudOsc.start(now);
    thudOsc.stop(now + 0.14);

    // High metallic settlement chimes (wobble on table)
    [2100, 2800, 3400].forEach((freq, idx) => {
      const chimeOsc = ctx.createOscillator();
      const chimeGain = ctx.createGain();

      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(freq, now + 0.02);
      chimeOsc.frequency.exponentialRampToValueAtTime(freq * 0.96, now + 0.25);

      chimeGain.gain.setValueAtTime(0.12 / (idx + 1), now + 0.02);
      chimeGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      chimeOsc.connect(chimeGain);
      chimeGain.connect(ctx.destination);

      chimeOsc.start(now + 0.02);
      chimeOsc.stop(now + 0.38);
    });
  }

  /**
   * Celebratory chime when gut check reveals true preference
   */
  public playEureka(): void {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const chords = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 arpeggio

    chords.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const noteTime = now + i * 0.08;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.12, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(noteTime);
      osc.stop(noteTime + 0.45);
    });
  }
}

export const coinSound = new CoinSoundEngine();
