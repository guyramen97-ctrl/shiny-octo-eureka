import React, { useState, useEffect } from 'react';
import {
  ChatMessage,
  BotProfile,
  SavedDecision,
  ParsedDecision,
  ProgressLog,
  ProgressStatus,
  DashboardActiveTab,
  VotingPoll,
  ScaleEvaluation,
  JournalEntry,
  FinancialDecisionModel,
  CoinTossResult,
  UserAccount,
} from './types';
import { Header } from './components/Header';
import { ChatInterface } from './components/ChatInterface';
import { VotingDashboard } from './components/VotingDashboard';
import { ScalesDashboard } from './components/ScalesDashboard';
import { DiaryDashboard } from './components/DiaryDashboard';
import { FinancialDashboard } from './components/FinancialDashboard';
import { CoinTossDashboard } from './components/CoinTossDashboard';
import { BotProfileModal } from './components/BotProfileModal';
import { StructuredDecisionModal } from './components/StructuredDecisionModal';
import { SavedDecisionsDrawer } from './components/SavedDecisionsDrawer';
import { RecordProgressModal } from './components/RecordProgressModal';
import { ProgressReportModal } from './components/ProgressReportModal';
import { ConfirmChoiceModal } from './components/ConfirmChoiceModal';
import { AuthModal } from './components/AuthModal';
import { getCurrentUser, setCurrentUser } from './utils/auth';
import { parseDecisionText } from './utils/decisionParser';
import {
  INITIAL_VOTING_POLLS,
  INITIAL_SCALE_EVALUATIONS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_FINANCIAL_MODELS,
  INITIAL_COIN_TOSSES,
} from './utils/sampleData';

const DEFAULT_BOT_PROFILE: BotProfile = {
  name: 'Decision Helper Bot',
  persona: 'Friendly, neutral, practical, conversational, zero fluff',
  description: 'Fast, clear, low-stress decision maker between 2 or more options.',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<DashboardActiveTab>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [botProfile, setBotProfile] = useState<BotProfile>(() => {
    try {
      const saved = localStorage.getItem('dhb_bot_profile');
      return saved ? JSON.parse(saved) : DEFAULT_BOT_PROFILE;
    } catch {
      return DEFAULT_BOT_PROFILE;
    }
  });

  const [savedDecisions, setSavedDecisions] = useState<SavedDecision[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_saved_decisions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Feature States
  const [votingPolls, setVotingPolls] = useState<VotingPoll[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_voting_polls');
      return saved ? JSON.parse(saved) : INITIAL_VOTING_POLLS;
    } catch {
      return INITIAL_VOTING_POLLS;
    }
  });

  const [scaleEvaluations, setScaleEvaluations] = useState<ScaleEvaluation[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_scale_evaluations');
      return saved ? JSON.parse(saved) : INITIAL_SCALE_EVALUATIONS;
    } catch {
      return INITIAL_SCALE_EVALUATIONS;
    }
  });

  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_journal_entries');
      return saved ? JSON.parse(saved) : INITIAL_JOURNAL_ENTRIES;
    } catch {
      return INITIAL_JOURNAL_ENTRIES;
    }
  });

  const [financialModels, setFinancialModels] = useState<FinancialDecisionModel[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_financial_models');
      return saved ? JSON.parse(saved) : INITIAL_FINANCIAL_MODELS;
    } catch {
      return INITIAL_FINANCIAL_MODELS;
    }
  });

  const [coinTossHistory, setCoinTossHistory] = useState<CoinTossResult[]>(() => {
    try {
      const saved = localStorage.getItem('dhb_coin_toss_history');
      return saved ? JSON.parse(saved) : INITIAL_COIN_TOSSES;
    } catch {
      return INITIAL_COIN_TOSSES;
    }
  });

  const [coinTossInitialOptions, setCoinTossInitialOptions] = useState<{
    heads: string;
    tails: string;
    decisionId?: string;
  } | undefined>(undefined);

  // User Authentication state
  const [currentUser, setCurrentUserSession] = useState<UserAccount | null>(() => {
    return getCurrentUser();
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'switch'>('login');

  // Modal / Drawer visibility states
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isBuilderModalOpen, setIsBuilderModalOpen] = useState(false);
  const [isHistoryDrawerOpen, setIsHistoryDrawerOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [selectedDecisionForProgress, setSelectedDecisionForProgress] = useState<SavedDecision | null>(null);
  const [isConfirmChoiceModalOpen, setIsConfirmChoiceModalOpen] = useState(false);
  const [selectedDecisionForConfirm, setSelectedDecisionForConfirm] = useState<{
    decision: ParsedDecision;
    selectedOptionName: string;
    existingConfirmedChoice?: string;
  } | null>(null);

  // Sync state to local storage
  useEffect(() => {
    try {
      localStorage.setItem('dhb_bot_profile', JSON.stringify(botProfile));
    } catch (e) {
      console.error('Failed to save bot profile:', e);
    }
  }, [botProfile]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_saved_decisions', JSON.stringify(savedDecisions));
    } catch (e) {
      console.error('Failed to save decisions:', e);
    }
  }, [savedDecisions]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_voting_polls', JSON.stringify(votingPolls));
    } catch (e) {
      console.error('Failed to save voting polls:', e);
    }
  }, [votingPolls]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_scale_evaluations', JSON.stringify(scaleEvaluations));
    } catch (e) {
      console.error('Failed to save scale evaluations:', e);
    }
  }, [scaleEvaluations]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_journal_entries', JSON.stringify(journalEntries));
    } catch (e) {
      console.error('Failed to save journal entries:', e);
    }
  }, [journalEntries]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_financial_models', JSON.stringify(financialModels));
    } catch (e) {
      console.error('Failed to save financial models:', e);
    }
  }, [financialModels]);

  useEffect(() => {
    try {
      localStorage.setItem('dhb_coin_toss_history', JSON.stringify(coinTossHistory));
    } catch (e) {
      console.error('Failed to save coin toss history:', e);
    }
  }, [coinTossHistory]);


  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          botProfile,
        }),
      });

      const rawText = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(rawText);
      } catch {
        // Response is not JSON (e.g. HTML error or gateway response)
      }

      if (!res.ok) {
        const fallbackMsg = rawText.startsWith('<!') || rawText.includes('<html')
          ? `The AI service is temporarily unavailable (HTTP ${res.status}). Please try again in a moment.`
          : rawText;
        throw new Error(data?.error || fallbackMsg || 'Failed to get a response from Decision Helper Bot.');
      }

      if (!data) {
        throw new Error('Received an unexpected response format from the server. Please try again.');
      }

      const botResponseText: string = data.text || '';
      const updatedProfile = data.updatedProfile;

      // If Gemini tagged a profile update, apply it
      if (updatedProfile) {
        setBotProfile((prev) => ({
          ...prev,
          name: updatedProfile.name || prev.name,
          persona: updatedProfile.persona || prev.persona,
        }));
      }

      // Check if user requested name or persona change via standard keywords
      const nameChangeMatch = text.match(/(?:change your name to|call yourself|name yourself)\s+([^\.\,\n\!]+)/i);
      const personaChangeMatch = text.match(/(?:act like|be a|adopt persona)\s+([^\.\,\n\!]+)/i);

      if (nameChangeMatch && !updatedProfile?.name) {
        setBotProfile((prev) => ({ ...prev, name: nameChangeMatch[1].trim() }));
      }
      if (personaChangeMatch && !updatedProfile?.persona) {
        setBotProfile((prev) => ({ ...prev, persona: personaChangeMatch[1].trim() }));
      }

      // Parse structured decision if available
      const parsedDecision = parseDecisionText(botResponseText);

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        content: botResponseText,
        timestamp: Date.now(),
        parsedDecision,
        botName: botProfile.name,
        botPersona: botProfile.persona,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
      let cleanErrorMessage = 'Unable to analyze decision at the moment. Please try again.';
      if (err?.message) {
        try {
          if (err.message.includes('{')) {
            const jsonStart = err.message.indexOf('{');
            const parsed = JSON.parse(err.message.slice(jsonStart));
            cleanErrorMessage = parsed?.error?.message || parsed?.message || err.message;
          } else {
            cleanErrorMessage = err.message;
          }
        } catch {
          cleanErrorMessage = err.message;
        }
      }

      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        content: `Error: ${cleanErrorMessage}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDecision = (decision: ParsedDecision, title?: string): SavedDecision => {
    const existing = savedDecisions.find((d) => d.parsedDecision.quickSummary === decision.quickSummary);
    if (existing) return existing;

    const formattedNow = new Date().toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const newSaved: SavedDecision = {
      id: `decision-${Date.now()}`,
      title: title || decision.quickSummary || `Decision: ${decision.options.map((o) => o.name).join(' vs ')}`,
      date: formattedNow,
      timestamp: Date.now(),
      parsedDecision: decision,
      nextStepCompleted: false,
      status: 'not_started',
      progressPercent: 0,
      progressLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: Date.now(),
          dateTimeFormatted: formattedNow,
          status: 'not_started',
          note: `Decision established and saved. Next action: ${decision.nextStep}`,
          progressPercent: 0,
        },
      ],
    };

    setSavedDecisions((prev) => [newSaved, ...prev]);
    return newSaved;
  };

  const handleToggleNextStep = (id: string) => {
    setSavedDecisions((prev) =>
      prev.map((d) => {
        if (d.id !== id) return d;
        const willComplete = !d.nextStepCompleted;
        const now = Date.now();
        const formattedNow = new Date(now).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: 'numeric',
          minute: '2-digit',
          hour12: true,
        });

        const newLog: ProgressLog = {
          id: `log-${now}`,
          timestamp: now,
          dateTimeFormatted: formattedNow,
          status: willComplete ? 'completed' : 'in_progress',
          note: willComplete ? 'Marked action item as complete.' : 'Re-opened action item.',
          progressPercent: willComplete ? 100 : 50,
        };

        return {
          ...d,
          nextStepCompleted: willComplete,
          completedAt: willComplete ? now : undefined,
          completedAtFormatted: willComplete ? formattedNow : undefined,
          status: willComplete ? 'completed' : 'in_progress',
          progressPercent: willComplete ? 100 : 50,
          progressLogs: [newLog, ...(d.progressLogs || [])],
        };
      })
    );
  };

  const handleSaveProgress = (
    decisionId: string,
    logData: Omit<ProgressLog, 'id'>,
    newStatus: ProgressStatus,
    newPercent: number,
    updatedConfirmedChoice?: string
  ) => {
    setSavedDecisions((prev) =>
      prev.map((d) => {
        if (d.id !== decisionId) return d;
        const isCompleted = newStatus === 'completed' || newPercent === 100;
        const newLog: ProgressLog = {
          ...logData,
          id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        };

        const choiceToSet = updatedConfirmedChoice !== undefined ? (updatedConfirmedChoice || undefined) : d.confirmedChoice;

        return {
          ...d,
          confirmedChoice: choiceToSet,
          confirmedAt: (choiceToSet && !d.confirmedAt) ? logData.timestamp : d.confirmedAt,
          confirmedAtFormatted: (choiceToSet && !d.confirmedAtFormatted) ? logData.dateTimeFormatted : d.confirmedAtFormatted,
          status: newStatus,
          progressPercent: newPercent,
          nextStepCompleted: isCompleted,
          completedAt: isCompleted ? logData.timestamp : undefined,
          completedAtFormatted: isCompleted ? logData.dateTimeFormatted : undefined,
          progressLogs: [newLog, ...(d.progressLogs || [])],
        };
      })
    );
  };

  const handleOpenRecordProgress = (decision: SavedDecision) => {
    setSelectedDecisionForProgress(decision);
    setIsRecordModalOpen(true);
  };

  const handleOpenConfirmChoice = (decision: ParsedDecision, optionName?: string) => {
    const existing = savedDecisions.find(
      (d) =>
        d.parsedDecision.quickSummary === decision.quickSummary ||
        (d.parsedDecision.recommendation.chosenOption === decision.recommendation.chosenOption &&
         d.parsedDecision.options.length === decision.options.length)
    );

    setSelectedDecisionForConfirm({
      decision,
      selectedOptionName: optionName || existing?.confirmedChoice || decision.recommendation.chosenOption || decision.options[0]?.name || '',
      existingConfirmedChoice: existing?.confirmedChoice,
    });
    setIsConfirmChoiceModalOpen(true);
  };

  const handleConfirmChoice = (
    decision: ParsedDecision,
    optionName: string,
    details: {
      confirmedDateFormatted: string;
      timestamp: number;
      reason: string;
      customNextStep: string;
      initialStatus: ProgressStatus;
      initialPercent: number;
    }
  ) => {
    // Check if decision exists in savedDecisions
    const existingIndex = savedDecisions.findIndex(
      (d) =>
        d.parsedDecision.quickSummary === decision.quickSummary ||
        (d.parsedDecision.recommendation.chosenOption === decision.recommendation.chosenOption &&
         d.parsedDecision.options.length === decision.options.length)
    );

    const logEntry: ProgressLog = {
      id: `log-confirm-${Date.now()}`,
      timestamp: details.timestamp,
      dateTimeFormatted: details.confirmedDateFormatted,
      status: details.initialStatus,
      note: `Confirmed Choice: "${optionName}"${details.reason ? ` • Rationale: ${details.reason}` : ''}`,
      progressPercent: details.initialPercent,
    };

    if (existingIndex >= 0) {
      setSavedDecisions((prev) =>
        prev.map((d, idx) => {
          if (idx !== existingIndex) return d;
          return {
            ...d,
            confirmedChoice: optionName,
            confirmedAt: details.timestamp,
            confirmedAtFormatted: details.confirmedDateFormatted,
            confirmedReason: details.reason || undefined,
            status: details.initialStatus,
            progressPercent: Math.max(d.progressPercent || 0, details.initialPercent),
            parsedDecision: {
              ...d.parsedDecision,
              nextStep: details.customNextStep || d.parsedDecision.nextStep,
              confirmedChoice: optionName,
              confirmedAtFormatted: details.confirmedDateFormatted,
            },
            progressLogs: [logEntry, ...(d.progressLogs || [])],
          };
        })
      );
    } else {
      // Create new saved decision
      const newSaved: SavedDecision = {
        id: `decision-${Date.now()}`,
        title: decision.quickSummary || `Decision: ${decision.options.map((o) => o.name).join(' vs ')}`,
        date: details.confirmedDateFormatted,
        timestamp: details.timestamp,
        confirmedChoice: optionName,
        confirmedAt: details.timestamp,
        confirmedAtFormatted: details.confirmedDateFormatted,
        confirmedReason: details.reason || undefined,
        parsedDecision: {
          ...decision,
          nextStep: details.customNextStep || decision.nextStep,
          confirmedChoice: optionName,
          confirmedAtFormatted: details.confirmedDateFormatted,
        },
        nextStepCompleted: details.initialPercent === 100,
        status: details.initialStatus,
        progressPercent: details.initialPercent,
        progressLogs: [
          logEntry,
          {
            id: `log-init-${Date.now()}`,
            timestamp: details.timestamp,
            dateTimeFormatted: details.confirmedDateFormatted,
            status: 'not_started',
            note: `Decision established and saved. Next action: ${details.customNextStep || decision.nextStep}`,
            progressPercent: 0,
          },
        ],
      };
      setSavedDecisions((prev) => [newSaved, ...prev]);
    }

    // Add confirmation notice to chat
    const confirmNotice: ChatMessage = {
      id: `confirm-msg-${Date.now()}`,
      role: 'model',
      content: `🎯 **Choice Confirmed:** You selected **${optionName}** on **${details.confirmedDateFormatted}**.\n\n${details.reason ? `> *Rationale:* ${details.reason}\n\n` : ''}This choice has been permanently recorded in your **Progress Report**. Next step: *${details.customNextStep || decision.nextStep}*`,
      timestamp: Date.now(),
    };
    setMessages((prev) => [...prev, confirmNotice]);

    setIsConfirmChoiceModalOpen(false);
    setSelectedDecisionForConfirm(null);
  };

  const handleDeleteDecision = (id: string) => {
    setSavedDecisions((prev) => prev.filter((d) => d.id !== id));
  };

  const handleClearSavedDecisions = () => {
    if (window.confirm('Clear all saved decisions and progress reports?')) {
      setSavedDecisions([]);
    }
  };

  const handleClearChat = () => {
    setMessages([]);
  };

  const handleOpenCoinToss = (heads: string, tails: string, decisionId?: string) => {
    setCoinTossInitialOptions({ heads, tails, decisionId });
    setActiveTab('cointoss');
  };

  const handleSaveToJournalFromCoinToss = (entry: Partial<JournalEntry>) => {
    const newEntry: JournalEntry = {
      id: `journal-${Date.now()}`,
      decisionTitle: entry.decisionTitle || 'Coin Toss Decision',
      chosenOption: entry.chosenOption,
      date: entry.date || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: entry.timestamp || Date.now(),
      mood: entry.mood || 'confident',
      confidenceAtTime: entry.confidenceAtTime || 85,
      tags: entry.tags || ['Coin Toss', 'Gut-Check'],
      contextReasoning: entry.contextReasoning || '',
      assumptionsMade: entry.assumptionsMade || [],
      fearsAndRisks: entry.fearsAndRisks || '',
    };
    setJournalEntries((prev) => [newEntry, ...prev]);
  };

  const handleConfirmDecisionChoiceFromCoinToss = (decisionId: string, optionName: string) => {
    const now = Date.now();
    const formattedDate = new Date().toLocaleString([], {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    setSavedDecisions((prev) =>
      prev.map((dec) => {
        if (dec.id === decisionId) {
          return {
            ...dec,
            confirmedChoice: optionName,
            confirmedAt: now,
            confirmedAtFormatted: formattedDate,
            parsedDecision: {
              ...dec.parsedDecision,
              confirmedChoice: optionName,
              confirmedAtFormatted: formattedDate,
            },
          };
        }
        return dec;
      })
    );
  };

  const handleOpenAuth = (mode: 'login' | 'register' | 'switch' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUserSession(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentUserSession(null);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-white text-[#111827] font-sans antialiased overflow-hidden">
      {/* Top Header */}
      <Header
        botProfile={botProfile}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenHistory={() => setIsHistoryDrawerOpen(true)}
        onOpenBuilder={() => setIsBuilderModalOpen(true)}
        onOpenReport={() => setIsReportModalOpen(true)}
        onClearChat={handleClearChat}
        savedCount={savedDecisions.length}
        votingCount={votingPolls.length}
        scalesCount={scaleEvaluations.length}
        journalCount={journalEntries.length}
        financialCount={financialModels.length}
        coinTossCount={coinTossHistory.length}
        currentUser={currentUser}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
      />

      {/* Main Dynamic View Area */}
      <main className="flex-1 flex flex-col min-h-0 overflow-y-auto">
        {activeTab === 'chat' && (
          <ChatInterface
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            botProfile={botProfile}
            onSaveDecision={handleSaveDecision}
            savedDecisionIds={savedDecisions.map((d) => d.parsedDecision.quickSummary)}
            savedDecisions={savedDecisions}
            onOpenBuilder={() => setIsBuilderModalOpen(true)}
            onOpenConfirmChoice={handleOpenConfirmChoice}
            onOpenCoinToss={handleOpenCoinToss}
            currentUser={currentUser}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {activeTab === 'voting' && (
          <VotingDashboard
            polls={votingPolls}
            onSavePolls={setVotingPolls}
            savedDecisions={savedDecisions}
          />
        )}

        {activeTab === 'scales' && (
          <ScalesDashboard
            evaluations={scaleEvaluations}
            onSaveEvaluations={setScaleEvaluations}
            savedDecisions={savedDecisions}
          />
        )}

        {activeTab === 'journal' && (
          <DiaryDashboard
            journals={journalEntries}
            onSaveJournals={setJournalEntries}
            savedDecisions={savedDecisions}
          />
        )}

        {activeTab === 'financials' && (
          <FinancialDashboard
            financialModels={financialModels}
            onSaveModels={setFinancialModels}
            savedDecisions={savedDecisions}
          />
        )}

        {activeTab === 'cointoss' && (
          <CoinTossDashboard
            tossHistory={coinTossHistory}
            onSaveTossHistory={setCoinTossHistory}
            savedDecisions={savedDecisions}
            onSaveToJournal={handleSaveToJournalFromCoinToss}
            onConfirmDecisionChoice={handleConfirmDecisionChoiceFromCoinToss}
            initialOptions={coinTossInitialOptions}
          />
        )}
      </main>

      {/* Bot Profile & Persona Modal */}
      <BotProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentProfile={botProfile}
        onSaveProfile={(newProf) => {
          setBotProfile(newProf);
          const updateNotice: ChatMessage = {
            id: `notice-${Date.now()}`,
            role: 'model',
            content: `Profile updated: Now operating as **${newProf.name}** (${newProf.persona}).`,
            timestamp: Date.now(),
          };
          setMessages((prev) => [...prev, updateNotice]);
        }}
      />

      {/* Structured Decision Modal */}
      <StructuredDecisionModal
        isOpen={isBuilderModalOpen}
        onClose={() => setIsBuilderModalOpen(false)}
        onSubmit={handleSendMessage}
      />

      {/* Saved Decisions Drawer */}
      <SavedDecisionsDrawer
        isOpen={isHistoryDrawerOpen}
        onClose={() => setIsHistoryDrawerOpen(false)}
        savedDecisions={savedDecisions}
        onToggleNextStep={handleToggleNextStep}
        onDeleteDecision={handleDeleteDecision}
        onSelectDecision={() => {}}
        onClearAll={handleClearSavedDecisions}
        onOpenRecordModal={handleOpenRecordProgress}
        onOpenConfirmChoice={handleOpenConfirmChoice}
        onOpenReportModal={() => {
          setIsHistoryDrawerOpen(false);
          setIsReportModalOpen(true);
        }}
      />

      {/* Record Progress & Date/Time Modal */}
      <RecordProgressModal
        isOpen={isRecordModalOpen}
        onClose={() => {
          setIsRecordModalOpen(false);
          setSelectedDecisionForProgress(null);
        }}
        decision={selectedDecisionForProgress}
        onSaveProgress={handleSaveProgress}
      />

      {/* Full Progress Report & Timeline Modal */}
      <ProgressReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        savedDecisions={savedDecisions}
        onOpenRecordModal={(dec) => {
          setSelectedDecisionForProgress(dec);
          setIsRecordModalOpen(true);
        }}
        onOpenConfirmChoice={handleOpenConfirmChoice}
      />

      {/* Confirm Choice Modal */}
      <ConfirmChoiceModal
        isOpen={isConfirmChoiceModalOpen}
        onClose={() => {
          setIsConfirmChoiceModalOpen(false);
          setSelectedDecisionForConfirm(null);
        }}
        decision={selectedDecisionForConfirm?.decision || null}
        selectedOptionName={selectedDecisionForConfirm?.selectedOptionName || ''}
        existingConfirmedChoice={selectedDecisionForConfirm?.existingConfirmedChoice}
        onConfirmChoice={handleConfirmChoice}
      />

      {/* Authentication / Login & Register Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={handleLoginSuccess}
        initialMode={authModalMode}
      />
    </div>
  );
}

