export interface WeightedFactor {
  text: string;
  weight: number; // 1 to 5
  urgency: number; // 1.0x to 2.0x
  netScore: number; // signed score (+ or -)
}

export interface DecisionOption {
  name: string;
  pros: string[];
  cons: string[];
  weightedPros?: WeightedFactor[];
  weightedCons?: WeightedFactor[];
  netUtilityIndex?: number;
}

export type RiskLevel = 'Low' | 'Moderate' | 'High' | 'Critical';
export type ReversibilityType = 'One-Way Door' | 'Two-Way Door' | 'Partial Rollback';

export type CognitiveBiasType =
  | 'Sunk Cost Fallacy'
  | 'Loss Aversion'
  | 'Analysis Paralysis'
  | 'Confirmation Bias'
  | 'Status Quo Bias'
  | 'False Dilemma'
  | 'Present Bias'
  | 'None Detected';

export interface CognitiveBiasAnalysis {
  detectedBias: CognitiveBiasType | string;
  manifestation: string;
  debiasingChallenge: string;
}

export interface TemporalForecast {
  immediate24h: string;
  mediumTerm6m: string;
  longTerm5y: string;
  rippleEffect: string;
}

export interface DecisionRiskMatrix {
  shortTermImpactScore?: number; // 1 - 10
  shortTermImpactDesc?: string;
  longTermRiskScore?: number; // 1 - 10
  longTermRiskDesc?: string;
  reversibilityScore?: number; // 1 - 10
  reversibilityType?: ReversibilityType | string;
  confidencePercent: number; // e.g. 85
  riskLevel: RiskLevel;
  mitigationAdvice?: string;
}

export interface DecisionPerspectives {
  pragmatist: {
    stance: string;
    keyPoint?: string;
  };
  visionary: {
    stance: string;
    keyPoint?: string;
  };
  realist: {
    stance: string;
    keyPoint?: string;
  };
}

export interface DecisionDevilsAdvocate {
  blindSpot: string;
  counterArgument: string;
  stressTestQuestion?: string;
}

export interface ParsedDecision {
  quickSummary: string;
  options: DecisionOption[];
  recommendation: {
    chosenOption: string;
    because: string;
    utilityDelta?: string;
  };
  nextStep: string;
  safetyNotice?: string;
  confirmedChoice?: string;
  confirmedAtFormatted?: string;
  riskMatrix?: DecisionRiskMatrix;
  perspectives?: DecisionPerspectives;
  devilsAdvocate?: DecisionDevilsAdvocate;
  cognitiveBias?: CognitiveBiasAnalysis;
  temporalForecast?: TemporalForecast;
}

export type ProgressStatus = 'not_started' | 'in_progress' | 'completed' | 'blocked';

export interface ProgressLog {
  id: string;
  timestamp: number;
  dateTimeFormatted: string; // e.g. "Aug 17, 2026, 05:24 AM"
  status: ProgressStatus;
  note: string;
  progressPercent: number; // 0 to 100
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  parsedDecision?: ParsedDecision | null;
  botPersona?: string;
  botName?: string;
}

export interface SavedDecision {
  id: string;
  title: string;
  date: string;
  timestamp: number;
  parsedDecision: ParsedDecision;
  nextStepCompleted: boolean;
  completedAt?: number;
  completedAtFormatted?: string;
  confirmedChoice?: string;
  confirmedAt?: number;
  confirmedAtFormatted?: string;
  confirmedReason?: string;
  status: ProgressStatus;
  progressPercent: number;
  progressLogs: ProgressLog[];
  targetDate?: string;
  notes?: string;
}

export interface BotProfile {
  name: string;
  persona: string; // e.g. "Smart Friend", "Strict Coach", "Choice Genie", "Pragmatic Analyst", "Gentle Guide"
  description: string;
}

// ----------------------------------------------------------------------
// 1. VOTING FEATURE TYPES
// ----------------------------------------------------------------------
export type VotingMethod = 'single_choice' | 'ranked_choice' | 'point_allocation';

export interface SimulatedVoter {
  id: string;
  name: string;
  role: string; // e.g., "Product Lead", "Engineering", "Finance", "End User"
  avatarColor: string;
  voteChoice?: string; // option name
  rankedChoices?: string[]; // ordered option names
  allocatedPoints?: Record<string, number>; // optionName -> points (sum = 100)
  comment?: string;
}

export interface VotingPoll {
  id: string;
  decisionId?: string;
  title: string;
  description?: string;
  options: string[];
  votingMethod: VotingMethod;
  pointsBudget?: number; // default 100
  createdAt: number;
  createdAtFormatted: string;
  voters: SimulatedVoter[];
  status: 'open' | 'closed';
}

// ----------------------------------------------------------------------
// 2. SCALES & MULTI-CRITERIA DECISION ANALYSIS (MCDA) TYPES
// ----------------------------------------------------------------------
export interface ScaleCriterion {
  id: string;
  name: string;
  description?: string;
  weight: number; // 1 to 5 multiplier (importance)
  higherIsBetter: boolean; // true = higher score is good (e.g. ROI), false = higher is bad (e.g. stress/cost)
}

export interface OptionScaleScore {
  optionName: string;
  scores: Record<string, number>; // criterionId -> rating (1 to 10)
  totalWeightedScore: number; // calculated 0 to 100
}

export interface ScaleEvaluation {
  id: string;
  decisionId?: string;
  title: string;
  options: string[];
  criteria: ScaleCriterion[];
  optionScores: OptionScaleScore[];
  createdAt: number;
  createdAtFormatted: string;
  notes?: string;
}

// ----------------------------------------------------------------------
// 3. DIARY & DECISION JOURNAL TYPES
// ----------------------------------------------------------------------
export type DecisionMood = 'confident' | 'anxious' | 'neutral' | 'optimistic' | 'hesitant' | 'pressured' | 'peaceful';

export interface RetrospectiveReview {
  reviewedAt: number;
  reviewedAtFormatted: string;
  daysAfterDecision: number;
  actualOutcome: string;
  outcomeRating: number; // 1 to 5 stars
  wasRightChoice: 'yes' | 'partially' | 'no' | 'too_early';
  lessonsLearned: string;
  wouldChooseAgain: boolean;
}

export interface JournalEntry {
  id: string;
  decisionId?: string;
  decisionTitle: string;
  chosenOption?: string;
  date: string;
  timestamp: number;
  mood: DecisionMood;
  confidenceAtTime: number; // 1 to 100
  tags: string[];
  contextReasoning: string;
  assumptionsMade: string[];
  fearsAndRisks: string;
  retrospective?: RetrospectiveReview;
}

// ----------------------------------------------------------------------
// 4. FINANCIAL TRACKING & ROI TYPES
// ----------------------------------------------------------------------
export interface FinancialOptionCost {
  optionName: string;
  upfrontCost: number;
  recurringMonthlyCost: number;
  expectedMonthlyReturnOrSavings: number;
  implementationWeeks: number;
  oneYearNetCostOrBenefit: number;
  threeYearNetCostOrBenefit: number;
  paybackPeriodMonths: number | null; // null if never pays back
  riskContingencyPercent: number; // e.g. 15%
}

export interface ActualExpenseLog {
  id: string;
  date: string;
  timestamp: number;
  description: string;
  amount: number;
  category: 'upfront' | 'recurring' | 'unforeseen' | 'savings';
}

export interface FinancialDecisionModel {
  id: string;
  decisionId?: string;
  title: string;
  currency: string; // e.g. '$', '€', '£'
  budgetCap?: number;
  options: FinancialOptionCost[];
  actualExpenses: ActualExpenseLog[];
  createdAt: number;
  createdAtFormatted: string;
  notes?: string;
}

// ----------------------------------------------------------------------
// 5. COIN TOSS & GUT-CHECK RANDOMIZER TYPES
// ----------------------------------------------------------------------
export type CoinFace = 'heads' | 'tails';
export type CoinTossMode = 'single' | 'best_of_3' | 'best_of_5';
export type GutCheckReaction = 'relief' | 'disappointment' | 'indifferent';

export interface CoinTossResult {
  id: string;
  decisionId?: string;
  timestamp: number;
  timestampFormatted: string;
  optionHeads: string;
  optionTails: string;
  mode: CoinTossMode;
  flips: CoinFace[];
  winnerFace: CoinFace;
  winningOption: string;
  gutCheck?: {
    reaction: GutCheckReaction;
    reflectedChoice: string;
    note?: string;
  };
}
export type DashboardActiveTab = 'chat' | 'voting' | 'scales' | 'journal' | 'financials' | 'cointoss';

// ----------------------------------------------------------------------
// 6. AUTHENTICATION & USER ACCOUNT TYPES
// ----------------------------------------------------------------------
export interface UserAccount {
  id: string;
  username: string; // e.g. "user"
  password: string; // e.g. "123"
  displayName: string;
  email: string;
  avatarColor?: string;
  createdAt: number;
  lastLoginAt?: number;
}
