import React, { useState, useEffect } from 'react';
import { ParsedDecision, DecisionOption, ProgressStatus } from '../types';
import { 
  X, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  Check, 
  Target,
  ListTodo,
  FileEdit
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ConfirmChoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  decision: ParsedDecision | null;
  selectedOptionName: string;
  existingConfirmedChoice?: string;
  onConfirmChoice: (
    decision: ParsedDecision,
    optionName: string,
    details: {
      confirmedDateFormatted: string;
      timestamp: number;
      reason: string;
      customNextStep: string;
      initialStatus: ProgressStatus;
      initialPercent: number;
    }
  ) => void;
}

export const ConfirmChoiceModal: React.FC<ConfirmChoiceModalProps> = ({
  isOpen,
  onClose,
  decision,
  selectedOptionName,
  existingConfirmedChoice,
  onConfirmChoice,
}) => {
  if (!isOpen || !decision) return null;

  const getNowISOString = () => {
    const now = new Date();
    const offset = now.getTimezoneOffset() * 60000;
    const localTime = new Date(now.getTime() - offset);
    return localTime.toISOString().slice(0, 16);
  };

  const [chosenOption, setChosenOption] = useState<string>(
    selectedOptionName || decision.recommendation.chosenOption || decision.options[0]?.name || ''
  );
  const [dateTime, setDateTime] = useState<string>(getNowISOString());
  const [reason, setReason] = useState<string>('');
  const [nextStep, setNextStep] = useState<string>(decision.nextStep || '');
  const [initialStatus, setInitialStatus] = useState<ProgressStatus>('in_progress');
  const [initialPercent, setInitialPercent] = useState<number>(25);

  useEffect(() => {
    if (selectedOptionName) {
      setChosenOption(selectedOptionName);
    } else if (decision) {
      setChosenOption(decision.recommendation.chosenOption || decision.options[0]?.name || '');
    }
    if (decision) {
      setNextStep(decision.nextStep || '');
    }
  }, [selectedOptionName, decision]);

  const selectedOptionObj: DecisionOption | undefined = decision.options.find(
    (o) => o.name.toLowerCase() === chosenOption.toLowerCase()
  ) || decision.options[0];

  const isRecommended = decision.recommendation.chosenOption.toLowerCase().includes(chosenOption.toLowerCase());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedDate = new Date(dateTime);
    const timestamp = isNaN(parsedDate.getTime()) ? Date.now() : parsedDate.getTime();
    
    const formatted = parsedDate.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    onConfirmChoice(decision, chosenOption, {
      confirmedDateFormatted: formatted,
      timestamp,
      reason: reason.trim(),
      customNextStep: nextStep.trim() || decision.nextStep,
      initialStatus,
      initialPercent,
    });

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    onClose();
  };

  const setQuickTime = (type: 'now' | 'yesterday') => {
    const d = new Date();
    if (type === 'yesterday') d.setDate(d.getDate() - 1);
    const offset = d.getTimezoneOffset() * 60000;
    const localTime = new Date(d.getTime() - offset);
    setDateTime(localTime.toISOString().slice(0, 16));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-white border border-gray-100 rounded-2xl shadow-2xl p-6 sm:p-8 text-[#111827] relative animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-3 mb-5">
          <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-semibold text-gray-900">
              Confirm Decision Choice
            </h2>
            <p className="text-xs text-gray-500">
              Lock in your selected path and record it onto the Progress Report
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Select between options */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Select Your Choice to Confirm
            </label>
            <div className="space-y-2">
              {decision.options.map((opt, idx) => {
                const letter = String.fromCharCode(65 + idx);
                const isSelected = chosenOption.toLowerCase() === opt.name.toLowerCase();
                const isBotPick = decision.recommendation.chosenOption.toLowerCase().includes(opt.name.toLowerCase());

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setChosenOption(opt.name)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50 text-gray-800'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          isSelected
                            ? 'bg-emerald-600 text-white'
                            : 'bg-gray-200 text-gray-700'
                        }`}
                      >
                        {letter}
                      </span>
                      <div>
                        <span className="font-semibold text-sm block">
                          {opt.name}
                        </span>
                        <span className="text-[11px] text-gray-500">
                          {opt.pros[0] ? `+ ${opt.pros[0]}` : ''}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      {isBotPick && (
                        <span className="text-[10px] uppercase font-bold tracking-wider bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                          Bot Pick
                        </span>
                      )}
                      {isSelected ? (
                        <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 rounded-full border border-gray-300" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Time Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                Confirmation Date & Time
              </label>
              <div className="flex items-center space-x-1 text-[11px]">
                <button
                  type="button"
                  onClick={() => setQuickTime('now')}
                  className="px-2 py-0.5 rounded bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium"
                >
                  Now
                </button>
                <button
                  type="button"
                  onClick={() => setQuickTime('yesterday')}
                  className="px-2 py-0.5 rounded bg-gray-100 hover:bg-gray-200 text-gray-600"
                >
                  Yesterday
                </button>
              </div>
            </div>
            <input
              type="datetime-local"
              required
              value={dateTime}
              onChange={(e) => setDateTime(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-mono"
            />
          </div>

          {/* Reason / Decision Rationale (Optional) */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <FileEdit className="w-3.5 h-3.5 text-gray-500" />
              Decision Notes & Rationale (Optional)
            </label>
            <textarea
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder={`Why did you choose ${chosenOption}? (e.g., best budget fit, matches target timeline, higher reliability...)`}
              className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 placeholder:text-gray-400 resize-none"
            />
          </div>

          {/* Next Action Item */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <ListTodo className="w-3.5 h-3.5 text-blue-600" />
              Initial Action Item / Next Step
            </label>
            <input
              type="text"
              required
              value={nextStep}
              onChange={(e) => setNextStep(e.target.value)}
              placeholder="e.g. Schedule call with client, order item, register account..."
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="mt-6 flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Choice & Log to Report</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
