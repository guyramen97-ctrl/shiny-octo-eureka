import React, { useState } from 'react';
import { ScaleEvaluation, ScaleCriterion, OptionScaleScore, SavedDecision, ParsedDecision } from '../types';
import {
  Sliders,
  Plus,
  Trash2,
  Award,
  Sparkles,
  Layers,
  TrendingUp,
  Check,
  Scale,
  Target,
  ArrowRight,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ScalesDashboardProps {
  evaluations: ScaleEvaluation[];
  onSaveEvaluations: (evals: ScaleEvaluation[]) => void;
  savedDecisions: SavedDecision[];
  onCreateFromDecision?: (decision: ParsedDecision) => void;
}

const PRESET_CRITERIA_SUITES: Record<string, { label: string; criteria: Omit<ScaleCriterion, 'id'>[] }> = {
  product_tech: {
    label: 'Product & Tech Strategy',
    criteria: [
      { name: 'Business Value & Impact', weight: 5, higherIsBetter: true },
      { name: 'Ease of Implementation', weight: 4, higherIsBetter: true },
      { name: 'User Delight / UX', weight: 4, higherIsBetter: true },
      { name: 'Technical Debt Risk', weight: 3, higherIsBetter: false },
      { name: 'Maintenance Cost', weight: 3, higherIsBetter: false },
    ],
  },
  career_personal: {
    label: 'Career & Life Strategy',
    criteria: [
      { name: 'Growth & Skill Potential', weight: 5, higherIsBetter: true },
      { name: 'Financial Compensation', weight: 4, higherIsBetter: true },
      { name: 'Work-Life Balance', weight: 5, higherIsBetter: true },
      { name: 'Stress & Burnout Risk', weight: 4, higherIsBetter: false },
      { name: 'Culture & Alignment', weight: 3, higherIsBetter: true },
    ],
  },
  business_roi: {
    label: 'Business Investment & ROI',
    criteria: [
      { name: 'Projected 3-Year ROI', weight: 5, higherIsBetter: true },
      { name: 'Speed to Market / Break-Even', weight: 4, higherIsBetter: true },
      { name: 'Strategic Alignment', weight: 4, higherIsBetter: true },
      { name: 'Capital Risk Exposure', weight: 4, higherIsBetter: false },
      { name: 'Operational Friction', weight: 3, higherIsBetter: false },
    ],
  },
};

export const ScalesDashboard: React.FC<ScalesDashboardProps> = ({
  evaluations,
  onSaveEvaluations,
  savedDecisions,
}) => {
  const [selectedEvalId, setSelectedEvalId] = useState<string>(evaluations[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(evaluations.length === 0);

  // New Scale Evaluation Form State
  const [newTitle, setNewTitle] = useState('');
  const [newOptions, setNewOptions] = useState<string[]>(['Option A: Cloud Solution', 'Option B: Self-Hosted Architecture']);
  const [selectedPreset, setSelectedPreset] = useState<string>('product_tech');
  const [customCriteria, setCustomCriteria] = useState<Omit<ScaleCriterion, 'id'>[]>(
    PRESET_CRITERIA_SUITES.product_tech.criteria
  );
  const [selectedDecisionId, setSelectedDecisionId] = useState('');

  const activeEval = evaluations.find((e) => e.id === selectedEvalId) || evaluations[0];

  const handleSelectDecision = (decisionId: string) => {
    setSelectedDecisionId(decisionId);
    const target = savedDecisions.find((d) => d.id === decisionId);
    if (target) {
      setNewTitle(`Scale Matrix: ${target.parsedDecision.quickSummary || target.title}`);
      setNewOptions(target.parsedDecision.options.map((o) => o.name));
    }
  };

  const handleApplyPreset = (presetKey: string) => {
    setSelectedPreset(presetKey);
    if (PRESET_CRITERIA_SUITES[presetKey]) {
      setCustomCriteria(PRESET_CRITERIA_SUITES[presetKey].criteria);
    }
  };

  const handleAddCriterion = () => {
    setCustomCriteria((prev) => [
      ...prev,
      { name: `Criterion ${prev.length + 1}`, weight: 3, higherIsBetter: true },
    ]);
  };

  const handleRemoveCriterion = (idx: number) => {
    if (customCriteria.length <= 1) return;
    setCustomCriteria((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleCreateEvaluation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const filteredOptions = newOptions.map((o) => o.trim()).filter(Boolean);
    if (filteredOptions.length < 2) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const criteriaWithIds: ScaleCriterion[] = customCriteria.map((c, i) => ({
      ...c,
      id: `crit-${now}-${i}`,
    }));

    // Initial default scores (7 out of 10 for all)
    const initialOptionScores: OptionScaleScore[] = filteredOptions.map((opt) => {
      const scores: Record<string, number> = {};
      criteriaWithIds.forEach((c) => {
        scores[c.id] = 7;
      });
      return {
        optionName: opt,
        scores,
        totalWeightedScore: 70,
      };
    });

    const newEval: ScaleEvaluation = {
      id: `eval-${now}`,
      decisionId: selectedDecisionId || undefined,
      title: newTitle.trim(),
      options: filteredOptions,
      criteria: criteriaWithIds,
      optionScores: initialOptionScores,
      createdAt: now,
      createdAtFormatted: formattedNow,
    };

    // Calculate initial weighted scores
    const computed = computeAllWeightedScores(newEval);
    const updated = [computed, ...evaluations];
    onSaveEvaluations(updated);
    setSelectedEvalId(newEval.id);
    setIsCreatingNew(false);
    setNewTitle('');

    confetti({
      particleCount: 35,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const computeAllWeightedScores = (ev: ScaleEvaluation): ScaleEvaluation => {
    const totalWeight = ev.criteria.reduce((sum, c) => sum + c.weight, 0) || 1;

    const updatedScores = ev.optionScores.map((optScore) => {
      let weightedSum = 0;
      ev.criteria.forEach((crit) => {
        const rawScore = optScore.scores[crit.id] ?? 5; // 1 to 10
        // If lower is better (e.g. cost), reverse score: 10 becomes 1, 1 becomes 10
        const effectiveScore = crit.higherIsBetter ? rawScore : 11 - rawScore;
        weightedSum += effectiveScore * crit.weight;
      });

      // Scale to 0 - 100
      const totalWeightedScore = Math.round((weightedSum / (totalWeight * 10)) * 100);
      return {
        ...optScore,
        totalWeightedScore,
      };
    });

    return {
      ...ev,
      optionScores: updatedScores,
    };
  };

  const handleScoreChange = (optionName: string, criterionId: string, value: number) => {
    if (!activeEval) return;

    const updatedOptionScores = activeEval.optionScores.map((optScore) => {
      if (optScore.optionName !== optionName) return optScore;
      return {
        ...optScore,
        scores: {
          ...optScore.scores,
          [criterionId]: value,
        },
      };
    });

    const updatedEval = computeAllWeightedScores({
      ...activeEval,
      optionScores: updatedOptionScores,
    });

    const updatedEvaluations = evaluations.map((e) => (e.id === activeEval.id ? updatedEval : e));
    onSaveEvaluations(updatedEvaluations);
  };

  const handleDeleteEval = (id: string) => {
    const updated = evaluations.filter((e) => e.id !== id);
    onSaveEvaluations(updated);
    if (selectedEvalId === id) {
      setSelectedEvalId(updated[0]?.id || '');
      if (updated.length === 0) setIsCreatingNew(true);
    }
  };

  // Find winner
  const getWinner = () => {
    if (!activeEval || activeEval.optionScores.length === 0) return null;
    let highest = -1;
    let winnerName = '';
    activeEval.optionScores.forEach((opt) => {
      if (opt.totalWeightedScore > highest) {
        highest = opt.totalWeightedScore;
        winnerName = opt.optionName;
      }
    });
    return { name: winnerName, score: highest };
  };

  const winner = getWinner();

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-8 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
        <div>
          <div className="flex items-center space-x-2 text-blue-600 text-xs font-bold uppercase tracking-wider mb-1">
            <Sliders className="w-4 h-4" />
            <span>Multi-Criteria Decision Analysis (MCDA)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 tracking-tight">
            Decision Scales & Weighted Matrix
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
            Evaluate options systematically across customized multi-dimensional criteria and weights.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingNew(!isCreatingNew)}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm shrink-0 self-start sm:self-auto"
        >
          {isCreatingNew ? (
            <span>View Active Matrix</span>
          ) : (
            <>
              <Plus className="w-4 h-4" />
              <span>Create New Scale Matrix</span>
            </>
          )}
        </button>
      </div>

      {/* CREATE NEW SCALE MATRIX FORM */}
      {isCreatingNew ? (
        <form
          onSubmit={handleCreateEvaluation}
          className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-6"
        >
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
              <Scale className="w-4 h-4 text-blue-600" />
              <span>Setup Multi-Criteria Decision Matrix</span>
            </h3>
            {savedDecisions.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-500">Import from:</span>
                <select
                  value={selectedDecisionId}
                  onChange={(e) => handleSelectDecision(e.target.value)}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Select Saved Decision --</option>
                  {savedDecisions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Evaluation Title *
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Architecture Choice: Microservices vs Modular Monolith"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Options List */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-2">
                Options to Compare (Minimum 2)
              </label>
              <div className="space-y-2">
                {newOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-gray-100 text-gray-700 font-bold text-xs flex items-center justify-center shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const copy = [...newOptions];
                        copy[idx] = e.target.value;
                        setNewOptions(copy);
                      }}
                      className="flex-1 px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      required
                    />
                    {newOptions.length > 2 && (
                      <button
                        type="button"
                        onClick={() => setNewOptions(newOptions.filter((_, i) => i !== idx))}
                        className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Criteria Presets */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-2">
                Evaluation Criteria Framework
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                {Object.entries(PRESET_CRITERIA_SUITES).map(([key, suite]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => handleApplyPreset(key)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      selectedPreset === key
                        ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-1 ring-blue-600'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className="font-semibold text-xs mb-0.5">{suite.label}</div>
                    <p className="text-[11px] text-gray-500">{suite.criteria.length} calibrated metrics</p>
                  </button>
                ))}
              </div>

              {/* Custom Criteria Breakdown Table */}
              <div className="space-y-2 bg-gray-50 p-4 rounded-xl border border-gray-200">
                <div className="text-xs font-bold text-gray-700 uppercase tracking-wide mb-2 flex items-center justify-between">
                  <span>Criteria & Importance Weights</span>
                  <span className="text-[10px] text-gray-400 font-normal">Weight: 1 (Minor) to 5 (Critical)</span>
                </div>
                {customCriteria.map((crit, idx) => (
                  <div key={idx} className="flex items-center space-x-2 bg-white p-2 rounded-lg border border-gray-200">
                    <input
                      type="text"
                      value={crit.name}
                      onChange={(e) => {
                        const copy = [...customCriteria];
                        copy[idx].name = e.target.value;
                        setCustomCriteria(copy);
                      }}
                      className="flex-1 px-2 py-1 text-xs border border-gray-200 rounded"
                    />

                    {/* Weight Dropdown */}
                    <div className="flex items-center space-x-1">
                      <span className="text-[10px] text-gray-500 font-medium">Weight:</span>
                      <select
                        value={crit.weight}
                        onChange={(e) => {
                          const copy = [...customCriteria];
                          copy[idx].weight = parseInt(e.target.value);
                          setCustomCriteria(copy);
                        }}
                        className="text-xs px-2 py-1 border border-gray-200 rounded bg-gray-50"
                      >
                        <option value={1}>1x (Low)</option>
                        <option value={2}>2x (Medium)</option>
                        <option value={3}>3x (Standard)</option>
                        <option value={4}>4x (High)</option>
                        <option value={5}>5x (Critical)</option>
                      </select>
                    </div>

                    {/* Higher is Better Toggle */}
                    <button
                      type="button"
                      onClick={() => {
                        const copy = [...customCriteria];
                        copy[idx].higherIsBetter = !copy[idx].higherIsBetter;
                        setCustomCriteria(copy);
                      }}
                      className={`text-[10px] px-2 py-1 rounded font-medium border ${
                        crit.higherIsBetter
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}
                    >
                      {crit.higherIsBetter ? 'Higher is Better' : 'Lower is Better (Risk/Cost)'}
                    </button>

                    {customCriteria.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveCriterion(idx)}
                        className="p-1 text-gray-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}

                <button
                  type="button"
                  onClick={handleAddCriterion}
                  className="mt-2 text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Custom Criterion</span>
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
            {evaluations.length > 0 && (
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              Generate Scale Matrix
            </button>
          </div>
        </form>
      ) : null}

      {/* ACTIVE SCALE MATRIX VIEW */}
      {evaluations.length > 0 && activeEval && !isCreatingNew ? (
        <div className="space-y-6">
          {/* Multi-Matrix selector tabs */}
          {evaluations.length > 1 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {evaluations.map((e) => (
                <button
                  key={e.id}
                  onClick={() => setSelectedEvalId(e.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                    selectedEvalId === e.id
                      ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                      : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {e.title.length > 30 ? e.title.substring(0, 30) + '...' : e.title}
                </button>
              ))}
            </div>
          )}

          {/* Scale Evaluation Container */}
          <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
              <div>
                <span className="text-xs text-gray-400 font-mono">
                  Matrix Created {activeEval.createdAtFormatted}
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mt-0.5">
                  {activeEval.title}
                </h3>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleDeleteEval(activeEval.id)}
                  className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Delete Evaluation"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* WINNER SCORE BANNER */}
            {winner && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-blue-300 text-xs font-bold uppercase tracking-wider">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>Top-Ranked Option (Weighted Scale)</span>
                  </div>
                  <div className="text-lg font-bold text-white">
                    {winner.name}
                  </div>
                </div>

                <div className="flex items-center space-x-4 shrink-0">
                  <div className="text-right">
                    <div className="text-xs text-blue-200 uppercase font-semibold">Aggregate Score</div>
                    <div className="text-2xl font-bold font-mono text-white">{winner.score}%</div>
                  </div>
                </div>
              </div>
            )}

            {/* COMPARISON SLIDER MATRIX */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-blue-600" />
                  <span>Interactive Scale Ratings (1 to 10)</span>
                </h4>
                <span className="text-[11px] text-gray-500">
                  Adjust sliders in real-time to observe weighted outcome shifts
                </span>
              </div>

              {/* Side-by-Side Option Scoring Grid */}
              <div className={`grid gap-6 ${activeEval.options.length === 2 ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1 md:grid-cols-3'}`}>
                {activeEval.optionScores.map((optScore, optIdx) => {
                  const isTop = winner?.name === optScore.optionName;

                  return (
                    <div
                      key={optIdx}
                      className={`p-5 rounded-2xl border transition-all space-y-4 ${
                        isTop
                          ? 'bg-blue-50/40 border-blue-300 ring-2 ring-blue-500/20'
                          : 'bg-gray-50/60 border-gray-200'
                      }`}
                    >
                      {/* Option Header & Score */}
                      <div className="flex items-center justify-between pb-3 border-b border-gray-200/80">
                        <div className="flex items-center space-x-2">
                          <span className="w-6 h-6 rounded-full bg-gray-900 text-white font-bold text-xs flex items-center justify-center">
                            {String.fromCharCode(65 + optIdx)}
                          </span>
                          <span className="text-sm font-bold text-gray-900">
                            {optScore.optionName}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className={`text-base font-bold font-mono ${isTop ? 'text-blue-600' : 'text-gray-800'}`}>
                            {optScore.totalWeightedScore}%
                          </span>
                        </div>
                      </div>

                      {/* Criteria Sliders */}
                      <div className="space-y-3.5">
                        {activeEval.criteria.map((crit) => {
                          const currentVal = optScore.scores[crit.id] ?? 7;

                          return (
                            <div key={crit.id} className="space-y-1">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-700 font-medium flex items-center gap-1">
                                  <span>{crit.name}</span>
                                  <span className="text-[10px] text-gray-400 font-mono">({crit.weight}x)</span>
                                </span>
                                <span className="font-bold text-gray-900 font-mono">{currentVal}/10</span>
                              </div>

                              <input
                                type="range"
                                min={1}
                                max={10}
                                value={currentVal}
                                onChange={(e) =>
                                  handleScoreChange(optScore.optionName, crit.id, parseInt(e.target.value))
                                }
                                className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                              />

                              <div className="flex justify-between text-[9px] text-gray-400 font-mono">
                                <span>{crit.higherIsBetter ? 'Low' : 'Favorable'}</span>
                                <span>{crit.higherIsBetter ? 'High' : 'Severe'}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
