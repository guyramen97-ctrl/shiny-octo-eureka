import React, { useState } from 'react';
import { X, Plus, Trash2, Layers, Sparkles } from 'lucide-react';

interface StructuredDecisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (promptText: string) => void;
}

export const StructuredDecisionModal: React.FC<StructuredDecisionModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [dilemma, setDilemma] = useState('');
  const [optionA, setOptionA] = useState({ name: '', details: '' });
  const [optionB, setOptionB] = useState({ name: '', details: '' });
  const [includeOptionC, setIncludeOptionC] = useState(false);
  const [optionC, setOptionC] = useState({ name: '', details: '' });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dilemma.trim() || !optionA.name.trim() || !optionB.name.trim()) return;

    let formatted = `Decision Dilemma: ${dilemma.trim()}\n\n`;
    formatted += `Option A: ${optionA.name.trim()}`;
    if (optionA.details.trim()) formatted += ` (${optionA.details.trim()})`;
    formatted += `\n\nOption B: ${optionB.name.trim()}`;
    if (optionB.details.trim()) formatted += ` (${optionB.details.trim()})`;

    if (includeOptionC && optionC.name.trim()) {
      formatted += `\n\nOption C: ${optionC.name.trim()}`;
      if (optionC.details.trim()) formatted += ` (${optionC.details.trim()})`;
    }

    formatted += `\n\nPlease help me decide with pros, cons, recommendation, and next step based strictly on these details.`;

    onSubmit(formatted);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl bg-white border border-gray-100 rounded-2xl shadow-xl p-6 sm:p-8 text-gray-900 relative animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-sm">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-gray-900">
              Structured Decision Builder
            </h2>
            <p className="text-xs text-gray-500">
              Define your dilemma and options with key trade-offs
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Dilemma Summary */}
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1.5">
              1. What is the core dilemma or decision?
            </label>
            <input
              type="text"
              required
              value={dilemma}
              onChange={(e) => setDilemma(e.target.value)}
              placeholder="e.g. Choosing between upgrading office chair vs keeping current setup"
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-gray-400"
            />
          </div>

          {/* Option A */}
          <div className="p-4 rounded-xl bg-gray-50/70 border border-gray-200/80 space-y-2.5">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-gray-900 text-white text-xs font-bold flex items-center justify-center">
                A
              </span>
              <span className="text-xs font-semibold text-gray-800">Option A</span>
            </div>
            <input
              type="text"
              required
              value={optionA.name}
              onChange={(e) => setOptionA({ ...optionA, name: e.target.value })}
              placeholder="Option Name (e.g. Buy Pro-Ergo Model X)"
              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <textarea
              rows={2}
              value={optionA.details}
              onChange={(e) => setOptionA({ ...optionA, details: e.target.value })}
              placeholder="Key details, benefits, drawbacks you know (e.g. $1,200 cost, 12-yr warranty, relieves lower back fatigue)"
              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none placeholder:text-gray-400"
            />
          </div>

          {/* Option B */}
          <div className="p-4 rounded-xl bg-gray-50/70 border border-gray-200/80 space-y-2.5">
            <div className="flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-gray-200 text-gray-700 text-xs font-bold flex items-center justify-center">
                B
              </span>
              <span className="text-xs font-semibold text-gray-800">Option B</span>
            </div>
            <input
              type="text"
              required
              value={optionB.name}
              onChange={(e) => setOptionB({ ...optionB, name: e.target.value })}
              placeholder="Option Name (e.g. Keep Current Setup)"
              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <textarea
              rows={2}
              value={optionB.details}
              onChange={(e) => setOptionB({ ...optionB, details: e.target.value })}
              placeholder="Key details, benefits, drawbacks you know (e.g. $0 cost, no waste, but continued back fatigue)"
              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none placeholder:text-gray-400"
            />
          </div>

          {/* Option C (Optional) */}
          {includeOptionC ? (
            <div className="p-4 rounded-xl bg-gray-50/70 border border-gray-200/80 space-y-2.5 relative">
              <button
                type="button"
                onClick={() => setIncludeOptionC(false)}
                className="absolute top-3.5 right-3.5 text-gray-400 hover:text-rose-500 text-xs"
                title="Remove Option C"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <div className="flex items-center space-x-2">
                <span className="w-6 h-6 rounded-full bg-gray-200 text-gray-700 text-xs font-bold flex items-center justify-center">
                  C
                </span>
                <span className="text-xs font-semibold text-gray-800">Option C (Optional)</span>
              </div>
              <input
                type="text"
                value={optionC.name}
                onChange={(e) => setOptionC({ ...optionC, name: e.target.value })}
                placeholder="Option Name (e.g. Buy a refurbished chair or cushion)"
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <textarea
                rows={2}
                value={optionC.details}
                onChange={(e) => setOptionC({ ...optionC, details: e.target.value })}
                placeholder="Key details, pros, cons"
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-gray-900 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none placeholder:text-gray-400"
              />
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIncludeOptionC(true)}
              className="w-full py-2.5 rounded-xl border border-dashed border-gray-200 text-gray-500 hover:text-gray-900 hover:border-gray-300 hover:bg-gray-50 transition-all text-xs font-medium flex items-center justify-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add 3rd Option (Option C)</span>
            </button>
          )}

          {/* Submit */}
          <div className="mt-6 flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!dilemma.trim() || !optionA.name.trim() || !optionB.name.trim()}
              className="px-4 py-2 rounded-xl text-xs font-medium bg-gray-900 hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed text-white transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Analyze & Decide</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

