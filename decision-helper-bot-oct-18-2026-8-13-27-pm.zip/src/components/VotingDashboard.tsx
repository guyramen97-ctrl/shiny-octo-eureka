import React, { useState } from 'react';
import { VotingPoll, VotingMethod, SimulatedVoter, SavedDecision, ParsedDecision } from '../types';
import {
  Vote,
  Plus,
  Trash2,
  Users,
  CheckCircle2,
  Award,
  BarChart2,
  Sliders,
  Sparkles,
  Share2,
  Check,
  RefreshCw,
  TrendingUp,
  UserPlus,
  HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface VotingDashboardProps {
  polls: VotingPoll[];
  onSavePolls: (polls: VotingPoll[]) => void;
  savedDecisions: SavedDecision[];
  onCreateFromDecision?: (decision: ParsedDecision) => void;
}

const DEFAULT_STAKEHOLDER_PRESETS = [
  { name: 'Alex (Product Lead)', role: 'Product', avatarColor: 'bg-blue-600' },
  { name: 'Sarah (Lead Engineer)', role: 'Engineering', avatarColor: 'bg-emerald-600' },
  { name: 'Marcus (Finance / CFO)', role: 'Finance', avatarColor: 'bg-amber-600' },
  { name: 'Elena (UX Designer)', role: 'Design', avatarColor: 'bg-purple-600' },
  { name: 'David (Customer Success)', role: 'Ops', avatarColor: 'bg-rose-600' },
];

export const VotingDashboard: React.FC<VotingDashboardProps> = ({
  polls,
  onSavePolls,
  savedDecisions,
}) => {
  const [selectedPollId, setSelectedPollId] = useState<string>(polls[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(polls.length === 0);

  // New poll form state
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newOptions, setNewOptions] = useState<string[]>(['Option A: Build In-House', 'Option B: Buy Off-The-Shelf']);
  const [newMethod, setNewMethod] = useState<VotingMethod>('single_choice');
  const [selectedDecisionId, setSelectedDecisionId] = useState('');

  // User voting state in active poll
  const [userVoteChoice, setUserVoteChoice] = useState<string>('');
  const [userRankedChoices, setUserRankedChoices] = useState<string[]>([]);
  const [userPoints, setUserPoints] = useState<Record<string, number>>({});
  const [userVoterName, setUserVoterName] = useState('You (Decision Maker)');
  const [copiedLink, setCopiedLink] = useState(false);

  const activePoll = polls.find((p) => p.id === selectedPollId) || polls[0];

  // Populate from a selected saved decision
  const handleSelectDecisionForPoll = (decisionId: string) => {
    setSelectedDecisionId(decisionId);
    const target = savedDecisions.find((d) => d.id === decisionId);
    if (target) {
      setNewTitle(`Team Vote: ${target.parsedDecision.quickSummary || target.title}`);
      setNewOptions(target.parsedDecision.options.map((o) => o.name));
    }
  };

  const handleAddOptionField = () => {
    setNewOptions((prev) => [...prev, `Option ${String.fromCharCode(65 + prev.length)}`]);
  };

  const handleRemoveOptionField = (idx: number) => {
    if (newOptions.length <= 2) return;
    setNewOptions((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleCreatePoll = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const filteredOptions = newOptions.map((o) => o.trim()).filter(Boolean);
    if (filteredOptions.length < 2) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const newPoll: VotingPoll = {
      id: `poll-${now}`,
      decisionId: selectedDecisionId || undefined,
      title: newTitle.trim(),
      description: newDesc.trim() || undefined,
      options: filteredOptions,
      votingMethod: newMethod,
      pointsBudget: 100,
      createdAt: now,
      createdAtFormatted: formattedNow,
      voters: [],
      status: 'open',
    };

    const updated = [newPoll, ...polls];
    onSavePolls(updated);
    setSelectedPollId(newPoll.id);
    setIsCreatingNew(false);
    setNewTitle('');
    setNewDesc('');
    setNewOptions(['Option A', 'Option B']);

    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleDeletePoll = (pollId: string) => {
    const updated = polls.filter((p) => p.id !== pollId);
    onSavePolls(updated);
    if (selectedPollId === pollId) {
      setSelectedPollId(updated[0]?.id || '');
      if (updated.length === 0) setIsCreatingNew(true);
    }
  };

  // Cast User Vote
  const handleCastUserVote = () => {
    if (!activePoll) return;

    const existingVoterIdx = activePoll.voters.findIndex((v) => v.name === userVoterName);
    const updatedVoter: SimulatedVoter = {
      id: existingVoterIdx >= 0 ? activePoll.voters[existingVoterIdx].id : `voter-${Date.now()}`,
      name: userVoterName,
      role: 'Decision Lead',
      avatarColor: 'bg-blue-600',
      voteChoice: activePoll.votingMethod === 'single_choice' ? userVoteChoice : undefined,
      rankedChoices: activePoll.votingMethod === 'ranked_choice' ? userRankedChoices : undefined,
      allocatedPoints: activePoll.votingMethod === 'point_allocation' ? userPoints : undefined,
    };

    let newVoters: SimulatedVoter[];
    if (existingVoterIdx >= 0) {
      newVoters = [...activePoll.voters];
      newVoters[existingVoterIdx] = updatedVoter;
    } else {
      newVoters = [...activePoll.voters, updatedVoter];
    }

    const updatedPolls = polls.map((p) => (p.id === activePoll.id ? { ...p, voters: newVoters } : p));
    onSavePolls(updatedPolls);

    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.8 },
    });
  };

  // Add a Simulated Stakeholder Voter
  const handleAddStakeholderVote = (preset: typeof DEFAULT_STAKEHOLDER_PRESETS[0]) => {
    if (!activePoll) return;
    if (activePoll.voters.some((v) => v.name === preset.name)) return;

    let choice: string | undefined;
    let ranked: string[] | undefined;
    let allocated: Record<string, number> | undefined;

    const opts = activePoll.options;
    if (activePoll.votingMethod === 'single_choice') {
      choice = opts[Math.floor(Math.random() * opts.length)];
    } else if (activePoll.votingMethod === 'ranked_choice') {
      ranked = [...opts].sort(() => Math.random() - 0.5);
    } else if (activePoll.votingMethod === 'point_allocation') {
      allocated = {};
      let remaining = 100;
      opts.forEach((opt, i) => {
        if (i === opts.length - 1) {
          allocated![opt] = remaining;
        } else {
          const val = Math.floor(Math.random() * (remaining / 1.5));
          allocated![opt] = val;
          remaining -= val;
        }
      });
    }

    const newVoter: SimulatedVoter = {
      id: `voter-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: preset.name,
      role: preset.role,
      avatarColor: preset.avatarColor,
      voteChoice: choice,
      rankedChoices: ranked,
      allocatedPoints: allocated,
    };

    const newVoters = [...activePoll.voters, newVoter];
    const updatedPolls = polls.map((p) => (p.id === activePoll.id ? { ...p, voters: newVoters } : p));
    onSavePolls(updatedPolls);
  };

  const handleSimulateAllStakeholders = () => {
    if (!activePoll) return;
    DEFAULT_STAKEHOLDER_PRESETS.forEach((preset) => {
      handleAddStakeholderVote(preset);
    });
  };

  // Compute Results & Winner
  const calculateResults = () => {
    if (!activePoll || activePoll.voters.length === 0) {
      return { counts: {}, totalVotes: 0, winner: null, percentage: {}, consensusScore: 0 };
    }

    const totalVoters = activePoll.voters.length;
    const scores: Record<string, number> = {};
    activePoll.options.forEach((o) => (scores[o] = 0));

    if (activePoll.votingMethod === 'single_choice') {
      activePoll.voters.forEach((v) => {
        if (v.voteChoice && scores[v.voteChoice] !== undefined) {
          scores[v.voteChoice] += 1;
        }
      });
    } else if (activePoll.votingMethod === 'ranked_choice') {
      activePoll.voters.forEach((v) => {
        if (v.rankedChoices) {
          const n = v.rankedChoices.length;
          v.rankedChoices.forEach((choice, idx) => {
            if (scores[choice] !== undefined) {
              scores[choice] += n - idx; // Borda count weighting
            }
          });
        }
      });
    } else if (activePoll.votingMethod === 'point_allocation') {
      activePoll.voters.forEach((v) => {
        if (v.allocatedPoints) {
          Object.entries(v.allocatedPoints).forEach(([opt, pts]) => {
            if (scores[opt] !== undefined) {
              scores[opt] += Number(pts) || 0;
            }
          });
        }
      });
    }

    const totalScoreValue = Object.values(scores).reduce((a, b) => a + b, 0) || 1;
    const percentage: Record<string, number> = {};
    let topOption = activePoll.options[0];
    let topScore = -1;

    activePoll.options.forEach((opt) => {
      const pct = Math.round(((scores[opt] || 0) / totalScoreValue) * 100);
      percentage[opt] = pct;
      if ((scores[opt] || 0) > topScore) {
        topScore = scores[opt] || 0;
        topOption = opt;
      }
    });

    const consensusScore = percentage[topOption] || 0;

    return {
      counts: scores,
      totalVotes: totalVoters,
      winner: topScore > 0 ? topOption : null,
      percentage,
      consensusScore,
    };
  };

  const results = calculateResults();

  const handleCopySummary = () => {
    if (!activePoll) return;
    const lines = [
      `🗳️ Decision Voting Results: ${activePoll.title}`,
      `Method: ${activePoll.votingMethod.replace('_', ' ').toUpperCase()}`,
      `Total Voters: ${activePoll.voters.length}`,
      `Consensus Leader: ${results.winner || 'None'} (${results.percentage[results.winner || ''] || 0}%)`,
      '',
      'Breakdown:',
      ...activePoll.options.map((opt) => `- ${opt}: ${results.counts[opt] || 0} pts (${results.percentage[opt] || 0}%)`),
    ];
    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-8 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
        <div>
          <div className="flex items-center space-x-2 text-blue-600 text-xs font-bold uppercase tracking-wider mb-1">
            <Vote className="w-4 h-4" />
            <span>Decision Governance & Consensus</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 tracking-tight">
            Stakeholder Voting & Ballot Polls
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
            Conduct multi-option polls, simulate cross-functional stakeholder votes, and measure consensus.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingNew(!isCreatingNew)}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm shrink-0 self-start sm:self-auto"
        >
          {isCreatingNew ? (
            <span>View Active Polls</span>
          ) : (
            <>
              <Plus className="w-4 h-4" />
              <span>Create New Poll</span>
            </>
          )}
        </button>
      </div>

      {/* CREATE NEW POLL FORM */}
      {isCreatingNew ? (
        <form
          onSubmit={handleCreatePoll}
          className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-5"
        >
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
              <Vote className="w-4 h-4 text-blue-600" />
              <span>Create Stakeholder Decision Poll</span>
            </h3>
            {savedDecisions.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-500">Import from:</span>
                <select
                  value={selectedDecisionId}
                  onChange={(e) => handleSelectDecisionForPoll(e.target.value)}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Select Saved Decision --</option>
                  {savedDecisions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Poll Question / Decision Title *
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Which CRM platform should we migrate to?"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Context / Decision Rationale (Optional)
              </label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Key trade-offs, constraints, or voting deadline..."
                rows={2}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Voting Method Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-2">
                Voting Methodology
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setNewMethod('single_choice')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    newMethod === 'single_choice'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-1 ring-blue-600'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className="font-semibold text-xs mb-0.5">Single Choice (FPTP)</div>
                  <p className="text-[11px] text-gray-500">Each voter selects exactly one winning option.</p>
                </button>

                <button
                  type="button"
                  onClick={() => setNewMethod('ranked_choice')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    newMethod === 'ranked_choice'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-1 ring-blue-600'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className="font-semibold text-xs mb-0.5">Ranked Choice (Borda)</div>
                  <p className="text-[11px] text-gray-500">Rank options in order of preference.</p>
                </button>

                <button
                  type="button"
                  onClick={() => setNewMethod('point_allocation')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    newMethod === 'point_allocation'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-1 ring-blue-600'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className="font-semibold text-xs mb-0.5">100-Point Budget</div>
                  <p className="text-[11px] text-gray-500">Distribute 100 points based on confidence & conviction.</p>
                </button>
              </div>
            </div>

            {/* Options List */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-2">
                Options on Ballot (Minimum 2)
              </label>
              <div className="space-y-2">
                {newOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-gray-100 text-gray-700 font-bold text-xs flex items-center justify-center shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const copy = [...newOptions];
                        copy[idx] = e.target.value;
                        setNewOptions(copy);
                      }}
                      className="flex-1 px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      required
                    />
                    {newOptions.length > 2 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveOptionField(idx)}
                        className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={handleAddOptionField}
                className="mt-2.5 text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add another option</span>
              </button>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
            {polls.length > 0 && (
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              Launch Poll
            </button>
          </div>
        </form>
      ) : null}

      {/* POLL SELECTOR & ACTIVE POLL DASHBOARD */}
      {polls.length > 0 && activePoll && !isCreatingNew ? (
        <div className="space-y-6">
          {/* Poll Tab Strip if multiple polls */}
          {polls.length > 1 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {polls.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPollId(p.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                    selectedPollId === p.id
                      ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                      : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {p.title.length > 30 ? p.title.substring(0, 30) + '...' : p.title}
                </button>
              ))}
            </div>
          )}

          {/* Active Poll Main Card */}
          <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-6">
            {/* Poll Title & Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    {activePoll.votingMethod.replace('_', ' ').toUpperCase()}
                  </span>
                  <span className="text-xs text-gray-400 font-mono">
                    Created {activePoll.createdAtFormatted}
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mt-1">
                  {activePoll.title}
                </h3>
                {activePoll.description && (
                  <p className="text-xs text-gray-600 mt-1">{activePoll.description}</p>
                )}
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                <button
                  onClick={handleCopySummary}
                  className="px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 text-xs font-medium flex items-center space-x-1.5 transition-colors"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'Copied!' : 'Export Results'}</span>
                </button>

                <button
                  onClick={() => handleDeletePoll(activePoll.id)}
                  className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Delete Poll"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* LIVE TALLY & RESULTS BREAKDOWN */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: Real-Time Vote Bar Breakdown */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center gap-1.5">
                    <BarChart2 className="w-4 h-4 text-blue-600" />
                    <span>Live Vote Tally & Percentage</span>
                  </h4>
                  <span className="text-xs text-gray-500 font-mono">
                    {activePoll.voters.length} {activePoll.voters.length === 1 ? 'ballot' : 'ballots'} cast
                  </span>
                </div>

                <div className="space-y-3">
                  {activePoll.options.map((opt, idx) => {
                    const score = results.counts[opt] || 0;
                    const pct = results.percentage[opt] || 0;
                    const isWinner = results.winner === opt && score > 0;

                    return (
                      <div
                        key={idx}
                        className={`p-4 rounded-xl border transition-all ${
                          isWinner
                            ? 'bg-emerald-50/50 border-emerald-300 ring-1 ring-emerald-400/30'
                            : 'bg-gray-50/70 border-gray-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="w-5 h-5 rounded-full bg-gray-900 text-white font-bold text-[10px] flex items-center justify-center">
                              {String.fromCharCode(65 + idx)}
                            </span>
                            <span className="text-xs sm:text-sm font-semibold text-gray-900">
                              {opt}
                            </span>
                            {isWinner && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1">
                                <Award className="w-3 h-3" /> Leading
                              </span>
                            )}
                          </div>
                          <div className="text-xs font-mono font-bold text-gray-700">
                            {score} pts ({pct}%)
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isWinner ? 'bg-emerald-600' : 'bg-blue-600'
                            }`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Col: Consensus & Winner Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-blue-300 text-xs font-bold uppercase tracking-wider border-b border-white/10 pb-2">
                    <span className="flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4" /> Consensus Score
                    </span>
                    <span className="font-mono text-sm">{results.consensusScore}%</span>
                  </div>

                  {results.winner ? (
                    <div className="space-y-2 pt-2">
                      <span className="text-[11px] text-gray-300 uppercase tracking-wide">
                        Leading Option Choice
                      </span>
                      <div className="text-base sm:text-lg font-bold text-white leading-snug">
                        {results.winner}
                      </div>
                      <p className="text-xs text-blue-200 leading-relaxed">
                        Highest preference alignment across {activePoll.voters.length} stakeholder ballots.
                      </p>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-xs text-gray-400">
                      No ballots cast yet. Cast your vote below or simulate team members.
                    </div>
                  )}
                </div>

                {/* Quick simulate team members action */}
                <div className="pt-3 border-t border-white/10 space-y-2">
                  <button
                    onClick={handleSimulateAllStakeholders}
                    className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Simulate 5 Stakeholders</span>
                  </button>
                </div>
              </div>
            </div>

            {/* CAST YOUR VOTE SECTION */}
            <div className="p-5 rounded-2xl bg-blue-50/60 border border-blue-200/80 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  <span>Cast Your Vote / Ballot</span>
                </h4>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-600">Voting as:</span>
                  <input
                    type="text"
                    value={userVoterName}
                    onChange={(e) => setUserVoterName(e.target.value)}
                    className="text-xs px-2.5 py-1 rounded-lg border border-blue-200 bg-white font-medium text-gray-800"
                  />
                </div>
              </div>

              {/* Single Choice Voting */}
              {activePoll.votingMethod === 'single_choice' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {activePoll.options.map((opt, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setUserVoteChoice(opt)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        userVoteChoice === opt
                          ? 'border-blue-600 bg-white ring-2 ring-blue-500/20 text-blue-950 font-semibold shadow-2xs'
                          : 'border-blue-200/80 bg-white/70 hover:bg-white text-gray-700'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold flex items-center justify-center">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="text-xs">{opt}</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Point Allocation Voting (100 pts) */}
              {activePoll.votingMethod === 'point_allocation' && (
                <div className="space-y-3">
                  <p className="text-xs text-blue-900">
                    Allocate 100 points across the options according to your preference weight:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {activePoll.options.map((opt, idx) => (
                      <div key={idx} className="p-3 bg-white rounded-xl border border-blue-200/80 space-y-1.5">
                        <div className="flex justify-between text-xs">
                          <span className="font-semibold text-gray-800">{opt}</span>
                          <span className="font-bold text-blue-600 font-mono">
                            {userPoints[opt] || 0} pts
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={userPoints[opt] || 0}
                          onChange={(e) => {
                            setUserPoints({
                              ...userPoints,
                              [opt]: parseInt(e.target.value) || 0,
                            });
                          }}
                          className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Submit Vote Button */}
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleCastUserVote}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm flex items-center space-x-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Submit My Ballot</span>
                </button>
              </div>
            </div>

            {/* STAKEHOLDERS VOTERS LOG */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-gray-500" />
                  <span>Voters & Stakeholder Roster ({activePoll.voters.length})</span>
                </h4>

                {/* Add Individual Presets */}
                <div className="flex items-center space-x-1.5">
                  <span className="text-[11px] text-gray-400">Quick add:</span>
                  {DEFAULT_STAKEHOLDER_PRESETS.slice(0, 3).map((p, i) => (
                    <button
                      key={i}
                      onClick={() => handleAddStakeholderVote(p)}
                      disabled={activePoll.voters.some((v) => v.name === p.name)}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium disabled:opacity-40 transition-colors"
                    >
                      +{p.role}
                    </button>
                  ))}
                </div>
              </div>

              {activePoll.voters.length === 0 ? (
                <div className="text-center py-6 text-xs text-gray-400 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                  No individual votes registered yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {activePoll.voters.map((voter) => (
                    <div
                      key={voter.id}
                      className="p-3 bg-gray-50 rounded-xl border border-gray-200/80 flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div
                          className={`w-7 h-7 rounded-full text-white text-[10px] font-bold flex items-center justify-center ${
                            voter.avatarColor || 'bg-gray-700'
                          }`}
                        >
                          {voter.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-gray-900 leading-tight">
                            {voter.name}
                          </div>
                          <div className="text-[10px] text-gray-500">{voter.role}</div>
                        </div>
                      </div>

                      <div className="text-right">
                        {voter.voteChoice && (
                          <span className="text-[11px] font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                            {voter.voteChoice}
                          </span>
                        )}
                        {voter.allocatedPoints && (
                          <span className="text-[10px] font-mono text-gray-600">
                            Pts allocated
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
