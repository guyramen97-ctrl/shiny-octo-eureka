import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, ParsedDecision, BotProfile, UserAccount } from '../types';
import { DecisionCard } from './DecisionCard';
import { 
  Send, 
  HelpCircle, 
  Mic, 
  MicOff, 
  User, 
  Bot, 
  ArrowRight, 
  Layers, 
  Zap, 
  Scale,
  AlertTriangle,
  RefreshCw,
  KeyRound,
  Sparkles
} from 'lucide-react';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  botProfile: BotProfile;
  onSaveDecision: (decision: ParsedDecision, title?: string) => void;
  savedDecisionIds: string[];
  savedDecisions?: import('../types').SavedDecision[];
  onOpenBuilder: () => void;
  onOpenConfirmChoice?: (decision: ParsedDecision, optionName?: string) => void;
  onOpenCoinToss?: (heads: string, tails: string) => void;
  currentUser?: UserAccount | null;
  onOpenAuth?: (mode?: 'login' | 'register' | 'switch') => void;
}

const SAMPLE_STARTERS = [
  {
    title: 'Home Office Chair Dilemma',
    prompt: 'Should I upgrade my home office chair? Option A: Buy Pro-Ergo Model X ($1,200, 12-year warranty, back relief). Option B: Keep current chair ($0 cost, but continued back fatigue).',
  },
  {
    title: 'Job Offer vs. Current Role',
    prompt: 'I need to decide between: Option A: Accept a new job offer with 20% higher salary but longer commute. Option B: Stay at my current job with great work-life balance and friends, but stagnant pay.',
  },
  {
    title: 'MacBook Air vs. Pro',
    prompt: 'Should I buy Option A: MacBook Air (lighter, cheaper, sufficient for web/docs) or Option B: MacBook Pro (heavier, more expensive, handles 4K video editing and multiple monitors)?',
  },
  {
    title: 'Rent Closer vs. Buy Farther',
    prompt: 'I am choosing between: Option A: Rent an apartment 10 minutes from work with no equity. Option B: Buy a suburban house 45 minutes away with equity but high maintenance.',
  },
];

const PERSONA_TRIGGERS = [
  'Act like a strict coach',
  'Change your name to Choice Genie',
  'Act like a pragmatic analyst',
  'Act like a gentle guide',
];

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  onSendMessage,
  isLoading,
  botProfile,
  onSaveDecision,
  savedDecisionIds,
  savedDecisions = [],
  onOpenBuilder,
  onOpenConfirmChoice,
  onOpenCoinToss,
  currentUser,
  onOpenAuth,
}) => {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle textarea height auto-expansion
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input.trim());
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Speech Recognition support
  const handleToggleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Voice recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.start();
    } catch (err) {
      console.error('Speech recognition error:', err);
      setIsListening(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white text-[#111827]">
      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 space-y-8">
        {messages.length === 0 ? (
          /* Empty State / Welcome Screen */
          <div className="max-w-2xl mx-auto py-8 sm:py-12 space-y-10 animate-in fade-in duration-300">
            {/* Hero Greeting */}
            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-gray-900 text-white flex items-center justify-center mx-auto shadow-md">
                <Scale className="w-6 h-6" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-light text-gray-900 tracking-tight">
                {botProfile.name}
              </h2>
              <p className="text-gray-500 text-sm max-w-md mx-auto leading-relaxed">
                Provide 2–3 options you are choosing between. I’ll break them down with strict pros, cons, a clear recommendation, and an instant next step.
              </p>
            </div>

            {/* Account Status / Demo Login Banner */}
            {currentUser ? (
              <div className="p-3 sm:p-3.5 rounded-xl bg-gradient-to-r from-blue-50/80 to-indigo-50/60 border border-blue-200/70 flex items-center justify-between text-xs shadow-2xs">
                <div className="flex items-center space-x-2.5">
                  <div
                    className={`w-8 h-8 rounded-full bg-gradient-to-tr ${
                      currentUser.avatarColor || 'from-blue-600 to-indigo-600'
                    } text-white flex items-center justify-center font-bold text-xs shadow-xs`}
                  >
                    {currentUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-gray-900">
                        {currentUser.displayName || currentUser.username}
                      </span>
                      <span className="text-[10px] bg-blue-100 text-blue-700 font-mono px-1.5 py-0.5 rounded font-bold">
                        @{currentUser.username}
                      </span>
                    </div>
                    <span className="text-[11px] text-gray-500">
                      Decisions, polls & journals are linked to this profile
                    </span>
                  </div>
                </div>
                {onOpenAuth && (
                  <button
                    type="button"
                    onClick={() => onOpenAuth('switch')}
                    className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-white hover:bg-blue-50 rounded-lg border border-blue-200/80 transition-colors shadow-2xs"
                  >
                    Switch Account
                  </button>
                )}
              </div>
            ) : (
              <div className="p-3 sm:p-3.5 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50/70 border border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-xs shadow-xs shrink-0">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-amber-950">Quick Sign In Available</span>
                      <span className="text-[10px] bg-amber-200 text-amber-900 font-mono px-1.5 py-0.5 rounded font-bold">
                        acc: user | password: 123
                      </span>
                    </div>
                    <span className="text-[11px] text-amber-800">
                      Sign in with the demo account or create your custom profile.
                    </span>
                  </div>
                </div>
                {onOpenAuth && (
                  <div className="flex items-center space-x-2 self-end sm:self-auto shrink-0">
                    <button
                      type="button"
                      id="welcome-login-btn"
                      onClick={() => onOpenAuth('login')}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-lg shadow-xs transition-all flex items-center space-x-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Sign In</span>
                    </button>
                    <button
                      type="button"
                      id="welcome-create-acc-btn"
                      onClick={() => onOpenAuth('register')}
                      className="px-3 py-1.5 text-xs font-semibold text-amber-900 hover:bg-amber-100 rounded-lg transition-colors border border-amber-300"
                    >
                      Create Account
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Quick Starters */}
            <div className="space-y-3">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest block text-center">
                Try a dilemma example:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SAMPLE_STARTERS.map((starter, idx) => (
                  <button
                    key={idx}
                    onClick={() => onSendMessage(starter.prompt)}
                    className="p-4 rounded-xl bg-gray-50/80 border border-gray-100 hover:border-blue-300 hover:bg-blue-50/30 text-left transition-all group flex flex-col justify-between"
                  >
                    <div className="font-medium text-gray-900 text-xs sm:text-sm group-hover:text-blue-600 flex items-center justify-between">
                      <span>{starter.title}</span>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-blue-600 shrink-0 ml-2" />
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-snug">
                      {starter.prompt}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Persona Switch & Builder Shortcuts */}
            <div className="p-4 rounded-xl bg-gray-50 border border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2 text-gray-600">
                <Zap className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Prefer a guided step-by-step form?</span>
              </div>
              <button
                onClick={onOpenBuilder}
                className="px-3.5 py-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-white font-medium transition-colors flex items-center space-x-1.5 shadow-sm"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Open Structured Builder</span>
              </button>
            </div>
          </div>
        ) : (
          /* Conversation Messages */
          <div className="max-w-3xl mx-auto space-y-8">
            {messages.map((msg, index) => {
              const isUser = msg.role === 'user';
              const isClarification = !isUser && msg.content.includes('What are the 2–3 options you are choosing between?');
              const isError = !isUser && msg.content.startsWith('Error:');

              // Find previous user message for quick retry
              const prevUserMsg = !isUser && index > 0 
                ? [...messages.slice(0, index)].reverse().find(m => m.role === 'user')?.content
                : null;

              return (
                <div
                  key={msg.id}
                  className={`flex items-start space-x-3.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-1 shadow-sm ${
                      isError ? 'bg-amber-600 text-white' : 'bg-gray-900 text-white'
                    }`}>
                      {isError ? <AlertTriangle className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>
                  )}

                  <div className={`max-w-2xl ${isUser ? 'w-auto' : 'w-full'}`}>
                    {isUser ? (
                      <div className="px-4 py-3 rounded-2xl bg-gray-900 text-white text-sm leading-relaxed shadow-sm whitespace-pre-wrap">
                        {msg.content}
                      </div>
                    ) : isError ? (
                      /* Error Notice with Retry Button */
                      <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200 shadow-xs space-y-3">
                        <div className="flex items-center space-x-2 text-amber-800 font-semibold text-xs uppercase tracking-wider">
                          <AlertTriangle className="w-4 h-4 text-amber-600" />
                          <span>Temporary Connection Issue</span>
                        </div>
                        <p className="text-xs sm:text-sm text-amber-900 leading-relaxed">
                          {msg.content.replace(/^Error:\s*/, '')}
                        </p>
                        {prevUserMsg && (
                          <div className="pt-1">
                            <button
                              type="button"
                              onClick={() => onSendMessage(prevUserMsg)}
                              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium transition-colors flex items-center space-x-1.5 shadow-xs"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Retry Analysis</span>
                            </button>
                          </div>
                        )}
                      </div>
                    ) : msg.parsedDecision ? (
                      /* Visual Decision Card for parsed decision */
                      (() => {
                        const savedMatch = savedDecisions.find(
                          (d) =>
                            d.parsedDecision.quickSummary === msg.parsedDecision?.quickSummary ||
                            (d.parsedDecision.recommendation.chosenOption === msg.parsedDecision?.recommendation.chosenOption &&
                             d.parsedDecision.options.length === msg.parsedDecision?.options.length)
                        );
                        const isSaved = Boolean(savedMatch) || (msg.parsedDecision.quickSummary ? savedDecisionIds.includes(msg.parsedDecision.quickSummary) : false);
                        const confirmedChoice = savedMatch?.confirmedChoice || msg.parsedDecision.confirmedChoice;
                        const confirmedAtFormatted = savedMatch?.confirmedAtFormatted || msg.parsedDecision.confirmedAtFormatted;

                        return (
                          <DecisionCard
                            decision={msg.parsedDecision}
                            rawText={msg.content}
                            onSave={(dec) => onSaveDecision(dec, msg.parsedDecision?.quickSummary)}
                            isSaved={isSaved}
                            confirmedChoice={confirmedChoice}
                            confirmedAtFormatted={confirmedAtFormatted}
                            onOpenConfirmChoice={onOpenConfirmChoice}
                            onOpenCoinToss={onOpenCoinToss}
                          />
                        );
                      })()
                    ) : isClarification ? (
                      /* Clarify First Box */
                      <div className="p-6 rounded-r-xl bg-gray-50 border-l-4 border-blue-500 shadow-sm space-y-3">
                        <div className="flex items-center space-x-2 text-blue-700 font-semibold text-sm">
                          <HelpCircle className="w-5 h-5" />
                          <span>Need your 2–3 options first</span>
                        </div>
                        <p className="text-base text-gray-800 leading-relaxed italic">
                          What are the 2–3 options you are choosing between?
                        </p>
                        <div className="pt-2 flex flex-wrap gap-2">
                          <button
                            onClick={onOpenBuilder}
                            className="px-3.5 py-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-white text-xs font-medium transition-colors flex items-center space-x-1"
                          >
                            <Layers className="w-3.5 h-3.5" />
                            <span>Use Structured Form</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Standard Bot Text Message */
                      <div className="px-5 py-4 rounded-2xl bg-gray-50 border border-gray-100 text-gray-800 text-sm leading-relaxed whitespace-pre-wrap">
                        {msg.content}
                      </div>
                    )}

                    <span className={`text-[10px] text-gray-400 mt-1.5 block ${isUser ? 'text-right' : 'text-left'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-700 shrink-0 mt-1">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}

            {isLoading && (
              <div className="flex items-start space-x-3.5 max-w-3xl mx-auto">
                <div className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="px-4 py-3 rounded-2xl bg-gray-50 border border-gray-100 text-gray-500 text-xs flex items-center space-x-2.5">
                  <div className="flex space-x-1">
                    <div className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce" />
                    <div className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1.5 h-1.5 bg-gray-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                  <span>Analyzing choices strictly based on your details...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Suggested Persona Quick Chips */}
      {messages.length > 0 && (
        <div className="px-6 py-2 max-w-3xl mx-auto w-full flex items-center space-x-2 overflow-x-auto text-[11px] text-gray-500">
          <span className="shrink-0 text-gray-400 font-medium">Quick switch:</span>
          {PERSONA_TRIGGERS.map((trigger, idx) => (
            <button
              key={idx}
              onClick={() => onSendMessage(trigger)}
              className="shrink-0 px-3 py-1 rounded-full bg-gray-50 border border-gray-200 hover:border-gray-300 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              {trigger}
            </button>
          ))}
        </div>
      )}

      {/* Input Form Bar */}
      <div className="p-4 sm:p-6 border-t border-gray-100 bg-white/95 backdrop-blur-md">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto flex items-end space-x-2.5">
          {/* Voice Input Button */}
          <button
            type="button"
            onClick={handleToggleVoice}
            className={`p-3 rounded-2xl transition-colors shrink-0 ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse'
                : 'text-gray-500 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 border border-gray-200'
            }`}
            title={isListening ? "Listening... click to stop" : "Speak your decision"}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Textarea Input */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Tell me your options (e.g. Option A: ... Option B: ...), or ask to change bot name/persona..."
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-none max-h-36 placeholder:text-gray-400"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-3 rounded-2xl bg-gray-900 hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-all shadow-md shrink-0"
            title="Send Message"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

