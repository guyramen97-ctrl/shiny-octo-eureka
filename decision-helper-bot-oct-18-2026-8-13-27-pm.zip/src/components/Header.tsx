import React, { useState, useRef, useEffect } from 'react';
import { BotProfile, DashboardActiveTab, UserAccount } from '../types';
import {
  Sparkles,
  History,
  SlidersHorizontal,
  PlusCircle,
  Trash2,
  Scale,
  TrendingUp,
  MessageSquare,
  Vote,
  Sliders,
  BookOpen,
  DollarSign,
  Coins,
  LogIn,
  LogOut,
  User,
  ChevronDown,
  UserPlus,
  Users,
  ShieldCheck,
} from 'lucide-react';

interface HeaderProps {
  botProfile: BotProfile;
  activeTab: DashboardActiveTab;
  onSelectTab: (tab: DashboardActiveTab) => void;
  onOpenProfile: () => void;
  onOpenHistory: () => void;
  onOpenBuilder: () => void;
  onOpenReport: () => void;
  onClearChat: () => void;
  savedCount: number;
  votingCount: number;
  scalesCount: number;
  journalCount: number;
  financialCount: number;
  coinTossCount?: number;
  currentUser: UserAccount | null;
  onOpenAuth: (mode?: 'login' | 'register' | 'switch') => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  botProfile,
  activeTab,
  onSelectTab,
  onOpenProfile,
  onOpenHistory,
  onOpenBuilder,
  onOpenReport,
  onClearChat,
  savedCount,
  votingCount,
  scalesCount,
  journalCount,
  financialCount,
  coinTossCount = 0,
  currentUser,
  onOpenAuth,
  onLogout,
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Close user dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-gray-200/80 text-gray-900 shadow-2xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-8">
        {/* Top Tier: Identity & Action Controls */}
        <div className="h-16 flex items-center justify-between gap-4">
          {/* Brand & Bot Profile Info */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
              <Scale className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h1 className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold truncate">
                Decision Helper Bot
              </h1>
              <div className="flex items-center space-x-2">
                <span className="text-sm sm:text-base font-medium text-gray-900 tracking-tight truncate">
                  {botProfile.name}
                </span>
                <span className="hidden sm:inline-flex text-[10px] uppercase bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-bold tracking-tight border border-blue-100/60 items-center">
                  <Sparkles className="w-2.5 h-2.5 mr-1 text-blue-500" />
                  {botProfile.persona.split(',')[0]}
                </span>
              </div>
            </div>
          </div>

          {/* Action Controls */}
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {/* Quick Structured Builder */}
            <button
              id="open-builder-btn"
              onClick={onOpenBuilder}
              className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-medium transition-colors border border-gray-200/80"
              title="Structured Decision Builder"
            >
              <PlusCircle className="w-3.5 h-3.5 text-blue-600" />
              <span>Builder</span>
            </button>

            {/* Progress Report */}
            <button
              id="progress-report-btn"
              onClick={onOpenReport}
              className="flex items-center space-x-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-blue-50/80 hover:bg-blue-100 text-blue-800 text-xs font-medium transition-colors border border-blue-200/80"
              title="View Progress Report & Timestamps"
            >
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">Progress Report</span>
            </button>

            {/* Persona Settings */}
            <button
              id="bot-profile-btn"
              onClick={onOpenProfile}
              className="p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-medium transition-colors border border-gray-200/80 flex items-center space-x-1"
              title="Customize Bot Name & Persona"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-gray-500" />
              <span className="hidden lg:inline">Persona</span>
            </button>

            {/* History */}
            <button
              id="history-btn"
              onClick={onOpenHistory}
              className="relative p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-medium transition-colors border border-gray-200/80 flex items-center space-x-1"
              title="Saved Decisions History"
            >
              <History className="w-3.5 h-3.5 text-gray-500" />
              <span className="hidden lg:inline">Saved</span>
              {savedCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-gray-900 text-[10px] font-bold text-white flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Clear Chat */}
            {activeTab === 'chat' && (
              <button
                id="clear-chat-btn"
                onClick={onClearChat}
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                title="Reset Conversation"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            {/* Divider */}
            <div className="h-5 w-px bg-gray-200/80 mx-1 hidden sm:block" />

            {/* User Account / Login Button */}
            {currentUser ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  id="user-account-btn"
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-1.5 sm:space-x-2 pl-1.5 pr-2 sm:pr-2.5 py-1 rounded-xl bg-gray-50 hover:bg-gray-100 border border-gray-200/80 transition-colors shadow-2xs"
                  title={`Logged in as ${currentUser.username}`}
                >
                  <div
                    className={`w-6 h-6 rounded-full bg-gradient-to-tr ${
                      currentUser.avatarColor || 'from-blue-600 to-indigo-600'
                    } text-white flex items-center justify-center font-bold text-xs shadow-xs`}
                  >
                    {currentUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="text-left hidden sm:block">
                    <span className="block text-xs font-semibold text-gray-800 leading-none">
                      {currentUser.username}
                    </span>
                    <span className="block text-[9px] text-gray-400 font-medium">
                      Account
                    </span>
                  </div>
                  <ChevronDown className="w-3 h-3 text-gray-400" />
                </button>

                {/* Account Dropdown Menu */}
                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="px-4 py-2.5 border-b border-gray-100">
                      <p className="text-xs font-bold text-gray-900">
                        {currentUser.displayName || currentUser.username}
                      </p>
                      <p className="text-[11px] text-gray-500 font-mono truncate">
                        @{currentUser.username}
                      </p>
                      <p className="text-[10px] text-gray-400 truncate">
                        {currentUser.email}
                      </p>
                    </div>

                    <div className="py-1">
                      <button
                        id="user-menu-switch"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          onOpenAuth('switch');
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center space-x-2 transition-colors"
                      >
                        <Users className="w-3.5 h-3.5 text-gray-500" />
                        <span>Switch Accounts</span>
                      </button>

                      <button
                        id="user-menu-create-acc"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          onOpenAuth('register');
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center space-x-2 transition-colors"
                      >
                        <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                        <span>Create New Account</span>
                      </button>
                    </div>

                    <div className="pt-1 border-t border-gray-100">
                      <button
                        id="user-menu-logout"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-red-600 hover:bg-red-50 flex items-center space-x-2 transition-colors"
                      >
                        <LogOut className="w-3.5 h-3.5 text-red-500" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                id="header-login-btn"
                onClick={() => onOpenAuth('login')}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                title="Sign in with user / 123"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
                <span className="hidden md:inline-flex items-center text-[10px] bg-blue-700 px-1.5 py-0.5 rounded font-mono text-blue-100">
                  user/123
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Bottom Tier: Feature Navigation Tabs */}
        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar py-1.5 border-t border-gray-100">
          {/* 1. Chat & Engine */}
          <button
            id="tab-chat"
            onClick={() => onSelectTab('chat')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'chat'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat Advisor</span>
          </button>

          {/* 2. Voting & Consensus */}
          <button
            id="tab-voting"
            onClick={() => onSelectTab('voting')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'voting'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Vote className="w-3.5 h-3.5" />
            <span>Voting Polls</span>
            {votingCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === 'voting' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                {votingCount}
              </span>
            )}
          </button>

          {/* 3. Scales Matrix */}
          <button
            id="tab-scales"
            onClick={() => onSelectTab('scales')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'scales'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Scales Matrix</span>
            {scalesCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === 'scales' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                {scalesCount}
              </span>
            )}
          </button>

          {/* 4. Diary / Journals */}
          <button
            id="tab-journal"
            onClick={() => onSelectTab('journal')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'journal'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Diary & Journals</span>
            {journalCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === 'journal' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                {journalCount}
              </span>
            )}
          </button>

          {/* 5. Financial Tracking */}
          <button
            id="tab-financials"
            onClick={() => onSelectTab('financials')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'financials'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Financial Tracking</span>
            {financialCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === 'financials' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                {financialCount}
              </span>
            )}
          </button>

          {/* 6. Coin Toss & Gut-Check */}
          <button
            id="tab-cointoss"
            onClick={() => onSelectTab('cointoss')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'cointoss'
                ? 'bg-amber-500 text-white shadow-2xs'
                : 'text-gray-600 hover:text-amber-800 hover:bg-amber-50/70'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Coin Toss</span>
            {coinTossCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === 'cointoss' ? 'bg-amber-600 text-white' : 'bg-amber-100 text-amber-800'
                }`}
              >
                {coinTossCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};



