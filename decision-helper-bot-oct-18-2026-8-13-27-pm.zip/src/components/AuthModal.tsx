import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Lock,
  Mail,
  Eye,
  EyeOff,
  UserPlus,
  LogIn,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Sparkles,
  Users,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { UserAccount } from '../types';
import {
  authenticateUser,
  createAccount,
  getStoredAccounts,
} from '../utils/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  onLoginSuccess: (user: UserAccount) => void;
  initialMode?: 'login' | 'register' | 'switch';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  initialMode = 'login',
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'switch'>(initialMode);
  
  // Login fields
  const [loginIdentifier, setLoginIdentifier] = useState('user');
  const [loginPassword, setLoginPassword] = useState('123');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loginSuccessMessage, setLoginSuccessMessage] = useState<string | null>(null);

  // Register fields
  const [regDisplayName, setRegDisplayName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regError, setRegError] = useState<string | null>(null);

  // Saved accounts on device
  const [storedAccounts, setStoredAccounts] = useState<UserAccount[]>([]);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setStoredAccounts(getStoredAccounts());
      setLoginError(null);
      setRegError(null);
      setLoginSuccessMessage(null);
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  const handleQuickFillDemo = () => {
    setLoginIdentifier('user');
    setLoginPassword('123');
    setLoginError(null);
  };

  const handleQuickLoginDemo = () => {
    setLoginIdentifier('user');
    setLoginPassword('123');
    setLoginError(null);
    setIsSubmitting(true);
    setTimeout(() => {
      const res = authenticateUser('user', '123');
      setIsSubmitting(false);
      if (res.success && res.user) {
        setLoginSuccessMessage(`Signed in as ${res.user.displayName || res.user.username}!`);
        setTimeout(() => {
          onLoginSuccess(res.user!);
          onClose();
        }, 400);
      } else {
        setLoginError(res.error || 'Authentication failed');
      }
    }, 250);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginSuccessMessage(null);

    if (!loginIdentifier.trim()) {
      setLoginError('Please enter your username or email.');
      return;
    }
    if (!loginPassword) {
      setLoginError('Please enter your password.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = authenticateUser(loginIdentifier, loginPassword);
      setIsSubmitting(false);

      if (res.success && res.user) {
        setLoginSuccessMessage(`Signed in as ${res.user.displayName || res.user.username}!`);
        setTimeout(() => {
          onLoginSuccess(res.user!);
          onClose();
        }, 400);
      } else {
        setLoginError(res.error || 'Invalid credentials. Hint: user / 123');
      }
    }, 250);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (!regUsername.trim()) {
      setRegError('Please enter a username.');
      return;
    }

    if (regPassword.length < 3) {
      setRegError('Password must be at least 3 characters.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match. Please verify your password.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = createAccount({
        username: regUsername,
        password: regPassword,
        displayName: regDisplayName.trim() || undefined,
        email: regEmail.trim() || undefined,
      });

      setIsSubmitting(false);

      if (res.success && res.user) {
        setLoginSuccessMessage(`Account created! Logged in as ${res.user.username}.`);
        setTimeout(() => {
          onLoginSuccess(res.user!);
          onClose();
        }, 500);
      } else {
        setRegError(res.error || 'Failed to create account.');
      }
    }, 300);
  };

  const handleSelectExistingAccount = (account: UserAccount) => {
    const res = authenticateUser(account.username, account.password);
    if (res.success && res.user) {
      onLoginSuccess(res.user);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon / Branding */}
        <div className="bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 px-6 py-5 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-blue-200 shadow-inner border border-white/10">
                <ShieldCheck className="w-5 h-5 text-blue-300" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                  Decision Helper Account
                </h2>
                <p className="text-xs text-blue-200/80">
                  {currentUser
                    ? `Currently signed in as ${currentUser.username}`
                    : 'Personalize & sync your decisions'}
                </p>
              </div>
            </div>
            <button
              id="auth-modal-close-btn"
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center space-x-1 mt-4 p-1 bg-white/10 rounded-xl backdrop-blur-xs text-xs font-semibold">
            <button
              id="auth-tab-login"
              type="button"
              onClick={() => {
                setMode('login');
                setLoginError(null);
              }}
              className={`flex-1 py-1.5 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                mode === 'login'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/5'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>

            <button
              id="auth-tab-register"
              type="button"
              onClick={() => {
                setMode('register');
                setRegError(null);
              }}
              className={`flex-1 py-1.5 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                mode === 'register'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-white/80 hover:text-white hover:bg-white/5'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create Account</span>
            </button>

            {storedAccounts.length > 1 && (
              <button
                id="auth-tab-switch"
                type="button"
                onClick={() => setMode('switch')}
                className={`py-1.5 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all ${
                  mode === 'switch'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-white/80 hover:text-white hover:bg-white/5'
                }`}
                title="Switch stored accounts"
              >
                <Users className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Accounts</span>
                <span className="w-4 h-4 rounded-full bg-blue-500/30 text-[10px] flex items-center justify-center">
                  {storedAccounts.length}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {/* Success Banner */}
          {loginSuccessMessage && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center space-x-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">{loginSuccessMessage}</span>
            </div>
          )}

          {/* MODE 1: LOGIN */}
          {mode === 'login' && (
            <div>
              {/* Demo Account Quick Access Card */}
              <div className="mb-5 p-3.5 bg-gradient-to-br from-amber-50 to-orange-50/60 border border-amber-200/80 rounded-xl">
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                      <span className="text-xs font-bold text-amber-900 tracking-tight">
                        Requested Demo Credentials
                      </span>
                    </div>
                    <div className="text-xs text-amber-800 space-x-3">
                      <span>Account: <strong className="font-mono bg-amber-100 px-1 py-0.5 rounded text-amber-950 font-bold">user</strong></span>
                      <span>Password: <strong className="font-mono bg-amber-100 px-1 py-0.5 rounded text-amber-950 font-bold">123</strong></span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 items-end shrink-0">
                    <button
                      type="button"
                      id="quick-login-demo-btn"
                      onClick={handleQuickLoginDemo}
                      className="px-2.5 py-1 text-[11px] font-semibold bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-lg transition-all shadow-xs flex items-center space-x-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>One-Click Login</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleQuickFillDemo}
                      className="text-[10px] text-amber-800 hover:text-amber-950 underline"
                    >
                      fill inputs
                    </button>
                  </div>
                </div>
              </div>

              {loginError && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {/* Username Input */}
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Account / Username
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      id="login-username-input"
                      type="text"
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. user"
                      className="w-full pl-9 pr-3 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                      autoFocus
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-gray-700">
                      Password
                    </label>
                    <span className="text-[11px] text-gray-400">Default: 123</span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="login-password-input"
                      type={showLoginPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••"
                      className="w-full pl-9 pr-10 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                      title={showLoginPassword ? 'Hide password' : 'Show password'}
                    >
                      {showLoginPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  id="login-submit-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-2 py-2.5 px-4 bg-gray-900 hover:bg-gray-800 active:scale-[0.99] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{isSubmitting ? 'Signing in...' : 'Sign In'}</span>
                </button>
              </form>

              <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
                <span>Don't have an account yet?</span>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setRegError(null);
                  }}
                  className="font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                >
                  <span>Create Account</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* MODE 2: REGISTER / CREATE ACCOUNT */}
          {mode === 'register' && (
            <div>
              <div className="mb-4">
                <h3 className="text-sm font-bold text-gray-900">
                  Create a New Decision Maker Account
                </h3>
                <p className="text-xs text-gray-500">
                  You can register custom accounts to manage distinct decisions.
                </p>
              </div>

              {regError && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                {/* Full / Display Name */}
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Full Name / Display Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      id="reg-displayname-input"
                      type="text"
                      value={regDisplayName}
                      onChange={(e) => setRegDisplayName(e.target.value)}
                      placeholder="e.g. Alex Morgan"
                      className="w-full pl-9 pr-3 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                      autoFocus
                    />
                  </div>
                </div>

                {/* Username */}
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Username <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <span className="text-xs font-bold text-gray-400">@</span>
                    </div>
                    <input
                      id="reg-username-input"
                      type="text"
                      value={regUsername}
                      onChange={(e) => setRegUsername(e.target.value)}
                      placeholder="e.g. alexm"
                      className="w-full pl-9 pr-3 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                      required
                    />
                  </div>
                  {regUsername.trim().toLowerCase() === 'user' && (
                    <p className="text-[11px] text-amber-600 mt-1">
                      Note: "user" is the default seeded demo account.
                    </p>
                  )}
                </div>

                {/* Email Address */}
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Email Address <span className="text-gray-400 text-[10px]">(Optional)</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      id="reg-email-input"
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="alex@example.com"
                      className="w-full pl-9 pr-3 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                {/* Password & Confirm */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Password <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        id="reg-password-input"
                        type={showRegPassword ? 'text' : 'password'}
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="••••••"
                        className="w-full px-3 py-2 bg-gray-50/50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white focus:outline-hidden transition-all"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Confirm <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        id="reg-confirm-password-input"
                        type={showRegPassword ? 'text' : 'password'}
                        value={regConfirmPassword}
                        onChange={(e) => setRegConfirmPassword(e.target.value)}
                        placeholder="••••••"
                        className={`w-full px-3 py-2 bg-gray-50/50 border rounded-xl text-sm focus:ring-2 focus:bg-white focus:outline-hidden transition-all ${
                          regConfirmPassword && regPassword !== regConfirmPassword
                            ? 'border-red-300 focus:ring-red-500'
                            : regConfirmPassword && regPassword === regConfirmPassword
                            ? 'border-emerald-400 focus:ring-emerald-500'
                            : 'border-gray-300 focus:ring-blue-500'
                        }`}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-gray-500">
                  <label className="flex items-center space-x-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showRegPassword}
                      onChange={(e) => setShowRegPassword(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span>Show passwords</span>
                  </label>
                  {regPassword && regConfirmPassword && regPassword === regConfirmPassword && (
                    <span className="text-emerald-600 font-semibold flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Passwords match</span>
                    </span>
                  )}
                </div>

                {/* Submit Register Button */}
                <button
                  id="reg-submit-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isSubmitting ? 'Creating account...' : 'Create Account & Sign In'}</span>
                </button>
              </form>

              <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
                <span>Already have an account?</span>
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setLoginError(null);
                  }}
                  className="font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                >
                  <span>Sign In instead</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* MODE 3: ACCOUNTS LIST / SWITCHER */}
          {mode === 'switch' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                  Stored Accounts ({storedAccounts.length})
                </span>
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
                >
                  <UserPlus className="w-3 h-3" />
                  <span>Add New</span>
                </button>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {storedAccounts.map((acc) => {
                  const isCurrent = currentUser?.id === acc.id;
                  return (
                    <div
                      key={acc.id}
                      onClick={() => handleSelectExistingAccount(acc)}
                      className={`p-3 rounded-xl border text-left flex items-center justify-between cursor-pointer transition-all ${
                        isCurrent
                          ? 'bg-blue-50/60 border-blue-200 ring-2 ring-blue-500/20'
                          : 'bg-white hover:bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-9 h-9 rounded-full bg-gradient-to-tr ${
                            acc.avatarColor || 'from-blue-600 to-indigo-600'
                          } text-white flex items-center justify-center font-bold text-sm shadow-xs`}
                        >
                          {acc.username.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-semibold text-gray-900">
                              {acc.displayName || acc.username}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full">
                                Active
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-gray-500">
                            @{acc.username} • {acc.email}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        className="px-2.5 py-1 text-xs font-medium rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
                      >
                        {isCurrent ? 'Current' : 'Select'}
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="w-full py-2 text-xs font-semibold text-gray-600 hover:text-gray-900 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  Return to Manual Login
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
