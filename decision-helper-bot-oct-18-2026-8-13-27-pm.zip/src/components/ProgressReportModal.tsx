import React, { useState } from 'react';
import { SavedDecision, ProgressStatus, ProgressLog, ParsedDecision } from '../types';
import { 
  X, 
  TrendingUp, 
  CheckCircle2, 
  PlayCircle, 
  AlertCircle, 
  StopCircle, 
  Calendar, 
  Clock, 
  Download, 
  Copy, 
  Check, 
  Plus, 
  FileText, 
  Search,
  ChevronDown,
  ChevronUp,
  Award,
  Target,
  CheckCheck
} from 'lucide-react';

interface ProgressReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedDecisions: SavedDecision[];
  onOpenRecordModal: (decision: SavedDecision) => void;
  onOpenConfirmChoice?: (decision: ParsedDecision, optionName?: string) => void;
}

export const ProgressReportModal: React.FC<ProgressReportModalProps> = ({
  isOpen,
  onClose,
  savedDecisions,
  onOpenRecordModal,
  onOpenConfirmChoice,
}) => {
  if (!isOpen) return null;

  const [statusFilter, setStatusFilter] = useState<'all' | 'confirmed' | 'unconfirmed' | ProgressStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [expandedDecisions, setExpandedDecisions] = useState<Record<string, boolean>>({});

  // Summary Metrics calculations
  const totalDecisions = savedDecisions.length;
  const confirmedDecisions = savedDecisions.filter((d) => Boolean(d.confirmedChoice)).length;
  const completedDecisions = savedDecisions.filter(
    (d) => d.nextStepCompleted || d.status === 'completed' || d.progressPercent === 100
  ).length;
  const inProgressDecisions = savedDecisions.filter(
    (d) => !d.nextStepCompleted && d.status === 'in_progress'
  ).length;
  const blockedDecisions = savedDecisions.filter(
    (d) => d.status === 'blocked'
  ).length;
  const notStartedDecisions = savedDecisions.filter(
    (d) => !d.nextStepCompleted && (!d.status || d.status === 'not_started')
  ).length;

  const overallProgressPercent = totalDecisions > 0
    ? Math.round(
        savedDecisions.reduce((acc, d) => acc + (d.progressPercent ?? (d.nextStepCompleted ? 100 : 0)), 0) / totalDecisions
      )
    : 0;

  const totalLogsCount = savedDecisions.reduce(
    (acc, d) => acc + (d.progressLogs?.length || 0),
    0
  );

  // Filtered decisions
  const filteredDecisions = savedDecisions.filter((d) => {
    const effectiveStatus: ProgressStatus = d.status || (d.nextStepCompleted ? 'completed' : 'not_started');
    if (statusFilter === 'confirmed') {
      if (!d.confirmedChoice) return false;
    } else if (statusFilter === 'unconfirmed') {
      if (d.confirmedChoice) return false;
    } else if (statusFilter !== 'all' && effectiveStatus !== statusFilter) {
      return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = d.title.toLowerCase().includes(q);
      const matchNextStep = d.parsedDecision.nextStep.toLowerCase().includes(q);
      const matchChoice = d.confirmedChoice?.toLowerCase().includes(q) || d.parsedDecision.recommendation.chosenOption.toLowerCase().includes(q);
      const matchLogs = d.progressLogs?.some((l) => l.note.toLowerCase().includes(q));
      return matchTitle || matchNextStep || matchChoice || matchLogs;
    }
    return true;
  });

  const toggleExpand = (id: string) => {
    setExpandedDecisions((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Generate formatted text / markdown progress report
  const generateMarkdownReport = () => {
    const nowStr = new Date().toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    let report = `# 📊 Decision Progress & Confirmed Choices Report\n`;
    report += `**Generated Date & Time:** ${nowStr}\n\n`;
    report += `## Executive Summary\n`;
    report += `- **Total Decisions Tracked:** ${totalDecisions}\n`;
    report += `- **Confirmed Choices:** ${confirmedDecisions} / ${totalDecisions} (${totalDecisions > 0 ? Math.round((confirmedDecisions / totalDecisions) * 100) : 0}%)\n`;
    report += `- **Completed Actions:** ${completedDecisions} / ${totalDecisions} (${totalDecisions > 0 ? Math.round((completedDecisions / totalDecisions) * 100) : 0}%)\n`;
    report += `- **Overall Average Execution Progress:** ${overallProgressPercent}%\n`;
    report += `- **In Progress:** ${inProgressDecisions} | **On Hold / Blocked:** ${blockedDecisions} | **Not Started:** ${notStartedDecisions}\n`;
    report += `- **Total Recorded Progress Timestamps & Logs:** ${totalLogsCount}\n\n`;
    report += `---\n\n`;
    report += `## Detailed Decisions, Confirmed Choices & Progress Logs\n\n`;

    savedDecisions.forEach((d, idx) => {
      const effectiveStatus: ProgressStatus = d.status || (d.nextStepCompleted ? 'completed' : 'not_started');
      const effectivePercent = d.progressPercent ?? (d.nextStepCompleted ? 100 : 0);
      report += `### ${idx + 1}. ${d.title}\n`;
      report += `- **Saved Date:** ${d.date}\n`;
      
      if (d.confirmedChoice) {
        report += `- **🎯 Confirmed Choice:** ${d.confirmedChoice} (Confirmed: ${d.confirmedAtFormatted || 'Recorded'})\n`;
        if (d.confirmedReason) {
          report += `  - *Decision Rationale:* ${d.confirmedReason}\n`;
        }
      } else {
        report += `- **⚠️ Confirmed Choice:** [Pending Confirmation]\n`;
      }
      
      report += `- **Recommended Choice (Bot):** ${d.parsedDecision.recommendation.chosenOption}\n`;
      report += `- **Action / Next Step:** ${d.parsedDecision.nextStep}\n`;
      report += `- **Status:** ${effectiveStatus.toUpperCase()} (${effectivePercent}% Complete)\n`;
      if (d.completedAtFormatted) {
        report += `- **Completed At:** ${d.completedAtFormatted}\n`;
      }

      if (d.progressLogs && d.progressLogs.length > 0) {
        report += `\n**Progress History & Timestamps:**\n`;
        d.progressLogs.forEach((log) => {
          report += `  - 🕒 **${log.dateTimeFormatted}** [${log.status.toUpperCase()} - ${log.progressPercent}%]: ${log.note}\n`;
        });
      } else {
        report += `\n*No detailed progress timestamps logged yet for this item.*\n`;
      }
      report += `\n`;
    });

    report += `---\n*Generated by Decision Helper Bot*`;
    return report;
  };

  const handleCopyReport = () => {
    const report = generateMarkdownReport();
    navigator.clipboard.writeText(report).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleDownloadReport = () => {
    const report = generateMarkdownReport();
    const blob = new Blob([report], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `decision-progress-report-${new Date().toISOString().slice(0, 10)}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const getStatusBadge = (status?: ProgressStatus, percent?: number) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Completed
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
            <PlayCircle className="w-3 h-3 mr-1" />
            In Progress ({percent || 50}%)
          </span>
        );
      case 'blocked':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <AlertCircle className="w-3 h-3 mr-1" />
            On Hold
          </span>
        );
      case 'not_started':
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-gray-100 text-gray-700 border border-gray-200">
            <StopCircle className="w-3 h-3 mr-1" />
            Not Started
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 sm:p-6">
      <div className="w-full max-w-4xl bg-white border border-gray-100 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-[#111827] animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 sm:p-8 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white shrink-0">
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <h1 className="text-xs uppercase tracking-widest text-gray-400 font-semibold flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-emerald-600" />
                <span>Decision & Choice Tracking</span>
              </h1>
            </div>
            <h2 className="text-xl sm:text-2xl font-light text-gray-900 flex items-center gap-2.5">
              <span className="font-semibold">Progress & Confirmed Choices Report</span>
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Comprehensive record of confirmed options, execution dates, timestamps, status updates, and action logs
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyReport}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-medium border border-gray-200 transition-colors"
              title="Copy formatted markdown report"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Report'}</span>
            </button>

            <button
              onClick={handleDownloadReport}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-white text-xs font-medium transition-colors shadow-sm"
              title="Download Progress Report (.md)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Metrics Bar */}
        <div className="px-6 sm:px-8 py-4 bg-gray-50 border-b border-gray-100 grid grid-cols-2 sm:grid-cols-5 gap-3 shrink-0">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block">
              Confirmed Choices
            </span>
            <div className="flex items-baseline space-x-1.5 mt-0.5">
              <span className="text-xl font-bold text-emerald-800 font-mono">
                {confirmedDecisions}
              </span>
              <span className="text-xs text-gray-500">/ {totalDecisions}</span>
            </div>
            <span className="text-[11px] text-emerald-700 font-medium block mt-1">
              {totalDecisions > 0 ? Math.round((confirmedDecisions / totalDecisions) * 100) : 0}% finalized
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block">
              Overall Progress
            </span>
            <div className="flex items-baseline space-x-2 mt-0.5">
              <span className="text-xl font-bold text-gray-900 font-mono">
                {overallProgressPercent}%
              </span>
              <span className="text-xs text-gray-500">avg</span>
            </div>
            <div className="w-full bg-gray-200 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-300"
                style={{ width: `${overallProgressPercent}%` }}
              />
            </div>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block">
              Completed Actions
            </span>
            <div className="flex items-baseline space-x-1.5 mt-0.5">
              <span className="text-xl font-bold text-emerald-700 font-mono">
                {completedDecisions}
              </span>
              <span className="text-xs text-gray-500">done</span>
            </div>
            <span className="text-[11px] text-gray-400 block mt-1">
              {totalDecisions > 0 ? Math.round((completedDecisions / totalDecisions) * 100) : 0}% action rate
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block">
              Active / In Progress
            </span>
            <div className="flex items-baseline space-x-1.5 mt-0.5">
              <span className="text-xl font-bold text-blue-600 font-mono">
                {inProgressDecisions}
              </span>
              <span className="text-xs text-gray-500">active</span>
            </div>
            <span className="text-[11px] text-gray-400 block mt-1">
              {blockedDecisions > 0 ? `${blockedDecisions} on hold` : '0 on hold'}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block">
              Recorded Logs
            </span>
            <div className="flex items-baseline space-x-1.5 mt-0.5">
              <span className="text-xl font-bold text-gray-900 font-mono">
                {totalLogsCount}
              </span>
              <span className="text-xs text-gray-500">entries</span>
            </div>
            <span className="text-[11px] text-gray-400 block mt-1">
              With date & time
            </span>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="px-6 sm:px-8 py-3 border-b border-gray-100 bg-white flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          {/* Status Filter Tabs */}
          <div className="flex items-center space-x-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === 'all'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              All ({totalDecisions})
            </button>
            <button
              onClick={() => setStatusFilter('confirmed')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap flex items-center gap-1 ${
                statusFilter === 'confirmed'
                  ? 'bg-emerald-700 text-white'
                  : 'text-emerald-800 hover:bg-emerald-50'
              }`}
            >
              <CheckCheck className="w-3 h-3" />
              <span>Confirmed ({confirmedDecisions})</span>
            </button>
            <button
              onClick={() => setStatusFilter('in_progress')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === 'in_progress'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              In Progress ({inProgressDecisions})
            </button>
            <button
              onClick={() => setStatusFilter('completed')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === 'completed'
                  ? 'bg-emerald-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Completed ({completedDecisions})
            </button>
            <button
              onClick={() => setStatusFilter('blocked')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === 'blocked'
                  ? 'bg-amber-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              On Hold ({blockedDecisions})
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search decisions, choices, logs..."
              className="w-full pl-8 pr-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Decisions & Progress Log List */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
          {savedDecisions.length === 0 ? (
            <div className="text-center py-16 px-4">
              <div className="w-14 h-14 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center mx-auto mb-3 text-gray-400">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-1">
                No Decisions Tracked Yet
              </h3>
              <p className="text-xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                When you chat with the bot and save decisions, their confirmed choices, progress dates, times, and execution logs will automatically show up here.
              </p>
            </div>
          ) : filteredDecisions.length === 0 ? (
            <div className="text-center py-12 text-gray-400 text-xs">
              No decisions match the selected status or search filter.
            </div>
          ) : (
            filteredDecisions.map((decision) => {
              const effectiveStatus: ProgressStatus = decision.status || (decision.nextStepCompleted ? 'completed' : 'not_started');
              const effectivePercent = decision.progressPercent ?? (decision.nextStepCompleted ? 100 : 0);
              const logs = decision.progressLogs || [];
              const isExpanded = expandedDecisions[decision.id] ?? true;

              return (
                <div
                  key={decision.id}
                  className="p-5 sm:p-6 rounded-2xl bg-white border border-gray-200/80 shadow-xs space-y-4 hover:border-gray-300 transition-all"
                >
                  {/* Item Top Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-gray-400 font-mono">
                          Saved: {decision.date}
                        </span>
                        {decision.completedAtFormatted && (
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
                            Completed: {decision.completedAtFormatted}
                          </span>
                        )}
                      </div>
                      <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                        {decision.title}
                      </h3>
                    </div>

                    <div className="flex items-center space-x-2 shrink-0">
                      {getStatusBadge(effectiveStatus, effectivePercent)}
                      <button
                        onClick={() => onOpenRecordModal(decision)}
                        className="px-3 py-1 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-medium border border-gray-200 flex items-center space-x-1 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5 text-blue-600" />
                        <span>Record Progress</span>
                      </button>
                    </div>
                  </div>

                  {/* Confirmed Choice Highlight Box */}
                  {decision.confirmedChoice ? (
                    <div className="p-3.5 bg-emerald-50/70 border border-emerald-200/90 rounded-xl space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-900">
                          <Target className="w-4 h-4 text-emerald-600" />
                          <span>CONFIRMED CHOICE: {decision.confirmedChoice}</span>
                        </div>
                        {onOpenConfirmChoice && (
                          <button
                            onClick={() => onOpenConfirmChoice(decision.parsedDecision, decision.confirmedChoice)}
                            className="text-xs text-emerald-700 hover:text-emerald-950 font-medium underline"
                          >
                            Edit Choice
                          </button>
                        )}
                      </div>
                      {decision.confirmedAtFormatted && (
                        <p className="text-[11px] text-emerald-700">
                          Confirmed on: <span className="font-medium font-mono">{decision.confirmedAtFormatted}</span>
                        </p>
                      )}
                      {decision.confirmedReason && (
                        <p className="text-xs text-emerald-900/80 bg-white/70 p-2 rounded-lg border border-emerald-100 mt-1">
                          <span className="font-semibold">Rationale: </span>
                          {decision.confirmedReason}
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-xl flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2 text-amber-900">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>No choice confirmed yet for this decision.</span>
                      </div>
                      {onOpenConfirmChoice && (
                        <button
                          onClick={() => onOpenConfirmChoice(decision.parsedDecision, decision.parsedDecision.recommendation.chosenOption)}
                          className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors shadow-2xs shrink-0 ml-3"
                        >
                          Confirm Choice Now
                        </button>
                      )}
                    </div>
                  )}

                  {/* Decision Context Box */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 bg-gray-50/70 border border-gray-100 rounded-xl text-xs">
                    <div>
                      <span className="font-semibold text-blue-700 uppercase tracking-wider text-[10px] block mb-0.5">
                        Bot Recommendation:
                      </span>
                      <p className="font-medium text-gray-800">
                        {decision.parsedDecision.recommendation.chosenOption}
                      </p>
                      {decision.parsedDecision.recommendation.because && (
                        <p className="text-gray-500 mt-1 line-clamp-2">
                          {decision.parsedDecision.recommendation.because}
                        </p>
                      )}
                    </div>

                    <div>
                      <span className="font-semibold text-gray-600 uppercase tracking-wider text-[10px] block mb-0.5">
                        Action Item / Next Step:
                      </span>
                      <p className="font-medium text-gray-900 leading-snug">
                        {decision.parsedDecision.nextStep}
                      </p>
                    </div>
                  </div>

                  {/* Progress Bar & Percentage */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500 font-medium">Completion Progress</span>
                      <span className="font-bold text-gray-900 font-mono">{effectivePercent}%</span>
                    </div>
                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          effectiveStatus === 'completed'
                            ? 'bg-emerald-600'
                            : effectiveStatus === 'blocked'
                            ? 'bg-amber-600'
                            : 'bg-blue-600'
                        }`}
                        style={{ width: `${effectivePercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Progress Timeline Header Toggle */}
                  <div className="pt-2 border-t border-gray-100">
                    <button
                      onClick={() => toggleExpand(decision.id)}
                      className="w-full flex items-center justify-between text-xs text-gray-500 hover:text-gray-900 font-medium py-1"
                    >
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-blue-600" />
                        <span>Progress History & Timestamps ({logs.length})</span>
                      </span>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    {/* Timeline Log Entries */}
                    {isExpanded && (
                      <div className="mt-3 space-y-2.5 pl-2 border-l-2 border-gray-100 ml-1.5">
                        {logs.length === 0 ? (
                          <p className="text-xs text-gray-400 italic py-1">
                            No progress entries logged yet. Click "Record Progress" to log an update with date & time!
                          </p>
                        ) : (
                          logs.map((log) => (
                            <div key={log.id} className="relative pl-4 space-y-1">
                              <div className="absolute -left-[13px] top-1 w-2.5 h-2.5 rounded-full bg-blue-500 ring-4 ring-white" />
                              <div className="flex flex-wrap items-center gap-2 text-xs">
                                <span className="font-semibold text-gray-900 font-mono">
                                  {log.dateTimeFormatted}
                                </span>
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    log.status === 'completed'
                                      ? 'bg-emerald-50 text-emerald-700'
                                      : log.status === 'blocked'
                                      ? 'bg-amber-50 text-amber-700'
                                      : 'bg-blue-50 text-blue-700'
                                  }`}
                                >
                                  {log.status.replace('_', ' ').toUpperCase()} • {log.progressPercent}%
                                </span>
                              </div>
                              <p className="text-xs text-gray-600 leading-relaxed bg-gray-50/70 p-2 rounded-lg border border-gray-100">
                                {log.note}
                              </p>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-6 border-t border-gray-100 bg-gray-50 flex items-center justify-between text-xs shrink-0">
          <p className="text-gray-500 italic">
            All confirmed choices and progress timestamps are saved securely and can be exported at any time.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-white font-medium transition-colors"
          >
            Close Report
          </button>
        </div>
      </div>
    </div>
  );
};
