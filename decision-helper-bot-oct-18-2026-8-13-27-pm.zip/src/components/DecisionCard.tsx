import React, { useState } from 'react';
import { ParsedDecision, RiskLevel, ReversibilityType } from '../types';
import { 
  CheckCircle2, 
  Circle, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Bookmark, 
  BookmarkCheck, 
  Clock, 
  Code2, 
  Sparkles,
  Target,
  Zap,
  Compass,
  Shield,
  AlertTriangle,
  RotateCcw,
  Gauge,
  HelpCircle,
  TrendingUp,
  Flame,
  Layers,
  Lightbulb,
  ArrowRight,
  BrainCircuit,
  Hourglass,
  Scale,
  Calendar,
  Waves,
  Coins
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface DecisionCardProps {
  decision: ParsedDecision;
  rawText: string;
  onSave?: (decision: ParsedDecision) => void;
  isSaved?: boolean;
  confirmedChoice?: string;
  confirmedAtFormatted?: string;
  onOpenConfirmChoice?: (decision: ParsedDecision, optionName: string) => void;
  onOpenCoinToss?: (heads: string, tails: string) => void;
}

export const DecisionCard: React.FC<DecisionCardProps> = ({
  decision,
  rawText,
  onSave,
  isSaved = false,
  confirmedChoice,
  confirmedAtFormatted,
  onOpenConfirmChoice,
  onOpenCoinToss,
}) => {
  const [showRaw, setShowRaw] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [nextStepCompleted, setNextStepCompleted] = useState(false);
  const [timerActive, setTimerActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minute quick start timer

  // Quick timer handler for instant action
  React.useEffect(() => {
    let interval: any = null;
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft]);

  const handleCopy = () => {
    navigator.clipboard.writeText(rawText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
      } else {
        const textToSpeak = `Recommendation: ${decision.recommendation.chosenOption}. ${decision.recommendation.because}. Next step: ${decision.nextStep}`;
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        setIsSpeaking(true);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const handleToggleNextStep = () => {
    const newState = !nextStepCompleted;
    setNextStepCompleted(newState);
    if (newState) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
      });
    }
  };

  const handleSave = () => {
    if (onSave) {
      onSave(decision);
      confetti({
        particleCount: 30,
        spread: 50,
        origin: { y: 0.7 },
      });
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const riskMatrix = decision.riskMatrix || {
    confidencePercent: 86,
    riskLevel: 'Low' as RiskLevel,
    reversibilityType: 'Two-Way Door' as ReversibilityType,
    shortTermImpactScore: 7,
    longTermRiskScore: 4,
    reversibilityScore: 8,
    shortTermImpactDesc: 'Immediate execution clarity and fast setup',
    longTermRiskDesc: 'Controlled scope with minimal sunk costs',
    mitigationAdvice: 'Stage the rollout with a 1-week pilot before scaling.',
  };

  const getRiskBadgeColor = (level?: string) => {
    switch (level?.toLowerCase()) {
      case 'low':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'moderate':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'high':
      case 'critical':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
  };

  const getReversibilityBadgeColor = (type?: string) => {
    const lower = (type || '').toLowerCase();
    if (lower.includes('two-way') || lower.includes('reversible')) {
      return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    }
    if (lower.includes('one-way') || lower.includes('irreversible')) {
      return 'bg-purple-50 text-purple-700 border-purple-200';
    }
    return 'bg-sky-50 text-sky-700 border-sky-200';
  };

  return (
    <div className="w-full bg-white border border-gray-200/80 rounded-2xl p-5 sm:p-7 shadow-xs text-[#111827] transition-all duration-300 space-y-6">
      {/* Top Header / Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-100">
        <div className="flex items-center space-x-2">
          <span className="text-xs uppercase tracking-widest text-gray-500 font-bold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Complex Decision Engine (Tier-2 Suite)</span>
          </span>
          <span className="text-[10px] text-blue-600 font-mono px-2 py-0.5 rounded-full bg-blue-50 border border-blue-100 font-medium">
            Cognitive & Scenario Modeling
          </span>
        </div>

        {/* Action buttons */}
        <div className="flex items-center space-x-1.5">
          {onOpenCoinToss && decision.options.length >= 2 && (
            <button
              onClick={() => onOpenCoinToss(decision.options[0].name, decision.options[1].name)}
              className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold flex items-center space-x-1 border border-amber-200/80 transition-colors"
              title="Flip a coin between Option A & B"
            >
              <Coins className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Flip Coin</span>
            </button>
          )}

          <button
            onClick={handleSpeak}
            className="p-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors text-xs flex items-center space-x-1"
            title={isSpeaking ? "Stop listening" : "Read recommendation"}
          >
            {isSpeaking ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={handleCopy}
            className="p-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors text-xs flex items-center space-x-1"
            title="Copy structured text"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          </button>

          {onSave && (
            <button
              onClick={handleSave}
              className={`p-1.5 rounded-lg transition-colors text-xs flex items-center space-x-1 ${
                isSaved
                  ? 'text-blue-600 bg-blue-50 border border-blue-100'
                  : 'text-gray-400 hover:text-blue-600 hover:bg-gray-50'
              }`}
              title={isSaved ? "Saved to History" : "Save this decision"}
            >
              {isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            </button>
          )}

          <button
            onClick={() => setShowRaw(!showRaw)}
            className="p-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors text-xs"
            title={showRaw ? "Show Visual Cards" : "Show Raw Format"}
          >
            <Code2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showRaw ? (
        <div className="mt-4 p-4 rounded-xl bg-gray-50 font-mono text-xs text-gray-700 whitespace-pre-wrap leading-relaxed border border-gray-200">
          {rawText}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Quick Summary Banner */}
          <div className="px-5 py-4 bg-gray-50/80 border-l-4 border-blue-600 rounded-r-xl">
            <p className="text-base sm:text-lg text-gray-800 leading-relaxed">
              <span className="font-semibold text-gray-900 mr-2">Quick Summary:</span>
              {decision.quickSummary}
            </p>
          </div>

          {/* ADVANCED FEATURE 2: COGNITIVE BIAS DETECTOR & CALIBRATION BOX */}
          {decision.cognitiveBias && (
            <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/50 border border-amber-200/90 shadow-2xs space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center space-x-2 text-amber-950 font-bold text-xs uppercase tracking-wider">
                  <BrainCircuit className="w-4 h-4 text-amber-600" />
                  <span>Cognitive Bias Detector & Calibration</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  Flagged Trap: {decision.cognitiveBias.detectedBias}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white/90 rounded-xl border border-amber-200/70 space-y-1">
                  <span className="font-bold text-amber-900 uppercase text-[10px] tracking-wide">
                    Input Manifestation
                  </span>
                  <p className="text-gray-800 leading-relaxed">
                    {decision.cognitiveBias.manifestation}
                  </p>
                </div>

                <div className="p-3 bg-white/90 rounded-xl border border-amber-200/70 space-y-1">
                  <span className="font-bold text-amber-900 uppercase text-[10px] tracking-wide">
                    De-Biasing Challenge
                  </span>
                  <p className="text-gray-900 font-medium italic leading-relaxed">
                    "{decision.cognitiveBias.debiasingChallenge}"
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* DYNAMIC CONFIDENCE & RISK MATRIX */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-gray-50/90 to-white border border-gray-200/90 shadow-2xs space-y-4">
            {/* Matrix Header Pill Row */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <Gauge className="w-4 h-4 text-blue-600" />
                <span className="text-xs uppercase font-bold tracking-wider text-gray-700">
                  Confidence & Risk Matrix
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Confidence Percentage Badge */}
                <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200/80 text-xs font-bold font-mono">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{riskMatrix.confidencePercent}% Confidence</span>
                </div>

                {/* Risk Level Badge */}
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${getRiskBadgeColor(riskMatrix.riskLevel)}`}>
                  {riskMatrix.riskLevel} Risk
                </span>

                {/* Reversibility Badge */}
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${getReversibilityBadgeColor(riskMatrix.reversibilityType)}`}>
                  <RotateCcw className="w-3 h-3" />
                  <span>{riskMatrix.reversibilityType || 'Two-Way Door'}</span>
                </span>
              </div>
            </div>

            {/* 3 Axes Grid: Short-Term Impact, Long-Term Risk, Reversibility */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {/* Axis 1: Short-Term Impact */}
              <div className="p-3 bg-white rounded-xl border border-gray-100 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500 font-medium">Short-Term Impact</span>
                  <span className="font-bold text-gray-900 font-mono">{riskMatrix.shortTermImpactScore || 7}/10</span>
                </div>
                <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-blue-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${((riskMatrix.shortTermImpactScore || 7) / 10) * 100}%` }}
                  />
                </div>
                {riskMatrix.shortTermImpactDesc && (
                  <p className="text-[11px] text-gray-600 leading-snug line-clamp-2">
                    {riskMatrix.shortTermImpactDesc}
                  </p>
                )}
              </div>

              {/* Axis 2: Long-Term Risk */}
              <div className="p-3 bg-white rounded-xl border border-gray-100 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500 font-medium">Long-Term Risk</span>
                  <span className="font-bold text-gray-900 font-mono">{riskMatrix.longTermRiskScore || 4}/10</span>
                </div>
                <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${
                      (riskMatrix.longTermRiskScore || 4) > 6 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${((riskMatrix.longTermRiskScore || 4) / 10) * 100}%` }}
                  />
                </div>
                {riskMatrix.longTermRiskDesc && (
                  <p className="text-[11px] text-gray-600 leading-snug line-clamp-2">
                    {riskMatrix.longTermRiskDesc}
                  </p>
                )}
              </div>

              {/* Axis 3: Reversibility */}
              <div className="p-3 bg-white rounded-xl border border-gray-100 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500 font-medium">Reversibility</span>
                  <span className="font-bold text-gray-900 font-mono">{riskMatrix.reversibilityScore || 8}/10</span>
                </div>
                <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${((riskMatrix.reversibilityScore || 8) / 10) * 100}%` }}
                  />
                </div>
                {riskMatrix.mitigationAdvice && (
                  <p className="text-[11px] text-gray-600 leading-snug line-clamp-2">
                    {riskMatrix.mitigationAdvice}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* MULTI-PERSPECTIVE PERSONA SIMULATION */}
          {decision.perspectives && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs uppercase font-bold tracking-wider text-gray-500 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Advisory Perspective Simulation</span>
                </h3>
                <span className="text-[10px] text-gray-400">3 Strategic Lenses</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* 1. The Pragmatist */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center space-x-2 text-slate-900 font-semibold text-xs">
                    <span className="w-5 h-5 rounded-md bg-slate-200 text-slate-800 flex items-center justify-center text-[10px]">
                      <Zap className="w-3 h-3 text-amber-600" />
                    </span>
                    <span>The Pragmatist</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {decision.perspectives.pragmatist?.stance || 'Focuses on immediate execution velocity and low operational overhead.'}
                  </p>
                </div>

                {/* 2. The Visionary */}
                <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 space-y-2">
                  <div className="flex items-center space-x-2 text-blue-950 font-semibold text-xs">
                    <span className="w-5 h-5 rounded-md bg-blue-200 text-blue-800 flex items-center justify-center text-[10px]">
                      <Compass className="w-3 h-3 text-blue-700" />
                    </span>
                    <span>The Visionary</span>
                  </div>
                  <p className="text-xs text-blue-900 leading-relaxed">
                    {decision.perspectives.visionary?.stance || 'Emphasizes long-term upside, future compounding, and strategic option value.'}
                  </p>
                </div>

                {/* 3. The Realist */}
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200/80 space-y-2">
                  <div className="flex items-center space-x-2 text-stone-900 font-semibold text-xs">
                    <span className="w-5 h-5 rounded-md bg-stone-200 text-stone-800 flex items-center justify-center text-[10px]">
                      <Shield className="w-3 h-3 text-emerald-700" />
                    </span>
                    <span>The Realist</span>
                  </div>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    {decision.perspectives.realist?.stance || 'Identifies resource friction, potential pitfalls, and operational bottlenecks.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ADVANCED FEATURE 3: WEIGHTED TRADE-OFF MATRIX (PROS/CONS WITH MULTIPLIERS & NUI) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs uppercase font-bold tracking-wider text-gray-600 flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-blue-600" />
                <span>Weighted Trade-Off Matrix (Net Utility Index)</span>
              </h3>
              <span className="text-[10px] text-gray-400 font-mono">Weight (1-5) × Urgency Multiplier</span>
            </div>

            <div
              className={`grid gap-6 ${
                decision.options.length === 3 ? 'grid-cols-1 md:grid-cols-3' : 'grid-cols-1 md:grid-cols-2'
              }`}
            >
              {decision.options.map((opt, idx) => {
                const letter = String.fromCharCode(65 + idx);
                const isRecommended = decision.recommendation.chosenOption.toLowerCase().includes(opt.name.toLowerCase()) ||
                  decision.recommendation.chosenOption.toLowerCase().includes(`option ${letter.toLowerCase()}`);
                const isConfirmedThis = Boolean(
                  confirmedChoice && (
                    confirmedChoice.toLowerCase() === opt.name.toLowerCase() ||
                    confirmedChoice.toLowerCase().includes(opt.name.toLowerCase())
                  )
                );

                const hasWeighted = (opt.weightedPros && opt.weightedPros.length > 0) || (opt.weightedCons && opt.weightedCons.length > 0);

                return (
                  <section 
                    key={idx} 
                    className={`space-y-4 p-5 rounded-2xl transition-all ${
                      isConfirmedThis 
                        ? 'bg-emerald-50/60 border-2 border-emerald-500/80 ring-2 ring-emerald-500/10 shadow-xs' 
                        : 'bg-white border border-gray-200/80 shadow-2xs'
                    }`}
                  >
                    {/* Option Header & Net Utility Index Pill */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                            isConfirmedThis
                              ? 'bg-emerald-600 text-white'
                              : isRecommended
                              ? 'bg-gray-900 text-white'
                              : 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {letter}
                        </div>
                        <div>
                          <h2 className="text-base font-semibold tracking-tight text-gray-900 leading-snug">
                            {opt.name}
                          </h2>
                          {opt.netUtilityIndex !== undefined && (
                            <div className="mt-0.5 flex items-center space-x-1 font-mono text-[11px] font-bold">
                              <span className="text-gray-400">Net Utility Index:</span>
                              <span className={opt.netUtilityIndex >= 0 ? 'text-blue-600 font-extrabold' : 'text-rose-600'}>
                                {opt.netUtilityIndex >= 0 ? `+${opt.netUtilityIndex}` : opt.netUtilityIndex}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-1.5 shrink-0">
                        {isConfirmedThis ? (
                          <span className="text-[10px] uppercase bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold tracking-tight flex items-center gap-1 shadow-2xs">
                            <Check className="w-3 h-3 stroke-[3]" />
                            Confirmed
                          </span>
                        ) : isRecommended ? (
                          <span className="text-[10px] uppercase bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-bold tracking-tight border border-blue-200">
                            Recommended
                          </span>
                        ) : null}
                      </div>
                    </div>

                    {/* Weighted Factors Breakdown */}
                    <div className="space-y-3 text-xs">
                      {/* Pros */}
                      <div className="space-y-2">
                        {hasWeighted && opt.weightedPros ? (
                          opt.weightedPros.map((wPro, pIdx) => (
                            <div key={pIdx} className="p-2 rounded-lg bg-emerald-50/50 border border-emerald-100 flex items-start justify-between gap-2">
                              <div className="flex items-start gap-2">
                                <span className="mt-0.5 w-3.5 h-3.5 bg-emerald-200 text-emerald-900 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0">
                                  +
                                </span>
                                <span className="text-gray-800 leading-snug">{wPro.text}</span>
                              </div>
                              <span className="shrink-0 font-mono text-[10px] font-semibold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.5 rounded">
                                W:{wPro.weight} U:{wPro.urgency}x (+{wPro.netScore})
                              </span>
                            </div>
                          ))
                        ) : (
                          opt.pros.map((pro, pIdx) => (
                            <div key={pIdx} className="flex items-start gap-2">
                              <span className="mt-0.5 w-3.5 h-3.5 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0">
                                +
                              </span>
                              <p className="text-gray-700 leading-snug">{pro}</p>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Cons */}
                      <div className="space-y-2 pt-1">
                        {hasWeighted && opt.weightedCons ? (
                          opt.weightedCons.map((wCon, cIdx) => (
                            <div key={cIdx} className="p-2 rounded-lg bg-rose-50/50 border border-rose-100 flex items-start justify-between gap-2">
                              <div className="flex items-start gap-2">
                                <span className="mt-0.5 w-3.5 h-3.5 bg-rose-200 text-rose-900 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0">
                                  −
                                </span>
                                <span className="text-gray-800 leading-snug">{wCon.text}</span>
                              </div>
                              <span className="shrink-0 font-mono text-[10px] font-semibold text-rose-700 bg-rose-100/80 px-1.5 py-0.5 rounded">
                                W:{wCon.weight} U:{wCon.urgency}x ({wCon.netScore})
                              </span>
                            </div>
                          ))
                        ) : (
                          opt.cons.map((con, cIdx) => (
                            <div key={cIdx} className="flex items-start gap-2">
                              <span className="mt-0.5 w-3.5 h-3.5 bg-rose-100 text-rose-800 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0">
                                −
                              </span>
                              <p className="text-gray-700 leading-snug">{con}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    {/* Choice Confirmation Action */}
                    <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                      {isConfirmedThis ? (
                        <div className="flex items-center justify-between w-full">
                          <div className="text-[11px] text-emerald-800 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Logged on Progress Report</span>
                            {confirmedAtFormatted && (
                              <span className="text-gray-400 font-mono">({confirmedAtFormatted.split(',')[0]})</span>
                            )}
                          </div>
                          {onOpenConfirmChoice && (
                            <button
                              type="button"
                              onClick={() => onOpenConfirmChoice(decision, opt.name)}
                              className="text-[11px] text-emerald-700 hover:text-emerald-900 underline font-medium"
                            >
                              Edit details
                            </button>
                          )}
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onOpenConfirmChoice && onOpenConfirmChoice(decision, opt.name)}
                          className="w-full py-2 px-3 rounded-xl bg-gray-50 hover:bg-gray-100 hover:text-gray-900 text-gray-700 border border-gray-200 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all shadow-2xs"
                        >
                          <Target className="w-3.5 h-3.5 text-blue-600" />
                          <span>Confirm Choice {letter}: {opt.name}</span>
                        </button>
                      )}
                    </div>
                  </section>
                );
              })}
            </div>
          </div>

          {/* ADVANCED FEATURE 1: TEMPORAL PROJECTION ENGINE (SCENARIO FORECASTING) */}
          {decision.temporalForecast && (
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white shadow-md space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-white/10">
                <div className="flex items-center space-x-2">
                  <Hourglass className="w-4 h-4 text-blue-400" />
                  <span className="text-xs uppercase font-bold tracking-wider text-blue-200">
                    Temporal Projection Engine (Scenario Forecasting)
                  </span>
                </div>
                <span className="text-[10px] text-blue-300 font-mono px-2 py-0.5 rounded bg-white/10">
                  10/10/10 Decision Dynamics
                </span>
              </div>

              {/* 3 Horizon Projection Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                {/* 24 Hours */}
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                  <div className="flex items-center space-x-1.5 text-blue-300 font-bold text-[11px] uppercase tracking-wide">
                    <Clock className="w-3.5 h-3.5 text-blue-400" />
                    <span>T+24 Hours (Immediate)</span>
                  </div>
                  <p className="text-gray-200 text-[11px] leading-relaxed">
                    {decision.temporalForecast.immediate24h}
                  </p>
                </div>

                {/* 6 Months */}
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                  <div className="flex items-center space-x-1.5 text-indigo-300 font-bold text-[11px] uppercase tracking-wide">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    <span>T+6 Months (Medium-Term)</span>
                  </div>
                  <p className="text-gray-200 text-[11px] leading-relaxed">
                    {decision.temporalForecast.mediumTerm6m}
                  </p>
                </div>

                {/* 5 Years */}
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                  <div className="flex items-center space-x-1.5 text-purple-300 font-bold text-[11px] uppercase tracking-wide">
                    <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
                    <span>T+5 Years (Long-Term)</span>
                  </div>
                  <p className="text-gray-200 text-[11px] leading-relaxed">
                    {decision.temporalForecast.longTerm5y}
                  </p>
                </div>
              </div>

              {/* Secondary Ripple Effect */}
              {decision.temporalForecast.rippleEffect && (
                <div className="p-3 rounded-xl bg-indigo-900/60 border border-indigo-400/30 flex items-start space-x-2.5 text-xs">
                  <Waves className="w-4 h-4 text-cyan-300 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cyan-200">Secondary Ripple Effect: </span>
                    <span className="text-gray-200 leading-relaxed">
                      {decision.temporalForecast.rippleEffect}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Primary Recommendation Section */}
          <div className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="max-w-xl space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs uppercase font-bold text-blue-700 tracking-wider">
                  Engine Recommendation:
                </span>
                <span className="text-base sm:text-lg font-bold text-gray-900">
                  {decision.recommendation.chosenOption}
                </span>
                {decision.recommendation.utilityDelta && (
                  <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-600 text-white">
                    Δ +{decision.recommendation.utilityDelta} Margin
                  </span>
                )}
                {onOpenConfirmChoice && !confirmedChoice && (
                  <button
                    type="button"
                    onClick={() => onOpenConfirmChoice(decision, decision.recommendation.chosenOption)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold flex items-center space-x-1 transition-colors shadow-2xs"
                    title="Confirm this bot recommendation directly"
                  >
                    <Check className="w-3 h-3 stroke-[3]" />
                    <span>Confirm Choice</span>
                  </button>
                )}
              </div>
              {decision.recommendation.because && (
                <p className="text-gray-700 text-xs sm:text-sm leading-relaxed">
                  <span className="font-semibold text-gray-900">Decisive Factor: </span>
                  {decision.recommendation.because}
                </p>
              )}
            </div>
          </div>

          {/* THE DEVIL'S ADVOCATE CHALLENGE */}
          {decision.devilsAdvocate && (
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-50/90 to-orange-50/70 border border-amber-200/90 shadow-2xs space-y-3">
              <div className="flex items-center space-x-2 text-amber-900 font-bold text-xs uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>The Devil's Advocate Challenge</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {/* Blind Spot */}
                <div className="p-3 bg-white/80 rounded-xl border border-amber-200/60 space-y-1">
                  <span className="font-bold text-amber-900 block text-[11px] uppercase tracking-wide">
                    ⚠️ Potential Blind Spot
                  </span>
                  <p className="text-gray-800 leading-relaxed">
                    {decision.devilsAdvocate.blindSpot}
                  </p>
                </div>

                {/* Counter Argument */}
                <div className="p-3 bg-white/80 rounded-xl border border-amber-200/60 space-y-1">
                  <span className="font-bold text-amber-900 block text-[11px] uppercase tracking-wide">
                    ⚔️ Contrarian Challenge
                  </span>
                  <p className="text-gray-800 leading-relaxed">
                    {decision.devilsAdvocate.counterArgument}
                  </p>
                </div>
              </div>

              {/* Stress-Test Question */}
              {decision.devilsAdvocate.stressTestQuestion && (
                <div className="p-3 bg-amber-100/70 rounded-xl border border-amber-300/60 flex items-start space-x-2 text-xs">
                  <HelpCircle className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-amber-950">Forcing Question: </span>
                    <span className="text-amber-900 italic">
                      "{decision.devilsAdvocate.stressTestQuestion}"
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Next Step & Immediate Action Box */}
          <div className="bg-gray-900 text-white px-6 py-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1 flex-1">
              <div className="flex items-center space-x-2 text-[10px] uppercase tracking-widest text-blue-400 font-bold">
                <Target className="w-3.5 h-3.5" />
                <span>Immediate Next Action</span>
              </div>
              <div className="flex items-start space-x-3 pt-1">
                <button
                  onClick={handleToggleNextStep}
                  className="mt-0.5 text-gray-400 hover:text-emerald-400 transition-colors shrink-0"
                  title={nextStepCompleted ? "Completed" : "Mark as done"}
                >
                  {nextStepCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Circle className="w-4 h-4" />
                  )}
                </button>
                <p className={`font-medium text-sm sm:text-base leading-snug ${nextStepCompleted ? 'line-through text-gray-400' : 'text-gray-100'}`}>
                  {decision.nextStep}
                </p>
              </div>
            </div>

            {/* 2-Min Timer */}
            <div className="shrink-0 flex items-center space-x-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-800">
              {timerActive ? (
                <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-gray-800 text-xs text-blue-300 font-mono">
                  <Clock className="w-3.5 h-3.5 animate-spin" />
                  <span>{formatTimer(timeLeft)}</span>
                  <button
                    onClick={() => setTimerActive(false)}
                    className="ml-1 text-[11px] text-gray-400 hover:text-white underline"
                  >
                    Pause
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setTimeLeft(120);
                    setTimerActive(true);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-xs text-gray-200 hover:text-white flex items-center space-x-1.5 transition-colors border border-gray-700"
                  title="Start 2-minute focus sprint"
                >
                  <Clock className="w-3.5 h-3.5 text-blue-400" />
                  <span>2-Min Quick Start</span>
                </button>
              )}
            </div>
          </div>

          {/* Safety Notice */}
          {decision.safetyNotice && (
            <div className="px-5 py-3 bg-gray-50 border border-gray-200 rounded-xl">
              <p className="text-[10px] text-gray-500 text-center uppercase tracking-widest italic font-medium">
                {decision.safetyNotice}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
