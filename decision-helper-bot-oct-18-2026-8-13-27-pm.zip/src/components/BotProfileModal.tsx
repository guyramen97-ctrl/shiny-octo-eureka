import React, { useState } from 'react';
import { BotProfile } from '../types';
import { X, User, Check, Bot } from 'lucide-react';

interface BotProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: BotProfile;
  onSaveProfile: (profile: BotProfile) => void;
}

const PRESET_PERSONAS = [
  {
    name: 'Smart Friend (Default)',
    persona: 'Friendly, neutral, practical, conversational, zero fluff',
    description: 'Balanced, reliable friend who helps you decide without any drama or lectures.',
  },
  {
    name: 'Strict Coach',
    persona: 'Strict coach, direct, high urgency, zero excuses',
    description: 'Pushes you to stop stalling, pick the optimal move, and execute immediately.',
  },
  {
    name: 'Choice Genie',
    persona: 'Choice Genie, swift magic of clarity, granting clarity wishes',
    description: 'Whimsical yet razor-sharp helper that turns dilemma confusion into instant clarity.',
  },
  {
    name: 'Pragmatic Analyst',
    persona: 'Analytical, pragmatic, ROI-focused, risk-aware',
    description: 'Dissects trade-offs like an executive strategist with laser focus on practical outcomes.',
  },
  {
    name: 'Gentle Guide',
    persona: 'Calm, gentle, stress-reducing, comforting, reassuring',
    description: 'Eases decision paralysis and anxiety with supportive, low-pressure guidance.',
  },
];

export const BotProfileModal: React.FC<BotProfileModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onSaveProfile,
}) => {
  const [name, setName] = useState(currentProfile.name);
  const [persona, setPersona] = useState(currentProfile.persona);
  const [customPersona, setCustomPersona] = useState('');

  if (!isOpen) return null;

  const handleSelectPreset = (preset: typeof PRESET_PERSONAS[0]) => {
    setPersona(preset.persona);
    setCustomPersona('');
  };

  const handleSave = () => {
    const finalPersona = customPersona.trim() || persona;
    onSaveProfile({
      name: name.trim() || 'Decision Helper Bot',
      persona: finalPersona,
      description: `Persona: ${finalPersona}`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-white border border-gray-100 rounded-2xl shadow-xl p-6 sm:p-8 text-gray-900 relative animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-sm">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-gray-900">
              Bot Profile & Persona
            </h2>
            <p className="text-xs text-gray-500">
              Customize the name and personality style of your decision assistant
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Bot Name Input */}
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1.5">
              Assistant Name
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Decision Helper Bot, Choice Genie, Coach Marcus..."
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-gray-400"
              />
              <User className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
            </div>
          </div>

          {/* Persona Presets */}
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2">
              Select Personality Archetype
            </label>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {PRESET_PERSONAS.map((preset, idx) => {
                const isSelected = persona === preset.persona && !customPersona;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs flex items-start justify-between ${
                      isSelected
                        ? 'bg-blue-50/70 border-blue-500 text-blue-950 shadow-xs'
                        : 'bg-gray-50/70 border-gray-200/80 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-gray-900 text-sm mb-0.5">
                        {preset.name}
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed">
                        {preset.description}
                      </p>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-blue-600 shrink-0 mt-1 ml-2" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Persona input */}
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-1.5">
              Or Custom Persona Instructions
            </label>
            <input
              type="text"
              value={customPersona}
              onChange={(e) => setCustomPersona(e.target.value)}
              placeholder="e.g. Act like a pirate captain, Speak in concise haikus..."
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-gray-400"
            />
          </div>

          <p className="text-[11px] text-gray-400 italic">
            Tip: You can also change the name or personality directly in chat at any time (e.g. "Change your name to Choice Genie" or "Act like a strict coach")!
          </p>
        </div>

        {/* Footer Actions */}
        <div className="mt-6 flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded-xl text-xs font-medium bg-gray-900 hover:bg-gray-800 text-white transition-colors shadow-sm"
          >
            Apply Profile
          </button>
        </div>
      </div>
    </div>
  );
};

