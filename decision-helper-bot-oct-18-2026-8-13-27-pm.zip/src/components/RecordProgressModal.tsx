import React, { useState } from 'react';
import { SavedDecision, ProgressLog, ProgressStatus } from '../types';
import { X, Calendar, Clock, CheckCircle2, AlertCircle, PlayCircle, StopCircle, ArrowRight, Target, Check } from 'lucide-react';

interface RecordProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  decision: SavedDecision | null;
  onSaveProgress: (
    decisionId: string,
    log: Omit<ProgressLog, 'id'>,
    newStatus: ProgressStatus,
    newPercent: number,
    updatedConfirmedChoice?: string
  ) => void;
}

export const RecordProgressModal: React.FC<RecordProgressModalProps> = ({
  isOpen,
  onClose,
  decision,
  onSaveProgress,
}) => {
  if (!isOpen || !decision) return null;

  // Format local ISO datetime for input: YYYY-MM-DDTHH:mm
  const getNowISOString = () => {
    const now = new Date();
    const offset = now.getTimezoneOffset() * 60000;
    const localTime = new Date(now.getTime() - offset);
    return localTime.toISOString().slice(0, 16);
  };

  const [dateTime, setDateTime] = useState<string>(getNowISOString());
  const [status, setStatus] = useState<ProgressStatus>(decision.status || (decision.nextStepCompleted ? 'completed' : 'in_progress'));
  const [progressPercent, setProgressPercent] = useState<number>(decision.progressPercent ?? (decision.nextStepCompleted ? 100 : 25));
  const [note, setNote] = useState<string>('');
  const [confirmedChoice, setConfirmedChoice] = useState<string>(
    decision.confirmedChoice || decision.parsedDecision.recommendation.chosenOption || decision.parsedDecision.options[0]?.name || ''
  );

  const handleStatusChange = (newStatus: ProgressStatus) => {
    setStatus(newStatus);
    if (newStatus === 'completed' && progressPercent < 100) {
      setProgressPercent(100);
    } else if (newStatus === 'not_started') {
      setProgressPercent(0);
    } else if (newStatus === 'in_progress' && (progressPercent === 0 || progressPercent === 100)) {
      setProgressPercent(50);
    }
  };

  const handlePercentChange = (val: number) => {
    setProgressPercent(val);
    if (val === 100) {
      setStatus('completed');
    } else if (val === 0) {
      setStatus('not_started');
    } else if (status !== 'blocked') {
      setStatus('in_progress');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedDate = new Date(dateTime);
    const timestamp = isNaN(parsedDate.getTime()) ? Date.now() : parsedDate.getTime();
    
    const formatted = parsedDate.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    onSaveProgress(
      decision.id,
      {
        timestamp,
        dateTimeFormatted: formatted,
        status,
        note: note.trim() || `Progress recorded: ${status.replace('_', ' ')} (${progressPercent}%) [Choice: ${confirmedChoice}]`,
        progressPercent,
      },
      status,
      progressPercent,
      confirmedChoice
    );

    onClose();
  };

  const setQuickTime = (type: 'now' | 'yesterday' | 'tomorrow') => {
    const d = new Date();
    if (type === 'yesterday') d.setDate(d.getDate() - 1);
    if (type === 'tomorrow') d.setDate(d.getDate() + 1);
    const offset = d.getTimezoneOffset() * 60000;
    const localTime = new Date(d.getTime() - offset);
    setDateTime(localTime.toISOString().slice(0, 16));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-white border border-gray-100 rounded-2xl shadow-xl p-6 sm:p-8 text-[#111827] relative animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center space-x-3 mb-5">
          <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-sm">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-gray-900">
              Record Progress & Date
            </h2>
            <p className="text-xs text-gray-500 line-clamp-1">
              {decision.title}
            </p>
          </div>
        </div>

        {/* Confirmed Choice Section */}
        <div className="mb-5 p-3.5 bg-gray-50 border border-gray-200/80 rounded-xl space-y-2">
          <label className="block text-[11px] font-bold text-gray-600 uppercase tracking-wider flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-emerald-600" />
            <span>Confirmed Choice for this Decision</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {decision.parsedDecision.options.map((opt, idx) => {
              const letter = String.fromCharCode(65 + idx);
              const isSelected = confirmedChoice.toLowerCase() === opt.name.toLowerCase();

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setConfirmedChoice(opt.name)}
                  className={`p-2 rounded-lg border text-left text-xs transition-all flex items-center justify-between ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-semibold'
                      : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <span className="truncate mr-1">{letter}: {opt.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 stroke-[3]" />}
                </button>
              );
            })}
          </div>
          <div className="pt-1 text-[11px] text-gray-500">
            <span className="font-semibold text-gray-700">Next Action: </span>
            {decision.parsedDecision.nextStep}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Progress Date & Time Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                Progress Date & Time
              </label>
              <div className="flex items-center space-x-1.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => setQuickTime('now')}
                  className="px-2 py-0.5 rounded bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium transition-colors"
                >
                  Now
                </button>
                <button
                  type="button"
                  onClick={() => setQuickTime('yesterday')}
                  className="px-2 py-0.5 rounded bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors"
                >
                  Yesterday
                </button>
              </div>
            </div>
            <input
              type="datetime-local"
              required
              value={dateTime}
              onChange={(e) => setDateTime(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-mono"
            />
          </div>

          {/* Status Selection */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Execution Status
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleStatusChange('not_started')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center justify-center space-y-1 transition-all ${
                  status === 'not_started'
                    ? 'bg-gray-900 text-white border-gray-900 shadow-xs'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <StopCircle className="w-4 h-4" />
                <span>Not Started</span>
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('in_progress')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center justify-center space-y-1 transition-all ${
                  status === 'in_progress'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <PlayCircle className="w-4 h-4" />
                <span>In Progress</span>
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('completed')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center justify-center space-y-1 transition-all ${
                  status === 'completed'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Completed</span>
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('blocked')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center justify-center space-y-1 transition-all ${
                  status === 'blocked'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <AlertCircle className="w-4 h-4" />
                <span>On Hold</span>
              </button>
            </div>
          </div>

          {/* Progress Percent Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                Progress Percentage
              </label>
              <span className="text-xs font-bold text-gray-900 font-mono">
                {progressPercent}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={progressPercent}
              onChange={(e) => handlePercentChange(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-900"
            />
            <div className="flex justify-between text-[10px] text-gray-400 mt-1 font-mono">
              <button type="button" onClick={() => handlePercentChange(0)} className="hover:text-gray-900">0%</button>
              <button type="button" onClick={() => handlePercentChange(25)} className="hover:text-gray-900">25%</button>
              <button type="button" onClick={() => handlePercentChange(50)} className="hover:text-gray-900">50%</button>
              <button type="button" onClick={() => handlePercentChange(75)} className="hover:text-gray-900">75%</button>
              <button type="button" onClick={() => handlePercentChange(100)} className="hover:text-gray-900">100%</button>
            </div>
          </div>

          {/* Progress Notes / Report Details */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              Progress Update / Notes
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Detail what steps you took, key discoveries, order confirmations, or why something is delayed..."
              className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-gray-400 resize-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="mt-6 flex items-center justify-end space-x-2.5 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-medium bg-gray-900 hover:bg-gray-800 text-white transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <span>Save Progress Log</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

