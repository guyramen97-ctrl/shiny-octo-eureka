import React, { useState } from 'react';
import {
  FinancialDecisionModel,
  FinancialOptionCost,
  ActualExpenseLog,
  SavedDecision,
  ParsedDecision,
} from '../types';
import {
  DollarSign,
  Plus,
  Trash2,
  TrendingUp,
  TrendingDown,
  Calculator,
  Wallet,
  Calendar,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  PieChart,
  Layers,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface FinancialDashboardProps {
  financialModels: FinancialDecisionModel[];
  onSaveModels: (models: FinancialDecisionModel[]) => void;
  savedDecisions: SavedDecision[];
  onCreateFromDecision?: (decision: ParsedDecision) => void;
}

export const FinancialDashboard: React.FC<FinancialDashboardProps> = ({
  financialModels,
  onSaveModels,
  savedDecisions,
}) => {
  const [selectedModelId, setSelectedModelId] = useState<string>(financialModels[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState(financialModels.length === 0);

  // New Financial Model Form
  const [newTitle, setNewTitle] = useState('');
  const [newCurrency, setNewCurrency] = useState('$');
  const [newBudgetCap, setNewBudgetCap] = useState<number>(10000);
  const [newOptions, setNewOptions] = useState<
    { name: string; upfront: number; recurring: number; monthlyReturn: number; weeks: number }[]
  >([
    { name: 'Option A: Cloud SaaS Vendor', upfront: 2000, recurring: 500, monthlyReturn: 1200, weeks: 2 },
    { name: 'Option B: Custom In-House Build', upfront: 12000, recurring: 100, monthlyReturn: 1800, weeks: 8 },
  ]);
  const [selectedDecisionId, setSelectedDecisionId] = useState('');

  // Add Expense Log Form
  const [newExpenseDesc, setNewExpenseDesc] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState<number>(500);
  const [newExpenseCategory, setNewExpenseCategory] = useState<'upfront' | 'recurring' | 'unforeseen' | 'savings'>('upfront');

  const activeModel = financialModels.find((m) => m.id === selectedModelId) || financialModels[0];

  const handleSelectDecision = (decisionId: string) => {
    setSelectedDecisionId(decisionId);
    const target = savedDecisions.find((d) => d.id === decisionId);
    if (target) {
      setNewTitle(`Financial Model: ${target.parsedDecision.quickSummary || target.title}`);
      setNewOptions(
        target.parsedDecision.options.map((o, idx) => ({
          name: o.name,
          upfront: idx === 0 ? 3000 : 8000,
          recurring: idx === 0 ? 400 : 150,
          monthlyReturn: idx === 0 ? 1000 : 1500,
          weeks: idx === 0 ? 2 : 6,
        }))
      );
    }
  };

  const calculateFinancialMetrics = (
    upfront: number,
    monthlyRecurring: number,
    monthlyReturn: number
  ): {
    oneYearNet: number;
    threeYearNet: number;
    paybackMonths: number | null;
  } => {
    const netMonthly = monthlyReturn - monthlyRecurring;
    const oneYearNet = netMonthly * 12 - upfront;
    const threeYearNet = netMonthly * 36 - upfront;

    let paybackMonths: number | null = null;
    if (netMonthly > 0) {
      paybackMonths = Math.ceil(upfront / netMonthly);
    }

    return {
      oneYearNet,
      threeYearNet,
      paybackMonths,
    };
  };

  const handleCreateModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const parsedOptions: FinancialOptionCost[] = newOptions.map((opt) => {
      const metrics = calculateFinancialMetrics(opt.upfront, opt.recurring, opt.monthlyReturn);
      return {
        optionName: opt.name,
        upfrontCost: opt.upfront,
        recurringMonthlyCost: opt.recurring,
        expectedMonthlyReturnOrSavings: opt.monthlyReturn,
        implementationWeeks: opt.weeks,
        oneYearNetCostOrBenefit: metrics.oneYearNet,
        threeYearNetCostOrBenefit: metrics.threeYearNet,
        paybackPeriodMonths: metrics.paybackMonths,
        riskContingencyPercent: 15,
      };
    });

    const newModel: FinancialDecisionModel = {
      id: `fin-${now}`,
      decisionId: selectedDecisionId || undefined,
      title: newTitle.trim(),
      currency: newCurrency,
      budgetCap: newBudgetCap > 0 ? newBudgetCap : undefined,
      options: parsedOptions,
      actualExpenses: [],
      createdAt: now,
      createdAtFormatted: formattedNow,
    };

    const updated = [newModel, ...financialModels];
    onSaveModels(updated);
    setSelectedModelId(newModel.id);
    setIsCreatingNew(false);
    setNewTitle('');

    confetti({
      particleCount: 35,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModel || !newExpenseDesc.trim() || newExpenseAmount <= 0) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

    const newExpense: ActualExpenseLog = {
      id: `exp-${now}`,
      date: formattedNow,
      timestamp: now,
      description: newExpenseDesc.trim(),
      amount: newExpenseAmount,
      category: newExpenseCategory,
    };

    const updated = financialModels.map((m) =>
      m.id === activeModel.id
        ? { ...m, actualExpenses: [newExpense, ...m.actualExpenses] }
        : m
    );

    onSaveModels(updated);
    setNewExpenseDesc('');
    setNewExpenseAmount(500);

    confetti({
      particleCount: 25,
      spread: 45,
      origin: { y: 0.8 },
    });
  };

  const handleDeleteExpense = (expId: string) => {
    if (!activeModel) return;
    const updated = financialModels.map((m) =>
      m.id === activeModel.id
        ? { ...m, actualExpenses: m.actualExpenses.filter((e) => e.id !== expId) }
        : m
    );
    onSaveModels(updated);
  };

  const handleDeleteModel = (id: string) => {
    const updated = financialModels.filter((m) => m.id !== id);
    onSaveModels(updated);
    if (selectedModelId === id) {
      setSelectedModelId(updated[0]?.id || '');
      if (updated.length === 0) setIsCreatingNew(true);
    }
  };

  // Calculate total actual spend
  const totalActualSpent =
    activeModel?.actualExpenses.reduce((sum, item) => sum + item.amount, 0) || 0;

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-8 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
        <div>
          <div className="flex items-center space-x-2 text-blue-600 text-xs font-bold uppercase tracking-wider mb-1">
            <DollarSign className="w-4 h-4" />
            <span>Capital Allocation & ROI Modeling</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 tracking-tight">
            Financial Impact & Budget Tracking
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
            Model upfront costs, recurring burn, payback horizons, and track realized actual expenses against your budget.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingNew(!isCreatingNew)}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm shrink-0 self-start sm:self-auto"
        >
          {isCreatingNew ? (
            <span>View Active Models</span>
          ) : (
            <>
              <Plus className="w-4 h-4" />
              <span>Create Financial Model</span>
            </>
          )}
        </button>
      </div>

      {/* CREATE NEW FINANCIAL MODEL FORM */}
      {isCreatingNew ? (
        <form
          onSubmit={handleCreateModel}
          className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-6"
        >
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-blue-600" />
              <span>Setup Financial Comparison Model</span>
            </h3>
            {savedDecisions.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-500">Import from:</span>
                <select
                  value={selectedDecisionId}
                  onChange={(e) => handleSelectDecision(e.target.value)}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Select Saved Decision --</option>
                  {savedDecisions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                  Model Title / Project Name *
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Infrastructure Cost: Cloud vs On-Prem"
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                  Budget Cap / Envelope
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-mono text-xs">
                    $
                  </span>
                  <input
                    type="number"
                    value={newBudgetCap}
                    onChange={(e) => setNewBudgetCap(parseInt(e.target.value) || 0)}
                    className="w-full pl-7 pr-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Financial Parameters per Option */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600">
                Options Cost & Value Parameters
              </label>

              {newOptions.map((opt, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-gray-50/80 rounded-xl border border-gray-200 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-gray-800">
                      Option {String.fromCharCode(65 + idx)}:
                    </span>
                    <input
                      type="text"
                      value={opt.name}
                      onChange={(e) => {
                        const copy = [...newOptions];
                        copy[idx].name = e.target.value;
                        setNewOptions(copy);
                      }}
                      className="text-xs px-2.5 py-1 bg-white border border-gray-200 rounded-lg flex-1 mx-2 font-medium"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-gray-500 block mb-1">Upfront Cost ($)</span>
                      <input
                        type="number"
                        value={opt.upfront}
                        onChange={(e) => {
                          const copy = [...newOptions];
                          copy[idx].upfront = parseFloat(e.target.value) || 0;
                          setNewOptions(copy);
                        }}
                        className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded font-mono"
                      />
                    </div>

                    <div>
                      <span className="text-gray-500 block mb-1">Monthly Burn ($/mo)</span>
                      <input
                        type="number"
                        value={opt.recurring}
                        onChange={(e) => {
                          const copy = [...newOptions];
                          copy[idx].recurring = parseFloat(e.target.value) || 0;
                          setNewOptions(copy);
                        }}
                        className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded font-mono"
                      />
                    </div>

                    <div>
                      <span className="text-gray-500 block mb-1">Monthly Value ($/mo)</span>
                      <input
                        type="number"
                        value={opt.monthlyReturn}
                        onChange={(e) => {
                          const copy = [...newOptions];
                          copy[idx].monthlyReturn = parseFloat(e.target.value) || 0;
                          setNewOptions(copy);
                        }}
                        className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded font-mono"
                      />
                    </div>

                    <div>
                      <span className="text-gray-500 block mb-1">Setup Time (Weeks)</span>
                      <input
                        type="number"
                        value={opt.weeks}
                        onChange={(e) => {
                          const copy = [...newOptions];
                          copy[idx].weeks = parseInt(e.target.value) || 1;
                          setNewOptions(copy);
                        }}
                        className="w-full px-2 py-1.5 bg-white border border-gray-200 rounded font-mono"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
            {financialModels.length > 0 && (
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              Generate Financial Model
            </button>
          </div>
        </form>
      ) : null}

      {/* ACTIVE FINANCIAL MODEL VIEW */}
      {financialModels.length > 0 && activeModel && !isCreatingNew ? (
        <div className="space-y-6">
          {/* Multi-model tabs */}
          {financialModels.length > 1 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {financialModels.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setSelectedModelId(m.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                    selectedModelId === m.id
                      ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                      : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {m.title.length > 30 ? m.title.substring(0, 30) + '...' : m.title}
                </button>
              ))}
            </div>
          )}

          {/* Main Financial Model Dashboard */}
          <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-gray-100">
              <div>
                <span className="text-xs text-gray-400 font-mono">
                  Created {activeModel.createdAtFormatted}
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mt-0.5">
                  {activeModel.title}
                </h3>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleDeleteModel(activeModel.id)}
                  className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Delete Model"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* SIDE-BY-SIDE FINANCIAL COMPARISON CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {activeModel.options.map((opt, idx) => {
                const isPositiveOneYear = opt.oneYearNetCostOrBenefit >= 0;
                const isPositiveThreeYear = opt.threeYearNetCostOrBenefit >= 0;

                return (
                  <div
                    key={idx}
                    className="p-5 rounded-2xl bg-gradient-to-b from-gray-50/90 to-white border border-gray-200 shadow-2xs space-y-4"
                  >
                    {/* Option Title */}
                    <div className="flex items-center justify-between pb-2 border-b border-gray-100">
                      <div className="flex items-center space-x-2">
                        <span className="w-6 h-6 rounded-full bg-gray-900 text-white font-bold text-xs flex items-center justify-center">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="text-sm font-bold text-gray-900">{opt.optionName}</span>
                      </div>
                      {opt.paybackPeriodMonths !== null && (
                        <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                          {opt.paybackPeriodMonths} Mo Payback
                        </span>
                      )}
                    </div>

                    {/* Cost Breakdown Grid */}
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="p-2.5 rounded-xl bg-white border border-gray-100 shadow-2xs">
                        <span className="text-[10px] uppercase text-gray-400 font-bold block">
                          Upfront
                        </span>
                        <span className="font-mono font-bold text-gray-900 text-sm">
                          ${opt.upfrontCost.toLocaleString()}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-gray-100 shadow-2xs">
                        <span className="text-[10px] uppercase text-gray-400 font-bold block">
                          Monthly Burn
                        </span>
                        <span className="font-mono font-bold text-rose-600 text-sm">
                          -${opt.recurringMonthlyCost.toLocaleString()}/mo
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-gray-100 shadow-2xs">
                        <span className="text-[10px] uppercase text-gray-400 font-bold block">
                          Monthly Value
                        </span>
                        <span className="font-mono font-bold text-emerald-600 text-sm">
                          +${opt.expectedMonthlyReturnOrSavings.toLocaleString()}/mo
                        </span>
                      </div>
                    </div>

                    {/* Net ROI Projection */}
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div className="p-3 rounded-xl bg-gray-100/70 space-y-1">
                        <div className="text-[10px] uppercase font-bold text-gray-500">
                          1-Year Net Financial
                        </div>
                        <div
                          className={`text-base font-bold font-mono ${
                            isPositiveOneYear ? 'text-emerald-700' : 'text-rose-700'
                          }`}
                        >
                          {isPositiveOneYear ? '+' : ''}${opt.oneYearNetCostOrBenefit.toLocaleString()}
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-gray-100/70 space-y-1">
                        <div className="text-[10px] uppercase font-bold text-gray-500">
                          3-Year Net Financial
                        </div>
                        <div
                          className={`text-base font-bold font-mono ${
                            isPositiveThreeYear ? 'text-emerald-700' : 'text-rose-700'
                          }`}
                        >
                          {isPositiveThreeYear ? '+' : ''}${opt.threeYearNetCostOrBenefit.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* BUDGET TRACKING & REALIZED EXPENSES LOG */}
            <div className="space-y-4 pt-4 border-t border-gray-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center gap-1.5">
                    <Wallet className="w-4 h-4 text-emerald-600" />
                    <span>Realized Budget & Spend Ledger</span>
                  </h4>
                  <span className="text-xs text-gray-500">
                    Track real-world invoices and expenditures against original estimates
                  </span>
                </div>

                {activeModel.budgetCap && (
                  <div className="text-right">
                    <span className="text-xs text-gray-500">Budget Spent: </span>
                    <span className="font-mono font-bold text-sm text-gray-900">
                      ${totalActualSpent.toLocaleString()} / ${activeModel.budgetCap.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>

              {/* Budget Progress Bar */}
              {activeModel.budgetCap && (
                <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      totalActualSpent > activeModel.budgetCap ? 'bg-rose-500' : 'bg-blue-600'
                    }`}
                    style={{
                      width: `${Math.min(100, (totalActualSpent / activeModel.budgetCap) * 100)}%`,
                    }}
                  />
                </div>
              )}

              {/* Add Expense Form */}
              <form
                onSubmit={handleAddExpense}
                className="bg-gray-50 p-3.5 rounded-xl border border-gray-200 grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end"
              >
                <div className="sm:col-span-2">
                  <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">
                    Expense / Invoice Description
                  </label>
                  <input
                    type="text"
                    value={newExpenseDesc}
                    onChange={(e) => setNewExpenseDesc(e.target.value)}
                    placeholder="e.g. Migration consultant fee"
                    className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">
                    Amount ($)
                  </label>
                  <input
                    type="number"
                    value={newExpenseAmount}
                    onChange={(e) => setNewExpenseAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-mono"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center space-x-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Expense</span>
                </button>
              </form>

              {/* Expense List */}
              {activeModel.actualExpenses.length > 0 ? (
                <div className="space-y-2">
                  {activeModel.actualExpenses.map((exp) => (
                    <div
                      key={exp.id}
                      className="p-3 bg-white rounded-xl border border-gray-200 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2.5">
                        <span className="font-mono text-gray-400 text-[11px]">{exp.date}</span>
                        <span className="font-semibold text-gray-800">{exp.description}</span>
                        <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-gray-100 text-gray-600">
                          {exp.category}
                        </span>
                      </div>

                      <div className="flex items-center space-x-3">
                        <span className="font-mono font-bold text-gray-900">
                          -${exp.amount.toLocaleString()}
                        </span>
                        <button
                          onClick={() => handleDeleteExpense(exp.id)}
                          className="text-gray-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-xs text-gray-400 bg-white rounded-xl border border-dashed border-gray-200">
                  No actual expenses logged yet. Add invoice entries above as execution begins.
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
