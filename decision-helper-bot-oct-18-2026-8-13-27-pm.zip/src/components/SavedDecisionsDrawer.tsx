import React, { useState } from 'react';
import { SavedDecision, ProgressStatus, ParsedDecision } from '../types';
import { 
  X, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  Download, 
  Bookmark, 
  Clock, 
  Plus, 
  TrendingUp, 
  FileText, 
  ChevronDown, 
  ChevronUp,
  PlayCircle,
  AlertCircle,
  StopCircle,
  Target,
  Check
} from 'lucide-react';

interface SavedDecisionsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedDecisions: SavedDecision[];
  onToggleNextStep: (id: string) => void;
  onDeleteDecision: (id: string) => void;
  onSelectDecision: (decision: SavedDecision) => void;
  onClearAll: () => void;
  onOpenRecordModal: (decision: SavedDecision) => void;
  onOpenReportModal: () => void;
  onOpenConfirmChoice?: (decision: ParsedDecision, optionName?: string) => void;
}

export const SavedDecisionsDrawer: React.FC<SavedDecisionsDrawerProps> = ({
  isOpen,
  onClose,
  savedDecisions,
  onToggleNextStep,
  onDeleteDecision,
  onSelectDecision,
  onClearAll,
  onOpenRecordModal,
  onOpenReportModal,
  onOpenConfirmChoice,
}) => {
  const [expandedLogs, setExpandedLogs] = useState<Record<string, boolean>>({});

  if (!isOpen) return null;

  const toggleExpand = (id: string) => {
    setExpandedLogs((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(savedDecisions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `decisions-export-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getStatusBadge = (status?: ProgressStatus, percent?: number) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-2.5 h-2.5 mr-1" />
            Completed
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
            <PlayCircle className="w-2.5 h-2.5 mr-1" />
            In Progress ({percent ?? 50}%)
          </span>
        );
      case 'blocked':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <AlertCircle className="w-2.5 h-2.5 mr-1" />
            On Hold
          </span>
        );
      case 'not_started':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-700 border border-gray-200">
            <StopCircle className="w-2.5 h-2.5 mr-1" />
            Not Started
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-lg bg-white border-l border-gray-100 shadow-2xl flex flex-col text-gray-900">
          {/* Drawer Header */}
          <div className="p-5 sm:p-6 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold text-sm">
                <Bookmark className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-gray-900">
                  Saved Decisions ({savedDecisions.length})
                </h2>
                <p className="text-xs text-gray-500">
                  Track choices, dates & execution progress
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-1.5">
              <button
                onClick={onOpenReportModal}
                className="px-2.5 py-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold flex items-center space-x-1 transition-colors border border-blue-200/80"
                title="View Comprehensive Progress Report"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Progress Report</span>
              </button>

              {savedDecisions.length > 0 && (
                <button
                  onClick={handleExportJSON}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                  title="Export decisions JSON"
                >
                  <Download className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Decision List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {savedDecisions.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3 text-gray-400">
                  <Bookmark className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-semibold text-gray-800 mb-1">
                  No saved decisions yet
                </h3>
                <p className="text-xs text-gray-500 max-w-xs mx-auto">
                  When the bot helps you make a choice, click the bookmark icon to save it here and track your progress with exact dates & times!
                </p>
              </div>
            ) : (
              savedDecisions.map((item) => {
                const effectiveStatus: ProgressStatus = item.status || (item.nextStepCompleted ? 'completed' : 'not_started');
                const effectivePercent = item.progressPercent ?? (item.nextStepCompleted ? 100 : 0);
                const logs = item.progressLogs || [];
                const isExpanded = expandedLogs[item.id] ?? false;

                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-gray-50/80 border border-gray-200/80 hover:border-gray-300 transition-all space-y-3 relative group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-400 block font-mono">
                            {item.date}
                          </span>
                          {getStatusBadge(effectiveStatus, effectivePercent)}
                        </div>
                        <h4 className="text-sm font-semibold text-gray-900 mt-1 line-clamp-2">
                          {item.title}
                        </h4>
                      </div>
                      <button
                        onClick={() => onDeleteDecision(item.id)}
                        className="p-1 text-gray-400 hover:text-rose-500 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Confirmed Choice or Recommendation pill */}
                    {item.confirmedChoice ? (
                      <div className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-50/80 border border-emerald-200 text-xs">
                        <div className="flex items-center space-x-1.5 truncate">
                          <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider flex items-center gap-1">
                            <Target className="w-3 h-3 text-emerald-600" />
                            Confirmed:
                          </span>
                          <span className="font-semibold text-emerald-950 truncate">
                            {item.confirmedChoice}
                          </span>
                        </div>
                        {onOpenConfirmChoice && (
                          <button
                            onClick={() => onOpenConfirmChoice(item.parsedDecision, item.confirmedChoice)}
                            className="text-[11px] text-emerald-700 hover:text-emerald-900 underline ml-2 shrink-0 font-medium"
                          >
                            Edit
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-between p-2.5 rounded-lg bg-blue-50/80 border border-blue-100 text-xs">
                        <div className="flex items-center space-x-1.5 truncate">
                          <span className="text-[10px] uppercase font-bold text-blue-600 tracking-wider">Choice:</span>
                          <span className="font-semibold text-blue-900 truncate">
                            {item.parsedDecision.recommendation.chosenOption}
                          </span>
                        </div>
                        {onOpenConfirmChoice && (
                          <button
                            onClick={() => onOpenConfirmChoice(item.parsedDecision, item.parsedDecision.recommendation.chosenOption)}
                            className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold tracking-tight shrink-0 transition-colors shadow-2xs"
                          >
                            Confirm Choice
                          </button>
                        )}
                      </div>
                    )}

                    {/* Next Step Checkbox & Completed Date */}
                    <div className="pt-2 border-t border-gray-200/80 space-y-2 text-xs">
                      <div className="flex items-start space-x-2.5">
                        <button
                          onClick={() => onToggleNextStep(item.id)}
                          className="text-gray-400 hover:text-emerald-600 mt-0.5 shrink-0"
                        >
                          {item.nextStepCompleted ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </button>
                        <div className="flex-1">
                          <span className={`text-gray-700 leading-snug block ${item.nextStepCompleted ? 'line-through text-gray-400' : ''}`}>
                            <strong className="text-gray-900">Next Step: </strong>
                            {item.parsedDecision.nextStep}
                          </span>
                          {item.completedAtFormatted && (
                            <span className="text-[10px] text-emerald-700 font-medium block mt-0.5">
                              Completed: {item.completedAtFormatted}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-gray-500">Progress</span>
                          <span className="font-bold text-gray-900 font-mono">{effectivePercent}%</span>
                        </div>
                        <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${
                              effectiveStatus === 'completed'
                                ? 'bg-emerald-600'
                                : effectiveStatus === 'blocked'
                                ? 'bg-amber-600'
                                : 'bg-blue-600'
                            }`}
                            style={{ width: `${effectivePercent}%` }}
                          />
                        </div>
                      </div>

                      {/* Quick Action & Log Progress button */}
                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => onOpenRecordModal(item)}
                          className="px-2.5 py-1 rounded-lg bg-white hover:bg-gray-100 text-gray-700 font-medium text-[11px] border border-gray-200 flex items-center space-x-1 transition-colors"
                        >
                          <Clock className="w-3 h-3 text-blue-600" />
                          <span>Record Progress Date</span>
                        </button>

                        <button
                          onClick={() => toggleExpand(item.id)}
                          className="text-[11px] text-gray-500 hover:text-gray-900 flex items-center space-x-0.5"
                        >
                          <span>{logs.length} logs</span>
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                      </div>

                      {/* Expanded mini timeline */}
                      {isExpanded && (
                        <div className="mt-2 pl-2 border-l-2 border-gray-200 space-y-2 text-[11px]">
                          {logs.length === 0 ? (
                            <span className="text-gray-400 italic">No progress logs recorded yet.</span>
                          ) : (
                            logs.map((log) => (
                              <div key={log.id} className="space-y-0.5">
                                <div className="flex items-center space-x-1.5">
                                  <span className="font-mono text-gray-800 font-medium">{log.dateTimeFormatted}:</span>
                                  <span className="text-blue-700 font-semibold">{log.progressPercent}%</span>
                                </div>
                                <p className="text-gray-600">{log.note}</p>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Drawer Footer */}
          {savedDecisions.length > 0 && (
            <div className="p-4 border-t border-gray-100 flex items-center justify-between text-xs bg-gray-50/50">
              <button
                onClick={onClearAll}
                className="text-gray-400 hover:text-rose-600 transition-colors"
              >
                Clear all history
              </button>
              <button
                onClick={onOpenReportModal}
                className="text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>View Full Report</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


