import React, { useState } from 'react';
import { JournalEntry, DecisionMood, RetrospectiveReview, SavedDecision, ParsedDecision } from '../types';
import {
  BookOpen,
  Plus,
  Trash2,
  Calendar,
  Smile,
  Frown,
  Meh,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  Star,
  RotateCcw,
  Edit3,
  HelpCircle,
  Tag,
  Clock,
  Compass
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface DiaryDashboardProps {
  journals: JournalEntry[];
  onSaveJournals: (entries: JournalEntry[]) => void;
  savedDecisions: SavedDecision[];
  onCreateFromDecision?: (decision: ParsedDecision) => void;
}

const MOOD_CONFIG: Record<DecisionMood, { label: string; emoji: string; color: string }> = {
  confident: { label: 'Confident', emoji: '🦁', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  optimistic: { label: 'Optimistic', emoji: '🚀', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  neutral: { label: 'Neutral & Calm', emoji: '🤔', color: 'bg-gray-50 text-gray-700 border-gray-200' },
  hesitant: { label: 'Hesitant / Cautious', emoji: '⏳', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  anxious: { label: 'Anxious / Second-Guessing', emoji: '😰', color: 'bg-rose-50 text-rose-700 border-rose-200' },
  pressured: { label: 'Time-Pressured', emoji: '⚡', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  peaceful: { label: 'At Peace', emoji: '🕊️', color: 'bg-teal-50 text-teal-700 border-teal-200' },
};

export const DiaryDashboard: React.FC<DiaryDashboardProps> = ({
  journals,
  onSaveJournals,
  savedDecisions,
}) => {
  const [isCreatingNew, setIsCreatingNew] = useState(journals.length === 0);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMood, setFilterMood] = useState<string>('all');
  const [activeRetroModalEntry, setActiveRetroModalEntry] = useState<JournalEntry | null>(null);

  // New Journal Entry State
  const [newTitle, setNewTitle] = useState('');
  const [newChosenOption, setNewChosenOption] = useState('');
  const [newMood, setNewMood] = useState<DecisionMood>('confident');
  const [newConfidence, setNewConfidence] = useState<number>(85);
  const [newContext, setNewContext] = useState('');
  const [newAssumptions, setNewAssumptions] = useState<string>('');
  const [newFears, setNewFears] = useState('');
  const [newTags, setNewTags] = useState('Career, Architecture');
  const [selectedDecisionId, setSelectedDecisionId] = useState('');

  // Retrospective Form State
  const [retroOutcome, setRetroOutcome] = useState('');
  const [retroRating, setRetroRating] = useState(5);
  const [retroRightChoice, setRetroRightChoice] = useState<'yes' | 'partially' | 'no' | 'too_early'>('yes');
  const [retroLessons, setRetroLessons] = useState('');
  const [retroWouldChooseAgain, setRetroWouldChooseAgain] = useState(true);

  const handleSelectDecision = (decisionId: string) => {
    setSelectedDecisionId(decisionId);
    const target = savedDecisions.find((d) => d.id === decisionId);
    if (target) {
      setNewTitle(target.parsedDecision.quickSummary || target.title);
      setNewChosenOption(target.confirmedChoice || target.parsedDecision.recommendation.chosenOption || '');
      setNewContext(target.parsedDecision.recommendation.because || '');
    }
  };

  const handleCreateEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const parsedAssumptions = newAssumptions
      .split('\n')
      .map((a) => a.trim())
      .filter(Boolean);

    const parsedTagsList = newTags
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const newEntry: JournalEntry = {
      id: `journal-${now}`,
      decisionId: selectedDecisionId || undefined,
      decisionTitle: newTitle.trim(),
      chosenOption: newChosenOption.trim() || undefined,
      date: formattedNow,
      timestamp: now,
      mood: newMood,
      confidenceAtTime: newConfidence,
      tags: parsedTagsList.length > 0 ? parsedTagsList : ['Decision'],
      contextReasoning: newContext.trim(),
      assumptionsMade: parsedAssumptions,
      fearsAndRisks: newFears.trim(),
    };

    const updated = [newEntry, ...journals];
    onSaveJournals(updated);
    setIsCreatingNew(false);
    setNewTitle('');
    setNewChosenOption('');
    setNewContext('');
    setNewAssumptions('');
    setNewFears('');

    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleDeleteEntry = (id: string) => {
    if (window.confirm('Delete this journal entry?')) {
      const updated = journals.filter((j) => j.id !== id);
      onSaveJournals(updated);
    }
  };

  const handleOpenRetroModal = (entry: JournalEntry) => {
    setActiveRetroModalEntry(entry);
    if (entry.retrospective) {
      setRetroOutcome(entry.retrospective.actualOutcome);
      setRetroRating(entry.retrospective.outcomeRating);
      setRetroRightChoice(entry.retrospective.wasRightChoice);
      setRetroLessons(entry.retrospective.lessonsLearned);
      setRetroWouldChooseAgain(entry.retrospective.wouldChooseAgain);
    } else {
      setRetroOutcome('');
      setRetroRating(5);
      setRetroRightChoice('yes');
      setRetroLessons('');
      setRetroWouldChooseAgain(true);
    }
  };

  const handleSaveRetro = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRetroModalEntry) return;

    const now = Date.now();
    const formattedNow = new Date(now).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    const daysDiff = Math.max(
      1,
      Math.round((now - activeRetroModalEntry.timestamp) / (1000 * 60 * 60 * 24))
    );

    const retrospective: RetrospectiveReview = {
      reviewedAt: now,
      reviewedAtFormatted: formattedNow,
      daysAfterDecision: daysDiff,
      actualOutcome: retroOutcome.trim(),
      outcomeRating: retroRating,
      wasRightChoice: retroRightChoice,
      lessonsLearned: retroLessons.trim(),
      wouldChooseAgain: retroWouldChooseAgain,
    };

    const updatedJournals = journals.map((j) =>
      j.id === activeRetroModalEntry.id ? { ...j, retrospective } : j
    );

    onSaveJournals(updatedJournals);
    setActiveRetroModalEntry(null);

    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.8 },
    });
  };

  const filteredEntries = journals.filter((entry) => {
    const matchesSearch =
      entry.decisionTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.contextReasoning.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (entry.chosenOption && entry.chosenOption.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesMood = filterMood === 'all' || entry.mood === filterMood;
    return matchesSearch && matchesMood;
  });

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-8 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
        <div>
          <div className="flex items-center space-x-2 text-blue-600 text-xs font-bold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            <span>Reflective Practice & Retrospective Log</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 tracking-tight">
            Decision Diary & Journals
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
            Log your emotional state, assumptions, and confidence at the time of choice, then review retrospective learnings.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingNew(!isCreatingNew)}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm shrink-0 self-start sm:self-auto"
        >
          {isCreatingNew ? (
            <span>View All Entries</span>
          ) : (
            <>
              <Plus className="w-4 h-4" />
              <span>New Journal Entry</span>
            </>
          )}
        </button>
      </div>

      {/* CREATE NEW ENTRY FORM */}
      {isCreatingNew ? (
        <form
          onSubmit={handleCreateEntry}
          className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xs space-y-5"
        >
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-blue-600" />
              <span>Write Decision Reflection Entry</span>
            </h3>
            {savedDecisions.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-500">Attach to:</span>
                <select
                  value={selectedDecisionId}
                  onChange={(e) => handleSelectDecision(e.target.value)}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Select Saved Decision --</option>
                  {savedDecisions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Decision Title / Topic *
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Decided to accept offer at Company A over Company B"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Chosen Path / Option Selected
              </label>
              <input
                type="text"
                value={newChosenOption}
                onChange={(e) => setNewChosenOption(e.target.value)}
                placeholder="e.g. Option A (Full-time Remote Role)"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Tags (Comma-separated)
              </label>
              <input
                type="text"
                value={newTags}
                onChange={(e) => setNewTags(e.target.value)}
                placeholder="Career, Finance, Health"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Mood Selector */}
            <div className="md:col-span-2 space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600">
                Emotional State / Mood at Moment of Choice
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                {Object.entries(MOOD_CONFIG).map(([moodKey, config]) => (
                  <button
                    key={moodKey}
                    type="button"
                    onClick={() => setNewMood(moodKey as DecisionMood)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center justify-center space-y-1 transition-all ${
                      newMood === moodKey
                        ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-semibold ring-1 ring-blue-600 shadow-2xs'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <span className="text-xl">{config.emoji}</span>
                    <span className="text-[10px] text-center">{config.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Confidence Slider */}
            <div className="md:col-span-2 p-3.5 bg-gray-50 rounded-xl border border-gray-200 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-gray-700 uppercase tracking-wide">
                  Decision Conviction & Confidence
                </span>
                <span className="font-mono font-bold text-blue-600 text-sm">{newConfidence}%</span>
              </div>
              <input
                type="range"
                min={1}
                max={100}
                value={newConfidence}
                onChange={(e) => setNewConfidence(parseInt(e.target.value))}
                className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Context & Rationale ("Why I feel this is right right now")
              </label>
              <textarea
                value={newContext}
                onChange={(e) => setNewContext(e.target.value)}
                placeholder="Write what factors carried the most emotional and logical weight..."
                rows={3}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Key Assumptions Made (1 per line)
              </label>
              <textarea
                value={newAssumptions}
                onChange={(e) => setNewAssumptions(e.target.value)}
                placeholder="Assuming team size stays at 5&#10;Assuming revenue grows 10%"
                rows={3}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Lingering Doubts / Potential Pitfalls
              </label>
              <textarea
                value={newFears}
                onChange={(e) => setNewFears(e.target.value)}
                placeholder="What could go wrong? What is the main source of anxiety?"
                rows={3}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
            {journals.length > 0 && (
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              Save Diary Entry
            </button>
          </div>
        </form>
      ) : null}

      {/* FILTER & SEARCH BAR */}
      {journals.length > 0 && !isCreatingNew ? (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-gray-200 shadow-2xs">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reflections, choices, or rationale..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto">
            <span className="text-xs text-gray-500 font-medium">Mood:</span>
            <select
              value={filterMood}
              onChange={(e) => setFilterMood(e.target.value)}
              className="text-xs px-2.5 py-1.5 border border-gray-200 rounded-lg bg-gray-50 text-gray-700"
            >
              <option value="all">All Moods</option>
              {Object.entries(MOOD_CONFIG).map(([key, cfg]) => (
                <option key={key} value={key}>
                  {cfg.emoji} {cfg.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      ) : null}

      {/* JOURNAL ENTRIES LIST */}
      {journals.length > 0 && !isCreatingNew ? (
        <div className="space-y-4">
          {filteredEntries.map((entry) => {
            const moodCfg = MOOD_CONFIG[entry.mood] || MOOD_CONFIG.neutral;

            return (
              <div
                key={entry.id}
                className="bg-white border border-gray-200/90 rounded-2xl p-5 sm:p-6 shadow-xs hover:border-gray-300 transition-all space-y-4"
              >
                {/* Entry Top Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-100">
                  <div className="flex items-center space-x-2.5 flex-wrap">
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-semibold border flex items-center gap-1.5 ${moodCfg.color}`}
                    >
                      <span>{moodCfg.emoji}</span>
                      <span>{moodCfg.label}</span>
                    </span>

                    <span className="text-xs font-mono text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100 font-bold">
                      {entry.confidenceAtTime}% Confidence
                    </span>

                    <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {entry.date}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleOpenRetroModal(entry)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors border ${
                        entry.retrospective
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-blue-600" />
                      <span>{entry.retrospective ? 'Review Learning' : 'Add Retrospective'}</span>
                    </button>

                    <button
                      onClick={() => handleDeleteEntry(entry.id)}
                      className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Entry Title & Choice */}
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-gray-900 leading-snug">
                    {entry.decisionTitle}
                  </h3>
                  {entry.chosenOption && (
                    <div className="mt-1 flex items-center space-x-1.5 text-xs text-emerald-800 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Committed to: <strong>{entry.chosenOption}</strong></span>
                    </div>
                  )}
                </div>

                {/* Context Rationale */}
                {entry.contextReasoning && (
                  <p className="text-xs sm:text-sm text-gray-700 leading-relaxed bg-gray-50/70 p-3.5 rounded-xl border border-gray-100">
                    "{entry.contextReasoning}"
                  </p>
                )}

                {/* Assumptions & Pitfalls Grid */}
                {(entry.assumptionsMade.length > 0 || entry.fearsAndRisks) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {entry.assumptionsMade.length > 0 && (
                      <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100/70 space-y-1">
                        <span className="font-bold text-blue-900 uppercase text-[10px] tracking-wide">
                          Assumptions at Decision Time:
                        </span>
                        <ul className="list-disc list-inside text-gray-700 space-y-0.5">
                          {entry.assumptionsMade.map((a, i) => (
                            <li key={i}>{a}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {entry.fearsAndRisks && (
                      <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100/70 space-y-1">
                        <span className="font-bold text-amber-900 uppercase text-[10px] tracking-wide">
                          Fears & Foreseen Pitfalls:
                        </span>
                        <p className="text-gray-700 leading-relaxed">{entry.fearsAndRisks}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* RETROSPECTIVE OUTCOME BANNER (IF REVIEWED) */}
                {entry.retrospective && (
                  <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-2 text-xs">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center space-x-2 font-bold text-emerald-900">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
                        <span>Retrospective Check-In ({entry.retrospective.daysAfterDecision} days later)</span>
                      </div>
                      <span className="font-mono text-emerald-800 text-[11px]">
                        Reviewed on {entry.retrospective.reviewedAtFormatted}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <span className="font-semibold text-emerald-950 block mb-0.5">Actual Outcome:</span>
                        <p className="text-gray-800">{entry.retrospective.actualOutcome}</p>
                      </div>
                      <div>
                        <span className="font-semibold text-emerald-950 block mb-0.5">Lessons Learned:</span>
                        <p className="text-gray-800">{entry.retrospective.lessonsLearned}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Tags Footer */}
                {entry.tags.length > 0 && (
                  <div className="flex items-center space-x-1.5 pt-1">
                    {entry.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-medium bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : null}

      {/* RETROSPECTIVE MODAL */}
      {activeRetroModalEntry && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveRetro}
            className="bg-white border border-gray-200 rounded-2xl p-6 max-w-lg w-full shadow-lg space-y-4"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-emerald-600" />
                <span>Decision Retrospective Check-In</span>
              </h3>
              <button
                type="button"
                onClick={() => setActiveRetroModalEntry(null)}
                className="text-gray-400 hover:text-gray-700 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-gray-600">
              Reviewing: <strong>{activeRetroModalEntry.decisionTitle}</strong>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                What actually happened? (Realized Outcome) *
              </label>
              <textarea
                value={retroOutcome}
                onChange={(e) => setRetroOutcome(e.target.value)}
                placeholder="Describe how the decision played out in reality..."
                rows={3}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                  Was it the right choice?
                </label>
                <select
                  value={retroRightChoice}
                  onChange={(e) => setRetroRightChoice(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-gray-50"
                >
                  <option value="yes">Yes, definitely</option>
                  <option value="partially">Partially / Mixed</option>
                  <option value="no">No, should have chosen other</option>
                  <option value="too_early">Still too early to tell</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                  Outcome Rating (1-5 Stars)
                </label>
                <div className="flex items-center space-x-1.5 pt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRetroRating(star)}
                      className={`text-lg transition-transform ${
                        star <= retroRating ? 'text-amber-400 scale-110' : 'text-gray-300'
                      }`}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1">
                Lessons Learned for Future Decisions
              </label>
              <textarea
                value={retroLessons}
                onChange={(e) => setRetroLessons(e.target.value)}
                placeholder="What heuristic or principle will you apply next time?"
                rows={2}
                className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setActiveRetroModalEntry(null)}
                className="px-4 py-2 text-xs font-medium text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors shadow-sm"
              >
                Save Retrospective
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
