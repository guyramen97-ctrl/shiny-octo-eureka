import React, { useState, useEffect, useRef } from 'react';
import {
  CoinFace,
  CoinTossMode,
  CoinTossResult,
  GutCheckReaction,
  SavedDecision,
  JournalEntry,
} from '../types';
import { coinSound } from '../utils/coinSound';
import confetti from 'canvas-confetti';
import {
  Coins,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  ArrowRightLeft,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  History,
  Brain,
  Trophy,
  BookOpen,
  Share2,
  Check,
  ChevronDown,
  Trash2,
  Compass,
  Shuffle,
  Flame,
} from 'lucide-react';

interface CoinTossDashboardProps {
  tossHistory: CoinTossResult[];
  onSaveTossHistory: (history: CoinTossResult[]) => void;
  savedDecisions?: SavedDecision[];
  onSaveToJournal?: (entry: Partial<JournalEntry>) => void;
  onConfirmDecisionChoice?: (decisionId: string, optionName: string) => void;
  initialOptions?: { heads: string; tails: string; decisionId?: string };
}

const PRESET_DILEMMAS = [
  { heads: 'Option A: Take the Leap & Act Now', tails: 'Option B: Wait & Gather More Information' },
  { heads: 'Option A: Accept the New Offer', tails: 'Option B: Stay at Current Position' },
  { heads: 'Option A: Say Yes', tails: 'Option B: Politely Decline (Protect My Time)' },
  { heads: 'Option A: High-Risk / High-Reward Path', tails: 'Option B: Stable & Predictable Path' },
  { heads: 'Option A: Build In-House', tails: 'Option B: Buy Existing Solution' },
];

export const CoinTossDashboard: React.FC<CoinTossDashboardProps> = ({
  tossHistory,
  onSaveTossHistory,
  savedDecisions = [],
  onSaveToJournal,
  onConfirmDecisionChoice,
  initialOptions,
}) => {
  // Config state
  const [optionHeads, setOptionHeads] = useState(
    initialOptions?.heads || 'Option A: Pursue the New Opportunity'
  );
  const [optionTails, setOptionTails] = useState(
    initialOptions?.tails || 'Option B: Maintain Current Course'
  );
  const [linkedDecisionId, setLinkedDecisionId] = useState<string | undefined>(
    initialOptions?.decisionId
  );
  const [tossMode, setTossMode] = useState<CoinTossMode>('single');
  const [isMuted, setIsMuted] = useState(coinSound.getMuted());

  // Animation & Toss State
  const [isFlipping, setIsFlipping] = useState(false);
  const [currentFace, setCurrentFace] = useState<CoinFace>('heads');
  const [lastLandedFace, setLastLandedFace] = useState<CoinFace | null>(null);

  // Series match state (for best_of_3 and best_of_5)
  const [seriesFlips, setSeriesFlips] = useState<CoinFace[]>([]);
  const [seriesWinner, setSeriesWinner] = useState<CoinFace | null>(null);

  // Psychological Gut-Check State
  const [gutReaction, setGutReaction] = useState<GutCheckReaction | null>(null);
  const [gutNote, setGutNote] = useState('');
  const [hasLoggedGutCheck, setHasLoggedGutCheck] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Multi-option tournament / roulette state
  const [multiOptions, setMultiOptions] = useState<string[]>([
    'Option A: Strategy Alpha',
    'Option B: Strategy Beta',
    'Option C: Strategy Gamma',
  ]);
  const [activeSubTab, setActiveSubTab] = useState<'standard' | 'multi'>('standard');
  const [multiWinner, setMultiWinner] = useState<string | null>(null);
  const [isMultiRolling, setIsMultiRolling] = useState(false);

  // Calculate required wins for series
  const requiredWins = tossMode === 'best_of_3' ? 2 : tossMode === 'best_of_5' ? 3 : 1;
  const headsScore = seriesFlips.filter((f) => f === 'heads').length;
  const tailsScore = seriesFlips.filter((f) => f === 'tails').length;

  // Sync initial options if passed dynamically
  useEffect(() => {
    if (initialOptions?.heads) setOptionHeads(initialOptions.heads);
    if (initialOptions?.tails) setOptionTails(initialOptions.tails);
    if (initialOptions?.decisionId) setLinkedDecisionId(initialOptions.decisionId);
  }, [initialOptions]);

  // Keyboard shortcut: Spacebar to flip
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.code === 'Space' &&
        !isFlipping &&
        (e.target as HTMLElement).tagName !== 'INPUT' &&
        (e.target as HTMLElement).tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        triggerToss();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFlipping, tossMode, seriesWinner, optionHeads, optionTails]);

  const toggleSound = () => {
    const newMute = coinSound.toggleMute();
    setIsMuted(newMute);
  };

  const swapOptions = () => {
    const temp = optionHeads;
    setOptionHeads(optionTails);
    setOptionTails(temp);
  };

  const handleSelectPreset = (heads: string, tails: string) => {
    setOptionHeads(heads);
    setOptionTails(tails);
    setLinkedDecisionId(undefined);
    resetSeries();
  };

  const handleSelectDecision = (dec: SavedDecision) => {
    if (dec.parsedDecision.options.length >= 2) {
      setOptionHeads(`Option A: ${dec.parsedDecision.options[0].name}`);
      setOptionTails(`Option B: ${dec.parsedDecision.options[1].name}`);
      setLinkedDecisionId(dec.id);
      resetSeries();
    }
  };

  const resetSeries = () => {
    setSeriesFlips([]);
    setSeriesWinner(null);
    setLastLandedFace(null);
    setGutReaction(null);
    setGutNote('');
    setHasLoggedGutCheck(false);
  };

  const handleModeChange = (mode: CoinTossMode) => {
    setTossMode(mode);
    resetSeries();
  };

  // Perform single flip
  const triggerToss = () => {
    if (isFlipping) return;
    if (seriesWinner && tossMode !== 'single') {
      resetSeries();
    }

    setIsFlipping(true);
    setGutReaction(null);
    setHasLoggedGutCheck(false);

    // Audio ping on toss
    coinSound.playToss();

    // Random outcome: 50% heads, 50% tails
    const outcome: CoinFace = Math.random() < 0.5 ? 'heads' : 'tails';

    // Animation takes 1.6s
    setTimeout(() => {
      setIsFlipping(false);
      setCurrentFace(outcome);
      setLastLandedFace(outcome);

      // Audio land thud + metallic settlement
      coinSound.playLand();

      if (tossMode === 'single') {
        recordFinalResult([outcome], outcome);
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#F59E0B', '#3B82F6', '#10B981'],
        });
      } else {
        const nextFlips = [...seriesFlips, outcome];
        setSeriesFlips(nextFlips);

        const newHeads = nextFlips.filter((f) => f === 'heads').length;
        const newTails = nextFlips.filter((f) => f === 'tails').length;

        if (newHeads >= requiredWins) {
          setSeriesWinner('heads');
          recordFinalResult(nextFlips, 'heads');
          confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
        } else if (newTails >= requiredWins) {
          setSeriesWinner('tails');
          recordFinalResult(nextFlips, 'tails');
          confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
        }
      }
    }, 1600);
  };

  const recordFinalResult = (flips: CoinFace[], winner: CoinFace) => {
    const winningOption = winner === 'heads' ? optionHeads : optionTails;
    const newRecord: CoinTossResult = {
      id: `toss-${Date.now()}`,
      decisionId: linkedDecisionId,
      timestamp: Date.now(),
      timestampFormatted: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
      optionHeads,
      optionTails,
      mode: tossMode,
      flips,
      winnerFace: winner,
      winningOption,
    };

    onSaveTossHistory([newRecord, ...tossHistory]);
  };

  // Gut check submission
  const handleRecordGutCheck = (reaction: GutCheckReaction) => {
    setGutReaction(reaction);
    setHasLoggedGutCheck(true);
    coinSound.playEureka();

    const winnerFace = seriesWinner || lastLandedFace || currentFace;
    const coinChosenOption = winnerFace === 'heads' ? optionHeads : optionTails;
    const alternateOption = winnerFace === 'heads' ? optionTails : optionHeads;

    // In psychology, if you feel disappointment, your TRUE choice is the other one!
    const reflectedChoice =
      reaction === 'disappointment' ? alternateOption : coinChosenOption;

    // Update latest history entry with gut check details
    if (tossHistory.length > 0) {
      const updated = [...tossHistory];
      updated[0] = {
        ...updated[0],
        gutCheck: {
          reaction,
          reflectedChoice,
          note: gutNote.trim() || undefined,
        },
      };
      onSaveTossHistory(updated);
    }
  };

  // 1-Click Save to Journal
  const handleSaveToDecisionJournal = () => {
    if (!onSaveToJournal) return;
    const winnerFace = seriesWinner || lastLandedFace || currentFace;
    const coinChosenOption = winnerFace === 'heads' ? optionHeads : optionTails;
    const alternateOption = winnerFace === 'heads' ? optionTails : optionHeads;
    const finalChoice =
      gutReaction === 'disappointment' ? alternateOption : coinChosenOption;

    onSaveToJournal({
      decisionTitle: `Coin Toss Gut-Check: ${optionHeads.slice(0, 30)} vs ${optionTails.slice(0, 30)}`,
      chosenOption: finalChoice,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
      timestamp: Date.now(),
      mood: gutReaction === 'relief' ? 'confident' : 'peaceful',
      confidenceAtTime: gutReaction === 'relief' ? 95 : 80,
      tags: ['Coin Toss', 'Subconscious Gut-Check', 'Freud Rule'],
      contextReasoning: `Tossed a coin between "${optionHeads}" and "${optionTails}". Coin landed on ${winnerFace.toUpperCase()} (${coinChosenOption}). Gut check reaction: ${
        gutReaction ? gutReaction.toUpperCase() : 'NEUTRAL'
      }. Final resolved choice: "${finalChoice}". ${gutNote ? `User note: ${gutNote}` : ''}`,
      assumptionsMade: ['Subconscious visceral reaction accurately highlights the preferred outcome.'],
      fearsAndRisks: 'Overthinking or analysis paralysis before flipping.',
    });

    alert('Decision saved directly to your Diary / Journals tab!');
  };

  // 1-Click confirm decision choice
  const handleConfirmDecision = () => {
    if (!linkedDecisionId || !onConfirmDecisionChoice) return;
    const winnerFace = seriesWinner || lastLandedFace || currentFace;
    const coinChosenOption = winnerFace === 'heads' ? optionHeads : optionTails;
    const alternateOption = winnerFace === 'heads' ? optionTails : optionHeads;
    const finalChoice =
      gutReaction === 'disappointment' ? alternateOption : coinChosenOption;

    onConfirmDecisionChoice(linkedDecisionId, finalChoice);
    alert(`Option "${finalChoice}" successfully marked as confirmed choice!`);
  };

  const copyResult = () => {
    const winnerFace = seriesWinner || lastLandedFace || currentFace;
    const winningOpt = winnerFace === 'heads' ? optionHeads : optionTails;
    const text = `🪙 Decision Helper Coin Toss\n- Option A (Heads): ${optionHeads}\n- Option B (Tails): ${optionTails}\n- Mode: ${tossMode}\n- Verdict: ${winnerFace.toUpperCase()} ➔ ${winningOpt}\n${
      gutReaction ? `- Gut-Check Reaction: ${gutReaction.toUpperCase()}` : ''
    }`;
    navigator.clipboard.writeText(text);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Multi-option roll
  const triggerMultiRoll = () => {
    if (isMultiRolling || multiOptions.length < 2) return;
    setIsMultiRolling(true);
    coinSound.playToss();

    let counter = 0;
    const interval = setInterval(() => {
      const randIdx = Math.floor(Math.random() * multiOptions.length);
      setMultiWinner(multiOptions[randIdx]);
      counter++;
      if (counter > 15) {
        clearInterval(interval);
        const finalIdx = Math.floor(Math.random() * multiOptions.length);
        setMultiWinner(multiOptions[finalIdx]);
        setIsMultiRolling(false);
        coinSound.playLand();
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      }
    }, 90);
  };

  // Stats calculation
  const totalFlipsCount = tossHistory.reduce(
    (sum, t) => sum + (t.flips ? t.flips.length : 1),
    0
  );
  const totalHeadsCount = tossHistory.reduce(
    (sum, t) => sum + (t.flips ? t.flips.filter((f) => f === 'heads').length : t.winnerFace === 'heads' ? 1 : 0),
    0
  );
  const totalTailsCount = totalFlipsCount - totalHeadsCount;
  const headsPercent = totalFlipsCount > 0 ? Math.round((totalHeadsCount / totalFlipsCount) * 100) : 50;

  const gutChecksWithReaction = tossHistory.filter((t) => t.gutCheck?.reaction);
  const gutAlignedCount = gutChecksWithReaction.filter(
    (t) => t.gutCheck?.reaction === 'relief'
  ).length;
  const gutAlignmentRate =
    gutChecksWithReaction.length > 0
      ? Math.round((gutAlignedCount / gutChecksWithReaction.length) * 100)
      : null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Top Header & Philosophy Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-blue-500/10 to-indigo-500/10 border border-amber-200/60 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-2xs relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-amber-700 font-semibold text-xs tracking-wider uppercase">
              <Coins className="w-4 h-4 text-amber-600" />
              <span>Intuition Revealer & Tiebreaker Engine</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight mt-1">
              Quantum Coin Toss & Gut-Check
            </h2>
            <p className="text-sm text-gray-600 max-w-2xl mt-1.5 leading-relaxed">
              <span className="font-semibold text-gray-800">The Freud Decision Principle:</span>{' '}
              A coin toss doesn’t make the choice for you. Instead,{' '}
              <em className="text-gray-900 font-medium">
                in that split-second while the coin is in the air, your subconscious reveals what you secretly hope for.
              </em>
            </p>
          </div>

          {/* Sound & Controls */}
          <div className="flex items-center space-x-2 self-start sm:self-center shrink-0">
            <button
              onClick={toggleSound}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                !isMuted
                  ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                  : 'bg-gray-100 text-gray-500 border-gray-200 hover:bg-gray-200'
              }`}
              title={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
            >
              {!isMuted ? (
                <>
                  <Volume2 className="w-4 h-4 text-amber-600" />
                  <span>Audio ON</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-gray-400" />
                  <span>Audio OFF</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Tab switcher: 2-Option Toss vs Multi-Option Dice */}
        <div className="mt-6 flex space-x-2 border-b border-gray-200/60 pb-1">
          <button
            onClick={() => setActiveSubTab('standard')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeSubTab === 'standard'
                ? 'bg-white text-gray-900 shadow-sm border border-gray-200/80'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
            }`}
          >
            <Coins className="w-3.5 h-3.5 text-amber-500" />
            <span>Classic 2-Choice Toss (Heads / Tails)</span>
          </button>
          <button
            onClick={() => setActiveSubTab('multi')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeSubTab === 'multi'
                ? 'bg-white text-gray-900 shadow-sm border border-gray-200/80'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
            }`}
          >
            <Shuffle className="w-3.5 h-3.5 text-blue-500" />
            <span>Multi-Choice Decider (3+ Options)</span>
          </button>
        </div>
      </div>

      {activeSubTab === 'standard' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN: The Interactive 3D Coin & Flipping Arena */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-8 shadow-xs relative overflow-hidden flex flex-col items-center justify-center min-h-[460px]">
              {/* Background radial spotlight */}
              <div className="absolute inset-0 bg-radial from-amber-50/50 via-transparent to-transparent pointer-events-none" />

              {/* Mode Selector Pill */}
              <div className="inline-flex p-1 bg-gray-100 rounded-xl mb-6 relative z-10">
                {(['single', 'best_of_3', 'best_of_5'] as CoinTossMode[]).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => handleModeChange(mode)}
                    disabled={isFlipping}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      tossMode === mode
                        ? 'bg-white text-gray-900 shadow-2xs font-bold'
                        : 'text-gray-500 hover:text-gray-900'
                    }`}
                  >
                    {mode === 'single'
                      ? 'Single Toss'
                      : mode === 'best_of_3'
                      ? 'Best of 3'
                      : 'Best of 5'}
                  </button>
                ))}
              </div>

              {/* Series Scoreboard (If Best of 3/5) */}
              {tossMode !== 'single' && (
                <div className="flex items-center space-x-6 mb-6 px-4 py-2 bg-gray-50 border border-gray-200 rounded-2xl relative z-10 text-xs">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span className="font-semibold text-gray-700">Heads:</span>
                    <span className="font-mono text-base font-bold text-gray-900">
                      {headsScore}
                    </span>
                  </div>
                  <span className="text-gray-300 font-bold">vs</span>
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                    <span className="font-semibold text-gray-700">Tails:</span>
                    <span className="font-mono text-base font-bold text-gray-900">
                      {tailsScore}
                    </span>
                  </div>
                  <span className="text-[11px] text-gray-400 pl-2 border-l border-gray-200">
                    First to {requiredWins} wins
                  </span>
                </div>
              )}

              {/* 3D COIN ARENA */}
              <div className="relative w-48 h-48 sm:w-56 sm:h-56 flex items-center justify-center perspective-1000 my-4 select-none cursor-pointer"
                onClick={triggerToss}
                title="Click coin or press Space to flip"
              >
                {/* 3D Rotating Coin Element */}
                <div
                  className={`w-40 h-40 sm:w-48 sm:h-48 rounded-full relative preserve-3d transition-transform duration-500 ${
                    isFlipping
                      ? lastLandedFace === 'tails' || currentFace === 'tails'
                        ? 'animate-coin-tails'
                        : 'animate-coin-heads'
                      : currentFace === 'tails'
                      ? 'rotate-y-180'
                      : ''
                  }`}
                >
                  {/* COIN FACE 1: HEADS (Gold Metallic Luxury Finish) */}
                  <div className="absolute inset-0 rounded-full backface-hidden bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 border-4 border-amber-300 shadow-xl flex flex-col items-center justify-center p-3 text-center">
                    {/* Outer milled rim */}
                    <div className="absolute inset-1 rounded-full border-2 border-dashed border-amber-700/30 pointer-events-none" />
                    {/* Inner polished medal disc */}
                    <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gradient-to-br from-yellow-300 to-amber-500 border border-amber-600/40 shadow-inner flex flex-col items-center justify-center p-2">
                      <Sparkles className="w-6 h-6 text-amber-900 drop-shadow-xs mb-1" />
                      <span className="font-black text-amber-950 text-xs sm:text-sm tracking-widest uppercase">
                        HEADS
                      </span>
                      <span className="text-[9px] font-bold text-amber-900/80 truncate max-w-[90px] mt-0.5">
                        {optionHeads ? optionHeads.slice(0, 18) : 'Option A'}
                      </span>
                    </div>
                  </div>

                  {/* COIN FACE 2: TAILS (Silver / Platinum Prestige Finish) */}
                  <div className="absolute inset-0 rounded-full backface-hidden rotate-y-180 bg-gradient-to-tr from-slate-400 via-gray-100 to-slate-300 border-4 border-slate-300 shadow-xl flex flex-col items-center justify-center p-3 text-center">
                    {/* Outer milled rim */}
                    <div className="absolute inset-1 rounded-full border-2 border-dashed border-slate-600/30 pointer-events-none" />
                    {/* Inner polished medal disc */}
                    <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gradient-to-br from-slate-200 to-slate-400 border border-slate-500/40 shadow-inner flex flex-col items-center justify-center p-2">
                      <Trophy className="w-6 h-6 text-slate-800 drop-shadow-xs mb-1" />
                      <span className="font-black text-slate-900 text-xs sm:text-sm tracking-widest uppercase">
                        TAILS
                      </span>
                      <span className="text-[9px] font-bold text-slate-800/80 truncate max-w-[90px] mt-0.5">
                        {optionTails ? optionTails.slice(0, 18) : 'Option B'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Grounding Shadow Underneath Coin */}
                <div
                  className={`absolute -bottom-6 w-32 sm:w-36 h-4 bg-gray-900/30 rounded-full blur-md ${
                    isFlipping ? 'animate-coin-shadow' : ''
                  }`}
                />
              </div>

              {/* Status Banner */}
              <div className="text-center my-3 min-h-[32px]">
                {isFlipping ? (
                  <div className="flex items-center justify-center space-x-2 text-amber-600 font-bold text-sm animate-pulse">
                    <Flame className="w-4 h-4 animate-bounce" />
                    <span>Coin is in the air... what is your gut whispering?</span>
                  </div>
                ) : seriesWinner ? (
                  <div className="flex items-center justify-center space-x-2 text-emerald-700 font-bold text-sm bg-emerald-50 px-4 py-1.5 rounded-full border border-emerald-200">
                    <Trophy className="w-4 h-4 text-emerald-600" />
                    <span>
                      Winner of Series:{' '}
                      <span className="uppercase">{seriesWinner}</span> (
                      {seriesWinner === 'heads' ? optionHeads : optionTails})
                    </span>
                  </div>
                ) : lastLandedFace ? (
                  <div className="flex items-center justify-center space-x-2 text-gray-800 font-semibold text-sm">
                    <span>Landed on:</span>
                    <span className="uppercase font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                      {lastLandedFace}
                    </span>
                    <span className="text-gray-500">—</span>
                    <span className="font-medium truncate max-w-[240px]">
                      {lastLandedFace === 'heads' ? optionHeads : optionTails}
                    </span>
                  </div>
                ) : (
                  <p className="text-xs text-gray-400">
                    Ready to toss. Click the coin or press <kbd className="px-1.5 py-0.5 bg-gray-100 border rounded text-gray-600">Space</kbd>
                  </p>
                )}
              </div>

              {/* Main Flip Action Button */}
              <div className="flex items-center space-x-3 mt-4 relative z-10">
                <button
                  id="flip-coin-btn"
                  onClick={triggerToss}
                  disabled={isFlipping}
                  className={`px-6 py-3 rounded-2xl font-bold text-sm shadow-md transition-all flex items-center space-x-2.5 ${
                    isFlipping
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-amber-500 hover:bg-amber-600 text-white hover:shadow-lg active:scale-95'
                  }`}
                >
                  <Coins className={`w-4 h-4 ${isFlipping ? 'animate-spin' : ''}`} />
                  <span>
                    {isFlipping
                      ? 'Flipping...'
                      : tossMode === 'single'
                      ? 'Flip Coin!'
                      : seriesWinner
                      ? 'Start New Series'
                      : `Flip Round (${seriesFlips.length + 1})`}
                  </span>
                </button>

                {(lastLandedFace || seriesFlips.length > 0) && !isFlipping && (
                  <button
                    onClick={resetSeries}
                    className="p-3 rounded-2xl border border-gray-200 text-gray-500 hover:text-gray-800 hover:bg-gray-50 transition-colors"
                    title="Reset Series"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* FREUD GUT-CHECK ENGINE CALLOUT (Revealed upon landing) */}
            {(lastLandedFace || seriesWinner) && !isFlipping && (
              <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-indigo-700/60 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-9 h-9 rounded-xl bg-indigo-500/30 border border-indigo-400/40 flex items-center justify-center shrink-0">
                      <Brain className="w-5 h-5 text-indigo-300" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-indigo-300 tracking-wider">
                        Psychological Verification
                      </span>
                      <h4 className="text-base font-bold text-white tracking-tight">
                        The Freud Gut-Check Test
                      </h4>
                    </div>
                  </div>
                  <button
                    onClick={copyResult}
                    className="text-xs text-indigo-300 hover:text-white flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-indigo-800/60 border border-indigo-700 transition-colors"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Copied' : 'Share'}</span>
                  </button>
                </div>

                <p className="text-xs sm:text-sm text-indigo-100 leading-relaxed">
                  The coin designated:{' '}
                  <strong className="text-amber-300 font-bold">
                    {(seriesWinner || lastLandedFace) === 'heads' ? optionHeads : optionTails}
                  </strong>
                  . Take a breath and notice: <em>How did you react the instant it landed?</em>
                </p>

                {/* 3 Gut Check Choice Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                  <button
                    onClick={() => handleRecordGutCheck('relief')}
                    className={`p-3 rounded-2xl text-left border transition-all ${
                      gutReaction === 'relief'
                        ? 'bg-emerald-600/30 border-emerald-400 ring-2 ring-emerald-400/50 text-white'
                        : 'bg-white/5 border-white/10 hover:bg-white/10 text-indigo-100'
                    }`}
                  >
                    <div className="text-lg">🌿</div>
                    <div className="font-bold text-xs mt-1">Felt Relief!</div>
                    <div className="text-[10px] text-emerald-300/90 mt-0.5">
                      Subconscious agrees with this outcome.
                    </div>
                  </button>

                  <button
                    onClick={() => handleRecordGutCheck('disappointment')}
                    className={`p-3 rounded-2xl text-left border transition-all ${
                      gutReaction === 'disappointment'
                        ? 'bg-rose-600/30 border-rose-400 ring-2 ring-rose-400/50 text-white'
                        : 'bg-white/5 border-white/10 hover:bg-white/10 text-indigo-100'
                    }`}
                  >
                    <div className="text-lg">⚡</div>
                    <div className="font-bold text-xs mt-1">Felt Disappointed!</div>
                    <div className="text-[10px] text-rose-300/90 mt-0.5">
                      Aha! You secretly want the other option!
                    </div>
                  </button>

                  <button
                    onClick={() => handleRecordGutCheck('indifferent')}
                    className={`p-3 rounded-2xl text-left border transition-all ${
                      gutReaction === 'indifferent'
                        ? 'bg-amber-600/30 border-amber-400 ring-2 ring-amber-400/50 text-white'
                        : 'bg-white/5 border-white/10 hover:bg-white/10 text-indigo-100'
                    }`}
                  >
                    <div className="text-lg">⚖️</div>
                    <div className="font-bold text-xs mt-1">Truly Indifferent</div>
                    <div className="text-[10px] text-amber-300/90 mt-0.5">
                      Equal utility. Trust the coin’s tiebreak.
                    </div>
                  </button>
                </div>

                {/* Gut Check Feedback & Next Step Actions */}
                {gutReaction && (
                  <div className="pt-3 border-t border-indigo-700/50 space-y-3">
                    <div className="bg-white/10 rounded-xl p-3 text-xs leading-relaxed">
                      {gutReaction === 'relief' && (
                        <p className="text-emerald-200">
                          <strong>Validated by Intuition:</strong> Your immediate sense of relief proves your emotional and logical centers are aligned. Lock this in with confidence!
                        </p>
                      )}
                      {gutReaction === 'disappointment' && (
                        <p className="text-rose-200">
                          <strong>The Secret Desire Discovered:</strong> If the coin landing on this choice made your stomach sink, your decision is already made: Choose{' '}
                          <strong className="text-white underline">
                            {(seriesWinner || lastLandedFace) === 'heads' ? optionTails : optionHeads}
                          </strong>
                          !
                        </p>
                      )}
                      {gutReaction === 'indifferent' && (
                        <p className="text-amber-200">
                          <strong>Equilibrium State:</strong> Since you feel zero friction either way, following the coin saves you from costly analysis paralysis.
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {onSaveToJournal && (
                        <button
                          onClick={handleSaveToDecisionJournal}
                          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-xs transition-colors"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>Save Result to Journal</span>
                        </button>
                      )}

                      {linkedDecisionId && onConfirmDecisionChoice && (
                        <button
                          onClick={handleConfirmDecision}
                          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Confirm on Linked Decision</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: Configuration, Presets & Session History */}
          <div className="lg:col-span-5 space-y-6">
            {/* Options Configuration Card */}
            <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-900 text-sm flex items-center space-x-2">
                  <Compass className="w-4 h-4 text-amber-500" />
                  <span>Dilemma Options</span>
                </h3>
                <button
                  onClick={swapOptions}
                  className="text-xs text-gray-500 hover:text-gray-900 flex items-center space-x-1 px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors"
                  title="Swap Heads & Tails"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  <span>Swap</span>
                </button>
              </div>

              {/* Option A (Heads) */}
              <div className="space-y-1.5">
                <label className="flex items-center justify-between text-xs font-semibold text-amber-900">
                  <span className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span>HEADS (Option A)</span>
                  </span>
                </label>
                <input
                  type="text"
                  value={optionHeads}
                  onChange={(e) => setOptionHeads(e.target.value)}
                  placeholder="Enter first option..."
                  className="w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm border border-amber-200 bg-amber-50/40 text-gray-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              {/* Option B (Tails) */}
              <div className="space-y-1.5">
                <label className="flex items-center justify-between text-xs font-semibold text-slate-800">
                  <span className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                    <span>TAILS (Option B)</span>
                  </span>
                </label>
                <input
                  type="text"
                  value={optionTails}
                  onChange={(e) => setOptionTails(e.target.value)}
                  placeholder="Enter second option..."
                  className="w-full px-3.5 py-2 rounded-xl text-xs sm:text-sm border border-slate-200 bg-slate-50/50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                />
              </div>

              {/* Load From Saved Decisions Dropdown */}
              {savedDecisions.length > 0 && (
                <div className="pt-2 border-t border-gray-100">
                  <label className="text-[11px] font-medium text-gray-500 block mb-1.5">
                    Link with a Saved Decision:
                  </label>
                  <select
                    className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    onChange={(e) => {
                      const dec = savedDecisions.find((d) => d.id === e.target.value);
                      if (dec) handleSelectDecision(dec);
                    }}
                    value={linkedDecisionId || ''}
                  >
                    <option value="">-- Choose from Saved Decisions --</option>
                    {savedDecisions.map((dec) => (
                      <option key={dec.id} value={dec.id}>
                        {dec.title} ({dec.parsedDecision.options.length} options)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Quick Presets */}
              <div className="pt-2">
                <span className="text-[11px] font-medium text-gray-400 block mb-2">
                  Or load standard dilemma templates:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {PRESET_DILEMMAS.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectPreset(preset.heads, preset.tails)}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-amber-50 hover:text-amber-800 text-gray-600 transition-colors border border-transparent hover:border-amber-200"
                    >
                      {preset.heads.split(':')[1]?.trim() || preset.heads}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Probability & Gut-Check Statistics Card */}
            <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-xs space-y-4">
              <h3 className="font-bold text-gray-900 text-sm flex items-center space-x-2">
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>Session Probability & Alignment</span>
              </h3>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-3 bg-amber-50/70 border border-amber-100 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-amber-800">Heads</div>
                  <div className="text-lg font-black text-amber-950 font-mono mt-0.5">
                    {totalHeadsCount}
                  </div>
                  <div className="text-[10px] text-amber-700/80">{headsPercent}%</div>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-slate-700">Tails</div>
                  <div className="text-lg font-black text-slate-900 font-mono mt-0.5">
                    {totalTailsCount}
                  </div>
                  <div className="text-[10px] text-slate-600/80">{100 - headsPercent}%</div>
                </div>

                <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-indigo-800">Gut Alignment</div>
                  <div className="text-lg font-black text-indigo-950 font-mono mt-0.5">
                    {gutAlignmentRate !== null ? `${gutAlignmentRate}%` : '—'}
                  </div>
                  <div className="text-[10px] text-indigo-700/80">
                    {gutChecksWithReaction.length} tested
                  </div>
                </div>
              </div>

              {/* Progress split bar */}
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
                <div
                  className="bg-amber-500 h-full transition-all duration-500"
                  style={{ width: `${headsPercent}%` }}
                />
                <div
                  className="bg-blue-500 h-full transition-all duration-500"
                  style={{ width: `${100 - headsPercent}%` }}
                />
              </div>
            </div>

            {/* Session Toss History Card */}
            <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-900 text-sm flex items-center space-x-2">
                  <History className="w-4 h-4 text-gray-500" />
                  <span>Recent Toss History</span>
                </h3>
                {tossHistory.length > 0 && (
                  <button
                    onClick={() => onSaveTossHistory([])}
                    className="text-xs text-red-500 hover:text-red-700 flex items-center space-x-1"
                    title="Clear toss history"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Clear</span>
                  </button>
                )}
              </div>

              {tossHistory.length === 0 ? (
                <p className="text-xs text-gray-400 py-3 text-center italic">
                  No coin tosses logged yet. Flip above to record your first!
                </p>
              ) : (
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {tossHistory.slice(0, 10).map((item) => (
                    <div
                      key={item.id}
                      className="p-3 bg-gray-50 border border-gray-200/80 rounded-2xl flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center space-x-2">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                              item.winnerFace === 'heads'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-200 text-slate-800'
                            }`}
                          >
                            {item.winnerFace}
                          </span>
                          <span className="font-semibold text-gray-900 truncate">
                            {item.winningOption}
                          </span>
                        </div>
                        <div className="text-[11px] text-gray-500 mt-1 truncate">
                          vs {item.winnerFace === 'heads' ? item.optionTails : item.optionHeads}
                        </div>
                        {item.gutCheck && (
                          <div className="mt-1 flex items-center space-x-1.5 text-[11px] text-indigo-700 font-medium">
                            <Brain className="w-3 h-3" />
                            <span>
                              Gut Reaction: <span className="capitalize">{item.gutCheck.reaction}</span>{' '}
                              (Chose: {item.gutCheck.reflectedChoice.slice(0, 20)}...)
                            </span>
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] text-gray-400 shrink-0 font-mono">
                        {item.timestampFormatted}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* MULTI-OPTION RANDOMIZER SUB-TAB */
        <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-gray-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div>
            <div className="flex items-center space-x-2 text-blue-600 font-semibold text-xs tracking-wider uppercase">
              <Shuffle className="w-4 h-4" />
              <span>Multi-Choice Decider</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mt-1">
              Random Wheel & Tiebreaker for 3+ Choices
            </h3>
            <p className="text-xs text-gray-500 mt-1">
              Have 3, 4, or 5 competing options? Randomly select one or eliminate options one by one.
            </p>
          </div>

          {/* Options List */}
          <div className="space-y-2.5">
            <label className="text-xs font-semibold text-gray-700 block">
              Options in the Pool:
            </label>
            {multiOptions.map((opt, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <span className="w-6 text-xs font-bold text-gray-400 font-mono">
                  #{idx + 1}
                </span>
                <input
                  type="text"
                  value={opt}
                  onChange={(e) => {
                    const next = [...multiOptions];
                    next[idx] = e.target.value;
                    setMultiOptions(next);
                  }}
                  className="flex-1 px-3 py-2 rounded-xl text-xs sm:text-sm border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
                {multiOptions.length > 2 && (
                  <button
                    onClick={() => {
                      setMultiOptions(multiOptions.filter((_, i) => i !== idx));
                    }}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}

            {multiOptions.length < 8 && (
              <button
                onClick={() =>
                  setMultiOptions([
                    ...multiOptions,
                    `Option ${String.fromCharCode(65 + multiOptions.length)}: New Alternative`,
                  ])
                }
                className="text-xs text-blue-600 font-semibold hover:underline flex items-center space-x-1 pt-1"
              >
                <span>+ Add another option</span>
              </button>
            )}
          </div>

          {/* Random Roll Display */}
          <div className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200/80 rounded-2xl text-center space-y-4">
            <div className="text-xs uppercase font-bold text-blue-700 tracking-wider">
              {isMultiRolling ? 'Spinning the Decider...' : multiWinner ? 'Selected by Randomizer' : 'Ready to Select'}
            </div>

            <div className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight min-h-[40px] flex items-center justify-center">
              {multiWinner || '???'}
            </div>

            <button
              onClick={triggerMultiRoll}
              disabled={isMultiRolling}
              className={`px-6 py-3 rounded-2xl font-bold text-sm shadow-md transition-all ${
                isMultiRolling
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white active:scale-95'
              }`}
            >
              {isMultiRolling ? 'Rolling...' : 'Roll Random Winner!'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
